# ClinicFlow Cloud Foundation

This is a **cloud migration foundation**, not a production-ready or HIPAA-certified application.
The original Base44 export is preserved separately in `legacy-base44-export/`. This folder adds
a containerized API foundation, Postgres schema, doctor-search ports/adapters, and deployment
templates so the backend can be migrated incrementally.

## Important scope decisions

- The Base44 export is a frontend export. Its original server-side functions, data, auth rules,
  and connector implementations are not included in the ZIP. They must be reimplemented and tested.
- Do not connect real patient data until authentication, authorization, audit logging, encryption,
  backup/restore, incident response, BAAs, and a security review are complete.
- Search results are **candidate discovery**, not a clinical recommendation or an objective claim
  that a doctor is "the best". Show sources, distance, credentials and appointment availability.
- Search queries must contain only public provider-search criteria (specialty and city/ZIP).
  Never send patient names, DOB, symptoms, insurance member IDs, or other PHI to a web search API.
- The booking endpoint is deliberately a safe stub. A real booking adapter must verify availability,
  hold a slot, request patient confirmation, re-check availability, and book idempotently.

## Run the backend locally

Requirements: Docker Desktop with Compose.

```bash
cp .env.example .env
docker compose up --build
```

API health: http://localhost:8000/health
OpenAPI: http://localhost:8000/docs

The initial API uses a development-only search adapter and returns no fabricated provider records.
Configure a real search adapter and authoritative provider-directory data before use.

## Contents

- `backend/`: FastAPI modular-monolith foundation.
- `database/schema.sql`: initial relational schema, including NPI and provider locations.
- `infra/k8s/`: starter Kubernetes manifests (not production-hardened).
- `legacy-base44-export/`: original uploaded Base44 project, unchanged.

## Next migration milestones

1. Normalize the frontend filenames/imports and replace Base44 SDK calls with a backend client.
2. Port and test each of the 23 inferred Base44 functions; confirm actual contracts against the live app.
3. Implement Cognito/OIDC authentication and server-side RBAC. UI route hiding is not authorization.
4. Implement Stedi 270/271 eligibility, 276/277 claim status, and 837P submission using server-side
   Secrets Manager secrets, idempotency keys, and immutable audit events.
5. Connect a licensed provider directory and state medical-board verification workflow.
6. Add a search provider adapter, ranking transparency, scheduling adapter and patient-confirmed booking.
7. Complete HIPAA risk analysis, BAAs, security testing, operational controls and disaster recovery.

## Secrets

Never put Stedi, Google, search-provider, Stripe, database, or LLM keys in React `VITE_*` variables.
Use AWS Secrets Manager and workload identity in production. `.env` is local development only.
