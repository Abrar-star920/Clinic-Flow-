from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = ""
    redis_url: str = ""
    stedi_api_key: str = ""
    stedi_base_url: str = "https://healthcare.us.stedi.com"
    web_search_provider: str = "disabled"
    web_search_api_key: str = ""
    web_search_base_url: str = ""
    llm_provider: str = "disabled"
    aws_region: str = "us-east-1"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
