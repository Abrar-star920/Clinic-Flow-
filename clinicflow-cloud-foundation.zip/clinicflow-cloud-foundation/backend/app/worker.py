"""Placeholder ETL worker entrypoint.

Production implementation should consume SQS messages, use bounded retries,
dead-letter queues, idempotent upserts, PHI-safe logs, and per-job audit events.
"""
import time

if __name__ == "__main__":
    print("ClinicFlow ETL worker scaffold started; no jobs are configured.")
    while True:
        time.sleep(60)
