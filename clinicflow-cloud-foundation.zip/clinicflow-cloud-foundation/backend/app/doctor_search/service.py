from app.doctor_search.models import DoctorSearchResponse

class DoctorSearchService:
    def __init__(self, planner, directory, web_search):
        self.planner = planner
        self.directory = directory
        self.web_search = web_search

    async def search(self, specialty: str, city: str, state: str, limit: int = 2):
        plan = self.planner.plan(specialty, city, state)
        directory_results = await self.directory.search(plan)
        web_results = await self.web_search.search(plan.web_queries)

        # Merge by NPI where available; otherwise use provider_id. Never invent rankings.
        merged = {}
        for item in directory_results + web_results:
            key = item.npi or item.provider_id
            merged.setdefault(key, item)

        # Ranking is intentionally not enabled until verified data and a scoring policy exist.
        candidates = list(merged.values())[:limit]
        message = (
            "No verified provider results are configured yet."
            if not candidates
            else "Candidates require credential, license and availability verification."
        )
        return DoctorSearchResponse(
            candidates=candidates,
            message=message,
            query_plan=plan,
        ).model_dump()
