from pydantic import BaseModel

class SearchPlan(BaseModel):
    specialty: str
    city: str
    state: str
    web_queries: list[str]

class ProviderCandidate(BaseModel):
    provider_id: str
    display_name: str
    specialty: str
    city: str
    state: str
    npi: str | None = None
    source: str
    source_url: str | None = None
    license_status: str = "unverified"
    next_available_at: str | None = None
    score: float = 0.0
    score_reasons: list[str] = []

class DoctorSearchResponse(BaseModel):
    candidates: list[ProviderCandidate]
    message: str
    query_plan: SearchPlan
