from app.doctor_search.models import ProviderCandidate

class DisabledWebSearch:
    async def search(self, queries: list[str]) -> list[ProviderCandidate]:
        # No fake data and no unconfigured external calls.
        return []
