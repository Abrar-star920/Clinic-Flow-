from app.doctor_search.models import SearchPlan

class RuleQueryPlanner:
    """Safe deterministic planner. Replace/augment with Bedrock structured output later."""
    def plan(self, specialty: str, city: str, state: str) -> SearchPlan:
        specialty = " ".join(specialty.split())[:100]
        city = " ".join(city.split())[:100]
        state = state.upper()
        q = f"{specialty} physician {city} {state}"
        return SearchPlan(
            specialty=specialty,
            city=city,
            state=state,
            web_queries=[q, f"{specialty} specialist {city} {state} NPI"],
        )
