from app.doctor_search.models import ProviderCandidate, SearchPlan

class EmptyDoctorDirectory:
    async def search(self, plan: SearchPlan) -> list[ProviderCandidate]:
        # Replace with an NPI Registry/CMS and curated provider directory adapter.
        return []
