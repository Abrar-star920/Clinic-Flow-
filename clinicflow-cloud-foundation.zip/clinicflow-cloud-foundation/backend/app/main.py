from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from app.settings import settings
from app.doctor_search.service import DoctorSearchService
from app.doctor_search.adapters.disabled_search import DisabledWebSearch
from app.doctor_search.adapters.directory_stub import EmptyDoctorDirectory
from app.doctor_search.adapters.rule_query_planner import RuleQueryPlanner

app = FastAPI(
    title="ClinicFlow API",
    version="0.1.0",
    description="Migration foundation. Not for production PHI or clinical decisions.",
)

search_service = DoctorSearchService(
    planner=RuleQueryPlanner(),
    directory=EmptyDoctorDirectory(),
    web_search=DisabledWebSearch(),
)

class DoctorSearchRequest(BaseModel):
    specialty: str = Field(min_length=2, max_length=100)
    city: str = Field(min_length=2, max_length=100)
    state: str = Field(min_length=2, max_length=2)
    limit: int = Field(default=2, ge=1, le=2)

@app.get("/health")
def health():
    return {"status": "ok", "environment": settings.app_env}

@app.post("/v1/doctor-search")
async def doctor_search(payload: DoctorSearchRequest):
    # Deliberately excludes patient identity, symptoms, DOB and insurance identifiers.
    result = await search_service.search(
        specialty=payload.specialty,
        city=payload.city,
        state=payload.state,
        limit=payload.limit,
    )
    return result

@app.post("/v1/appointments/{provider_id}/book")
async def book_appointment(provider_id: str):
    raise HTTPException(
        status_code=501,
        detail="Booking adapter is not configured. No appointment was created.",
    )

@app.get("/v1/insurance/health")
def insurance_integration_health():
    # Never returns the key or sends a live payer request.
    return {
        "provider": "Stedi",
        "configured": bool(settings.stedi_api_key),
        "mode": "configuration-check-only",
    }
