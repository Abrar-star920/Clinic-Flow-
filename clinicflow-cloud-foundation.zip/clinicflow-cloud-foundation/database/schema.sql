CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS patients (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  external_ref TEXT UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  date_of_birth DATE NOT NULL,
  email TEXT,
  phone TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS doctors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  npi CHAR(10) UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  primary_specialty TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  bio TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS doctor_locations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id UUID NOT NULL REFERENCES doctors(id),
  address_line1 TEXT,
  city TEXT NOT NULL,
  state CHAR(2) NOT NULL,
  postal_code TEXT,
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  is_primary BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS doctor_licenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id UUID NOT NULL REFERENCES doctors(id),
  state CHAR(2) NOT NULL,
  license_number TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'unverified',
  verified_at TIMESTAMPTZ,
  verification_source TEXT,
  UNIQUE (doctor_id, state, license_number)
);

CREATE TABLE IF NOT EXISTS doctor_payers (
  doctor_id UUID NOT NULL REFERENCES doctors(id),
  payer_code TEXT NOT NULL,
  plan_name TEXT,
  effective_from DATE,
  effective_to DATE,
  PRIMARY KEY (doctor_id, payer_code, plan_name)
);

CREATE TABLE IF NOT EXISTS appointment_slots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id UUID NOT NULL REFERENCES doctors(id),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('available','held','booked','cancelled')),
  hold_expires_at TIMESTAMPTZ,
  UNIQUE (doctor_id, starts_at)
);

CREATE TABLE IF NOT EXISTS appointments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id),
  doctor_id UUID NOT NULL REFERENCES doctors(id),
  slot_id UUID NOT NULL UNIQUE REFERENCES appointment_slots(id),
  status TEXT NOT NULL,
  idempotency_key TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS insurance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id),
  payer_id TEXT NOT NULL,
  member_id_ciphertext BYTEA NOT NULL,
  group_number_ciphertext BYTEA,
  coverage_status TEXT,
  last_verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id UUID NOT NULL REFERENCES patients(id),
  payer_id TEXT NOT NULL,
  claim_control_number TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  amount_cents BIGINT NOT NULL CHECK (amount_cents >= 0),
  submission_idempotency_key TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id TEXT,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  outcome TEXT NOT NULL,
  correlation_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_doctor_locations_city_state ON doctor_locations(city, state);
CREATE INDEX IF NOT EXISTS idx_slots_doctor_start ON appointment_slots(doctor_id, starts_at);
CREATE INDEX IF NOT EXISTS idx_claims_patient_created ON claims(patient_id, created_at DESC);
