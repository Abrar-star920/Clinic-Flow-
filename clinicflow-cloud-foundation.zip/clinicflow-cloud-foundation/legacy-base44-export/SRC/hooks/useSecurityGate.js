import { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";

// Polls the vendor security gate (license activation + vault lockdown status).
// On a failed check we keep the last known state — the gate must never
// accidentally open the app because a status probe errored.
export default function useSecurityGate(pollMs = 60000) {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const res = await base44.functions.invoke("securityGate", { action: "status" });
      setStatus(res.data);
    } catch (err) {
      // Keep last known status; retry on next poll.
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const interval = setInterval(refresh, pollMs);
    const onFocus = () => refresh();
    window.addEventListener("focus", onFocus);
    return () => {
      clearInterval(interval);
      window.removeEventListener("focus", onFocus);
    };
  }, [refresh, pollMs]);

  return { status, loading, refresh };
}