import React from "react";
import { Link } from "react-router-dom";
import AuthLayout from "@/components/AuthLayout";
import { Button } from "@/components/ui/button";
import { UserPlus, Lock, ShieldCheck } from "lucide-react";

export default function Register() {
  return (
    <AuthLayout
      icon={UserPlus}
      title="Registration is by invitation only"
      subtitle="ClinicFlow accounts can't be created here."
      footer={
        <>
          Already invited?{" "}
          <Link to="/login" className="text-primary font-medium hover:underline">
            Sign in
          </Link>
        </>
      }
    >
      <div className="flex items-start gap-2 rounded-lg border border-border bg-surface p-4 text-sm text-muted-foreground">
        <Lock className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
        <span>
          To protect patient data, staff access is provisioned exclusively by an
          administrator: an invitation is sent by email, and the application is
          unlocked with the security key provided after purchase. If you need
          access, contact your clinic administrator.
        </span>
      </div>

      <Button asChild variant="outline" className="mt-4 w-full h-12 font-medium">
        <Link to="/login">Go to sign in</Link>
      </Button>

      <div className="mt-4 flex items-center justify-center gap-1.5 text-xs font-medium text-muted-foreground">
        <ShieldCheck className="h-4 w-4 text-primary" aria-hidden="true" />
        HIPAA-aware · Invite-only accounts · Audit logged
      </div>
    </AuthLayout>
  );
}