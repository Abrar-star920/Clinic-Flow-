import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Users, Search, Phone, ShieldCheck, Clock, UserPlus, Filter, AlertTriangle, ChevronRight, PhoneCall } from "lucide-react";
import { cn } from "@/lib/utils";

// Insurance statuses that need front-desk follow-up
const NEEDS_INSURANCE = (status) => status === "pending" || status === "unverified" || status === "denied";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import StatCard from "@/components/StatCard";
import PatientIntakeDialog from "@/components/PatientIntakeDialog";
import PatientIdentificationDialog from "@/components/identification/PatientIdentificationDialog";
import CallerVerificationDialog from "@/components/identification/CallerVerificationDialog";
import Avatar from "@/components/Avatar";
import RpmInsightsWidget from "@/components/insights/RpmInsightsWidget";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Patients() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [insuranceFilter, setInsuranceFilter] = useState("all");
  const [intakeFilter, setIntakeFilter] = useState("all");
  const [intakeOpen, setIntakeOpen] = useState(false);
  const [identifyOpen, setIdentifyOpen] = useState(false);
  const [callerOpen, setCallerOpen] = useState(false);

  useEffect(() => {
    base44.entities.Patient.list("-created_date", 200)
      .then(setPatients)
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    return patients.filter((p) => {
      const q = query.toLowerCase();
      const matchesQuery =
        !q ||
        p.full_name?.toLowerCase().includes(q) ||
        p.phone?.toLowerCase().includes(q) ||
        p.insurance_provider?.toLowerCase().includes(q);
      const matchesIns = insuranceFilter === "all" || p.insurance_status === insuranceFilter;
      const matchesIntake = intakeFilter === "all" || p.intake_status === intakeFilter;
      return matchesQuery && matchesIns && matchesIntake;
    });
  }, [patients, query, insuranceFilter, intakeFilter]);

  const counts = useMemo(
    () => ({
      total: patients.length,
      verified: patients.filter((p) => p.insurance_status === "verified").length,
      pending: patients.filter((p) => p.insurance_status === "pending").length,
      checkedIn: patients.filter((p) => p.intake_status === "checked_in" || p.intake_status === "in_room").length,
    }),
    [patients]
  );

  async function verifyInsurance(id) {
    await base44.entities.Patient.update(id, { insurance_status: "verified" });
    setPatients((prev) => prev.map((p) => (p.id === id ? { ...p, insurance_status: "verified" } : p)));
    const p = patients.find((x) => x.id === id);
    try {
      await base44.entities.AuditLog.create({
        entity_type: "Patient",
        entity_id: id,
        patient_id: id,
        patient_name: p?.full_name,
        action: "status_change",
        actor_email: "staff",
        summary: `Insurance status verified for ${p?.full_name || "patient"}`,
      });
    } catch { /* non-blocking */ }
  }

  async function setIntake(id, status) {
    await base44.entities.Patient.update(id, { intake_status: status });
    setPatients((prev) => prev.map((p) => (p.id === id ? { ...p, intake_status: status } : p)));
  }

  return (
    <div>
      <PageHeader
        title="Patients"
        subtitle="Manage intake, demographics, and insurance verification"
        icon={Users}
        actions={
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setCallerOpen(true)}>
              <PhoneCall className="h-4 w-4" /> Verify Caller
            </Button>
            <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setIdentifyOpen(true)}>
              <Search className="h-4 w-4" /> Identify Patient
            </Button>
            <Button size="sm" variant="gold" className="gap-1.5" onClick={() => setIntakeOpen(true)}>
              <UserPlus className="h-4 w-4" /> New Patient
            </Button>
          </div>
        }
      />

      <div className="space-y-6 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard label="Total Patients" value={counts.total} icon={Users} accent="sky" />
          <StatCard label="Insurance Verified" value={counts.verified} icon={ShieldCheck} accent="emerald" />
          <StatCard label="Pending Verification" value={counts.pending} icon={Clock} accent="amber" />
          <StatCard label="Currently In Clinic" value={counts.checkedIn} icon={UserPlus} accent="gold" />
        </div>

        <RpmInsightsWidget />

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search by name, phone, or insurer…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={insuranceFilter} onValueChange={setInsuranceFilter}>
              <SelectTrigger className="w-[170px]">
                <SelectValue placeholder="Insurance" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Insurance</SelectItem>
                <SelectItem value="verified">Verified</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="unverified">Unverified</SelectItem>
                <SelectItem value="denied">Denied</SelectItem>
              </SelectContent>
            </Select>
            <Select value={intakeFilter} onValueChange={setIntakeFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Intake" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Intake</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="checked_in">Checked In</SelectItem>
                <SelectItem value="in_room">In Room</SelectItem>
                <SelectItem value="checked_out">Checked Out</SelectItem>
                <SelectItem value="no_show">No Show</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-muted/50 text-left text-[11px] uppercase tracking-[0.1em] text-muted-foreground">
                <th className="px-6 py-3.5 font-semibold">Patient</th>
                <th className="px-6 py-3.5 font-semibold">DOB</th>
                <th className="px-6 py-3.5 font-semibold">Insurance</th>
                <th className="px-6 py-3.5 font-semibold">Intake</th>
                <th className="px-6 py-3.5 font-semibold">Reason</th>
                <th className="px-6 py-3.5 font-semibold">Chart</th>
                <th className="px-6 py-3.5 text-right font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-muted-foreground">Loading patients…</td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-5 py-10 text-center text-muted-foreground">No patients match your filters.</td>
                </tr>
              )}
              {filtered.map((p) => {
                const flag = NEEDS_INSURANCE(p.insurance_status);
                return (
                <tr key={p.id} className={cn("transition-colors hover:bg-muted/40", flag && "bg-rose-50/60 hover:bg-rose-100/70")}>
                  <td className={cn("px-6 py-4 border-l-4", flag ? "border-l-rose-500" : "border-l-transparent")}>
                    <div className="flex items-center gap-3">
                      <Avatar name={p.full_name} src={p.photo_url} size="md" />
                      <div className="min-w-0">
                        <Link to={`/patients/${p.id}`} className="font-display font-semibold text-foreground hover:text-primary hover:underline">
                          {p.full_name}
                        </Link>
                        <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Phone className="h-3 w-3" /> {p.phone || "—"}
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-muted-foreground">{p.dob || "—"}</td>
                  <td className="px-6 py-4">
                    <div className="mb-1.5 text-xs text-muted-foreground">{p.insurance_provider || "—"}</div>
                    <div className="flex items-center gap-1.5">
                      <StatusBadge status={p.insurance_status} />
                      {flag && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white shadow-sm">
                          <AlertTriangle className="h-3 w-3" /> Action needed
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={p.intake_status} />
                  </td>
                  <td className="px-6 py-4 max-w-[220px] truncate text-muted-foreground">{p.reason_for_visit || "—"}</td>
                  <td className="px-6 py-4 text-right">
                    <Link to={`/patients/${p.id}`} className="inline-flex items-center gap-0.5 text-xs font-semibold text-primary hover:underline">
                      Chart <ChevronRight className="h-3.5 w-3.5" />
                    </Link>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      {p.insurance_status !== "verified" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 gap-1.5 text-xs"
                          onClick={() => verifyInsurance(p.id)}
                        >
                          <ShieldCheck className="h-3.5 w-3.5" /> Verify
                        </Button>
                      )}
                      <Select value={p.intake_status} onValueChange={(v) => setIntake(p.id, v)}>
                        <SelectTrigger className="h-7 w-[130px] text-xs">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="new">New</SelectItem>
                          <SelectItem value="checked_in">Check In</SelectItem>
                          <SelectItem value="in_room">In Room</SelectItem>
                          <SelectItem value="checked_out">Check Out</SelectItem>
                          <SelectItem value="no_show">No Show</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </td>
                </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <PatientIntakeDialog
          open={intakeOpen}
          onOpenChange={setIntakeOpen}
          onCreated={(p) => setPatients((prev) => [p, ...prev])}
        />
        <CallerVerificationDialog
          open={callerOpen}
          onOpenChange={setCallerOpen}
          onIdentifyPatient={() => setIdentifyOpen(true)}
        />
        <PatientIdentificationDialog open={identifyOpen} onOpenChange={setIdentifyOpen} />
      </div>
    </div>
  );
}