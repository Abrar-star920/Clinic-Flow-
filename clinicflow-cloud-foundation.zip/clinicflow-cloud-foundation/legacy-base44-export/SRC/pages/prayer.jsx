import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Plus, Pencil, Trash2, Loader2, CheckCircle2, XCircle } from "lucide-react";
import PayerDialog from "@/components/assistant/PayerDialog";
import { useToast } from "@/components/ui/use-toast";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

function Support({ on }) {
  return on
    ? <CheckCircle2 className="h-4 w-4 text-success" />
    : <XCircle className="h-4 w-4 text-muted-foreground/40" />;
}

export default function Payers() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [payers, setPayers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const isAdmin = user?.role === "admin";

  function load() {
    setLoading(true);
    base44.entities.Payer.filter({}, { sort: "payer_name", limit: 200 })
      .then(({ items }) => setPayers(items))
      .finally(() => setLoading(false));
  }

  useEffect(() => { load(); }, []);

  async function remove(p) {
    try {
      await base44.entities.Payer.delete(p.id);
      toast({ title: "Payer deleted" });
      load();
    } catch (e) {
      toast({ variant: "destructive", title: "Delete failed", description: e.message });
    }
  }

  return (
    <div>
      <PageHeader
        title="Payers"
        subtitle="Manage insurance payers and their Stedi clearinghouse capabilities."
        icon={Plus}
        actions={
          <Button onClick={() => { setEditing(null); setDialogOpen(true); }}>
            <Plus className="h-4 w-4" /> Add payer
          </Button>
        }
      />

      <div className="p-6 sm:p-8">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : payers.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-12 text-center">
            <p className="text-sm text-muted-foreground">No payers yet. Add your first insurance payer to enable eligibility and claims.</p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
            <table className="w-full text-sm">
              <thead className="bg-surface text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-semibold">Payer</th>
                  <th className="px-4 py-3 font-semibold">Stedi ID</th>
                  <th className="px-4 py-3 text-center font-semibold">Eligibility</th>
                  <th className="px-4 py-3 text-center font-semibold">Claim status</th>
                  <th className="px-4 py-3 text-center font-semibold">837P</th>
                  <th className="px-4 py-3 text-right font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {payers.map((p) => (
                  <tr key={p.id} className="hover:bg-surface/50">
                    <td className="px-4 py-3 font-medium text-foreground">{p.payer_name}</td>
                    <td className="px-4 py-3 text-muted-foreground">{p.stedi_payer_id}</td>
                    <td className="px-4 py-3 text-center"><Support on={p.supports_eligibility} /></td>
                    <td className="px-4 py-3 text-center"><Support on={p.supports_claim_status} /></td>
                    <td className="px-4 py-3 text-center"><Support on={p.supports_professional_claims} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => { setEditing(p); setDialogOpen(true); }} className="rounded-lg p-1.5 text-muted-foreground hover:bg-muted hover:text-foreground">
                          <Pencil className="h-4 w-4" />
                        </button>
                        {isAdmin && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <button className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/5 hover:text-destructive">
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete {p.payer_name}?</AlertDialogTitle>
                                <AlertDialogDescription>This payer will no longer be available for eligibility or claims.</AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => remove(p)}>Delete</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <PayerDialog payer={editing} open={dialogOpen} onOpenChange={setDialogOpen} onSaved={load} />
    </div>
  );
}