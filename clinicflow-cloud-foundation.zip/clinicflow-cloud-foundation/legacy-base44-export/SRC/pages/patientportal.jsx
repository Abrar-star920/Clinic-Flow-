import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Activity, Bot, CalendarClock, CreditCard, ShieldCheck, Phone, MapPin, Clock, UserRound, MessageSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";
import PortalConcierge from "@/components/portal/PortalConcierge";
import ScheduleForm from "@/components/portal/ScheduleForm";
import PayBill from "@/components/portal/PayBill";
import InsuranceFinder from "@/components/portal/InsuranceFinder";
import MyRecords from "@/components/portal/MyRecords";
import PortalMessages from "@/components/portal/PortalMessages";
import { useToast } from "@/components/ui/use-toast";

const TABS = [
  { id: "records", label: "My Records", icon: UserRound },
  { id: "concierge", label: "AI Receptionist", icon: Bot },
  { id: "schedule", label: "Schedule", icon: CalendarClock },
  { id: "insurance", label: "Insurance", icon: ShieldCheck },
  { id: "pay", label: "Pay a Bill", icon: CreditCard },
  { id: "messages", label: "Messages", icon: MessageSquare },
];

export default function PatientPortalPublic() {
  const { toast } = useToast();
  const [tab, setTab] = useState("records");
  const [patientContext, setPatientContext] = useState({});

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get("paid")) toast({ title: "Payment received", description: "Thank you — your invoice is paid." });
    if (params.get("cancelled")) toast({ variant: "destructive", title: "Payment cancelled" });
    if (params.get("paid") || params.get("cancelled")) {
      window.history.replaceState({}, "", window.location.pathname);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50/70 via-background to-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <Link to="/concierge" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-400 to-sky-600 text-white shadow-soft">
              <Activity className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <div className="font-display text-[15px] font-bold tracking-tight text-foreground">ClinicFlow</div>
              <div className="text-[11px] font-medium text-muted-foreground">Patient Portal</div>
            </div>
          </Link>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Link to="/assistant" className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 font-medium text-primary-foreground hover:bg-primary/90">
              <Bot className="h-4 w-4" /> Patient Assistant
            </Link>
            <Link to="/login" className="rounded-lg px-3 py-1.5 font-medium text-foreground hover:bg-muted">
              Staff sign in
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 py-8">
        {/* Hero */}
        <div className="rounded-2xl border border-border bg-gradient-to-r from-sky-50/80 to-teal-50/40 p-6 shadow-soft sm:p-8">
          <div className="inline-flex items-center gap-1.5 rounded-full border border-sky-200 bg-card px-3 py-1 text-xs font-semibold text-primary shadow-sm">
            <Bot className="h-3.5 w-3.5" /> Self-service, 24/7
          </div>
          <h1 className="mt-4 font-display text-2xl font-extrabold tracking-tight text-foreground sm:text-3xl">
            Your care, on your schedule.
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Book an appointment, verify your insurance, chat with our AI receptionist, and pay your bill — no login required.
          </p>
          <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><Phone className="h-3.5 w-3.5" /> (555) 200-1000</span>
            <span className="inline-flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" /> Mon–Fri, 8am–6pm</span>
            <span className="inline-flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> 100 Wellness Way, Suite 200</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-6 flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-colors",
                tab === t.id
                  ? "border-primary bg-primary text-primary-foreground shadow-soft"
                  : "border-border bg-card text-foreground hover:bg-muted"
              )}
            >
              <t.icon className="h-4 w-4" /> {t.label}
            </button>
          ))}
        </div>

        {/* Panel */}
        <div className="mt-5">
          {tab === "records" && <MyRecords onSession={setPatientContext} />}
          {tab === "concierge" && <PortalConcierge patientContext={patientContext} />}
          {tab === "schedule" && <ScheduleForm />}
          {tab === "insurance" && <InsuranceFinder onResolved={setPatientContext} />}
          {tab === "pay" && <PayBill />}
          {tab === "messages" && <PortalMessages />}
        </div>
      </main>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        ClinicFlow Patient Portal · For emergencies call 911
      </footer>
    </div>
  );
}