import React from "react";
import { Link } from "react-router-dom";
import {
  Activity, Bot, Clock, ShieldCheck, PhoneCall, MessageSquare, CalendarClock,
  Phone, FileText, Pill, Stethoscope, CheckCircle2, ArrowRight, Sparkles,
} from "lucide-react";
import ConciergeChat from "@/components/concierge/ConciergeChat";
import { Button } from "@/components/ui/button";

const STATS = [
  { value: "89%", label: "Reduction in hold time" },
  { value: "3.5x", label: "Higher self-scheduling" },
  { value: "24/7", label: "Always on" },
  { value: "0", label: "Missed calls" },
];

const FEATURES = [
  { icon: Clock, title: "Always On", text: "Every inbound call answered, every request completed, 24/7. No hold times, after-hours gaps, or staff intervention." },
  { icon: ShieldCheck, title: "Specialty-Built", text: "Trained on millions of patient interactions across specialties — masters complex scheduling logic and protocols from day one." },
  { icon: Activity, title: "EHR-Native", text: "Every action syncs directly back to your records in real time: appointments booked, tasks created, records updated." },
];

const STEPS = [
  { icon: PhoneCall, title: "Call Answered, Instantly", text: "The Concierge agent answers the patient's call immediately to help them." },
  { icon: FileText, title: "Patient Information Captured", text: "The agent captures necessary info, pulls up their chart, and writes new details into the record." },
  { icon: Sparkles, title: "Request Understood", text: "The agent identifies multiple needs — scheduling, refills, triage — in a single conversation." },
  { icon: CalendarClock, title: "Appointment Booked", text: "Checks real-time availability, applies provider rules, and books the appointment directly." },
  { icon: Pill, title: "Prescription Refill Submitted", text: "Generates a task for the provider to review and action the refill — no staff involvement." },
  { icon: CheckCircle2, title: "Confirmed, Loop Closed", text: "The patient receives an immediate text confirmation; tasks are queued for the team." },
];

const CHANNELS = [
  { icon: PhoneCall, title: "Phone", text: "Voice AI agents answer every call and complete the task on the spot." },
  { icon: MessageSquare, title: "Chatbot", text: "AI agents chat with patients directly from your website and close the loop." },
  { icon: CalendarClock, title: "Online Scheduling", text: "Patients self-serve to schedule with the same accuracy as calling in." },
];

export default function Concierge() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-background to-background">
      {/* Nav */}
      <header className="border-b border-border bg-card/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-400 to-sky-500 text-white shadow-sm">
              <Activity className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <div className="font-display text-[15px] font-bold tracking-tight text-foreground">ClinicFlow</div>
              <div className="text-[11px] font-medium text-muted-foreground">AI Concierge</div>
            </div>
          </div>
          <Link to="/login">
            <Button variant="outline" size="sm">Sign in</Button>
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto max-w-6xl px-5 py-16 text-center">
        <div className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs font-semibold text-primary shadow-sm">
          <Bot className="h-3.5 w-3.5" /> Introducing ClinicFlow Concierge
        </div>
        <h1 className="mx-auto mt-5 max-w-3xl font-display text-4xl font-extrabold tracking-tight text-foreground sm:text-5xl">
          AI Agents for Every Patient Interaction
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
          Concierge handles every inbound call, chat, and scheduling request, 24/7, and syncs every detail back to your records — so nothing slips and your front office gets time back.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <Link to="/portal">
            <Button size="lg" className="gap-2">Patient Portal <ArrowRight className="h-4 w-4" /></Button>
          </Link>
          <a href="#demo">
            <Button size="lg" variant="outline">See how it works</Button>
          </a>
        </div>

        <div className="mt-12 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <div className="font-display text-2xl font-extrabold text-primary">{s.value}</div>
              <div className="mt-1 text-xs font-medium text-muted-foreground">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Problem */}
      <section className="mx-auto max-w-6xl px-5 py-12">
        <div className="rounded-2xl border border-border bg-card p-8 shadow-sm">
          <h2 className="text-center font-display text-2xl font-bold text-foreground">Your staffing model can't keep up.</h2>
          <p className="mx-auto mt-2 max-w-2xl text-center text-sm text-muted-foreground">Call volume keeps climbing. Staff bandwidth doesn't. The result is missed calls, delayed care, and a front office too overwhelmed to support growth.</p>
          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {[
              { title: "Busiest hours are your biggest liability", text: "Requests come in across every channel, all at once. Something slips." },
              { title: "Missed calls become missed patients", text: "Patients who can't get through don't wait — they disengage." },
              { title: "You can't grow what you can't staff", text: "Adding patients shouldn't mean being held hostage to hiring." },
            ].map((c) => (
              <div key={c.title} className="rounded-xl border border-border bg-background/50 p-5">
                <div className="font-display text-sm font-bold text-foreground">{c.title}</div>
                <p className="mt-2 text-sm text-muted-foreground">{c.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-5 py-12">
        <h2 className="text-center font-display text-2xl font-bold text-foreground">No missed calls. No overwhelmed staff. No manual data entry.</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-xl border border-border bg-card p-6 shadow-sm">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-accent-foreground">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-base font-bold text-foreground">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Demo chat */}
      <section id="demo" className="mx-auto max-w-6xl px-5 py-12">
        <div className="grid items-center gap-8 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-2xl font-bold text-foreground">Try the Concierge yourself</h2>
            <p className="mt-3 text-sm text-muted-foreground">
              This is a live AI assistant. Ask it to book an appointment, request a refill, or ask an insurance question — just like a patient would on your website.
            </p>
            <div className="mt-6 space-y-3">
              {CHANNELS.map((c) => (
                <div key={c.title} className="flex items-start gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <c.icon className="h-4 w-4" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-foreground">{c.title}</div>
                    <div className="text-xs text-muted-foreground">{c.text}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <ConciergeChat variant="embedded" />
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-6xl px-5 py-12">
        <h2 className="text-center font-display text-2xl font-bold text-foreground">From first call to final confirmation</h2>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((s, i) => (
            <div key={s.title} className="relative rounded-xl border border-border bg-card p-5 shadow-sm">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-bold">{i + 1}</div>
                <s.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="mt-3 font-display text-sm font-bold text-foreground">{s.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-5 py-16">
        <div className="overflow-hidden rounded-2xl bg-gradient-to-r from-teal-500 to-sky-600 p-8 text-center text-white shadow-lg sm:p-12">
          <h2 className="font-display text-2xl font-extrabold sm:text-3xl">Less overhead. More appointments. No missed calls.</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-sky-50">See how ClinicFlow Concierge handles every inbound interaction — and gives your front office time back.</p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <Link to="/login">
              <Button size="lg" variant="secondary" className="gap-2">Get started <ArrowRight className="h-4 w-4" /></Button>
            </Link>
            <a href="#demo">
              <Button size="lg" variant="outline" className="border-white/40 bg-white/10 text-white hover:bg-white/20 hover:text-white">Try the demo</Button>
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-xs text-muted-foreground">
        ClinicFlow · AI Concierge for modern medical practices
      </footer>
    </div>
  );
}