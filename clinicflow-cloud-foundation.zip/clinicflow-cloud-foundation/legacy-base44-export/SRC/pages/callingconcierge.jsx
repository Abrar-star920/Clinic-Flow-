import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { Headset, PhoneCall, Loader2, AlertTriangle, CalendarPlus, Save, Sparkles, Phone } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const SAMPLES = [
  {
    caller_name: "Margaret Lowe",
    phone: "(555) 412-7788",
    transcript: "Hi, I've had a severe headache for three days and my vision is a little blurry. I take blood pressure medication. Can someone see me today? I'm worried it might be serious.",
  },
  {
    caller_name: "James Carter",
    phone: "(555) 881-2200",
    transcript: "Hello, I'd like to book a follow-up appointment with Dr. Chen next week, preferably Tuesday morning. Also, I need a refill on my lisinopril.",
  },
  {
    caller_name: "Priya Shah",
    phone: "(555) 339-0091",
    transcript: "I got a bill and my insurance was supposed to cover it. Can someone check my coverage before I pay?",
  },
];

export default function CallConcierge() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState({ caller_name: "", phone: "", transcript: "" });
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [acting, setActing] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function analyze(e) {
    e?.preventDefault();
    if (!form.transcript.trim()) return toast({ variant: "destructive", title: "Enter a call transcript" });
    setAnalyzing(true);
    setResult(null);
    try {
      const { data } = await base44.functions.invoke("triageCall", form);
      setResult(data);
    } catch (err) {
      toast({ variant: "destructive", title: "Analysis failed", description: err?.message });
    } finally {
      setAnalyzing(false);
    }
  }

  async function act(action) {
    setActing(action);
    try {
      if (action === "log") {
        await base44.entities.CallLog.create({
          caller_name: form.caller_name || "Unknown",
          phone: form.phone || undefined,
          reason: result.call_reason || "other",
          status: "answered",
          summary: result.summary,
          handled_by: "AI Concierge",
          received_at: new Date().toISOString(),
          duration_seconds: 0,
        });
        toast({ title: "Call log saved" });
      } else if (action === "escalate") {
        await base44.entities.Escalation.create({
          caller_name: form.caller_name || "Unknown",
          phone: form.phone || undefined,
          reason: "urgent_medical",
          priority: result.urgency === "critical" ? "critical" : result.urgency === "high" ? "high" : "medium",
          status: "open",
          notes: `${result.escalation_reason || result.summary} (via AI Concierge)`,
          created_at: new Date().toISOString(),
        });
        toast({ title: "Escalation created", description: "Routed to clinical staff." });
      } else if (action === "schedule" && result.suggested_appointment) {
        const a = result.suggested_appointment;
        await base44.entities.Appointment.create({
          patient_name: form.caller_name || "Unknown",
          patient_email: "",
          appointment_date: a.date,
          appointment_time: a.time,
          duration_minutes: 30,
          provider: a.provider || "Dr. A. Reyes",
          type: a.type || "follow_up",
          status: "scheduled",
        });
        toast({ title: "Appointment booked", description: `${a.date} ${a.time} · ${a.provider}` });
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Action failed", description: err?.message });
    } finally {
      setActing(false);
    }
  }

  function loadSample(i) {
    setForm(SAMPLES[i]);
    setResult(null);
  }

  return (
    <div>
      <PageHeader
        title="AI Call Concierge"
        subtitle="Simulate an inbound patient call — the AI triages, summarizes, and recommends next actions"
        icon={Headset}
        actions={
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => loadSample(0)}>
            <Sparkles className="h-4 w-4" /> Sample call
          </Button>
        }
      />

      <div className="grid gap-5 p-6 lg:grid-cols-2 sm:p-8">
        {/* Call input */}
        <div className="space-y-4">
          <form onSubmit={analyze} className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label>Caller Name</Label>
                <Input value={form.caller_name} onChange={(e) => set("caller_name", e.target.value)} placeholder="e.g. Margaret Lowe" />
              </div>
              <div className="space-y-1.5">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="(555) 000-0000" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Caller says (transcript)</Label>
              <Textarea rows={6} value={form.transcript} onChange={(e) => set("transcript", e.target.value)} placeholder="Type or paste what the caller said…" />
            </div>
            <div className="flex items-center gap-2">
              <Button type="submit" variant="gold" disabled={analyzing} className="gap-1.5">
                {analyzing ? <Loader2 className="h-4 w-4 animate-spin" /> : <PhoneCall className="h-4 w-4" />}
                {analyzing ? "Analyzing…" : "Analyze Call"}
              </Button>
              <Button type="button" variant="ghost" size="sm" onClick={() => { setForm({ caller_name: "", phone: "", transcript: "" }); setResult(null); }}>
                Clear
              </Button>
            </div>
          </form>

          <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Quick scenarios</div>
            <div className="mt-2 space-y-2">
              {SAMPLES.map((s, i) => (
                <button key={i} onClick={() => loadSample(i)} className="block w-full rounded-lg border border-border bg-background/50 px-3 py-2 text-left text-xs text-foreground transition-colors hover:bg-accent">
                  <span className="font-semibold">{s.caller_name}</span> — {s.transcript.slice(0, 70)}…
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Result */}
        <div className="space-y-4">
          {!result && !analyzing && (
            <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 py-16 text-center">
              <Phone className="h-8 w-8 text-muted-foreground/50" />
              <p className="mt-3 max-w-xs text-sm text-muted-foreground">Enter a caller transcript and analyze to see the AI triage summary and recommended actions.</p>
            </div>
          )}

          {analyzing && (
            <div className="flex flex-col items-center justify-center rounded-xl border border-border bg-card py-16 text-center">
              <Loader2 className="h-7 w-7 animate-spin text-primary" />
              <p className="mt-3 text-sm text-muted-foreground">Concierge is listening and triaging…</p>
            </div>
          )}

          {result && (
            <>
              <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-center justify-between">
                  <h3 className="font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">Triage Summary</h3>
                  <StatusBadge status={result.urgency} />
                </div>
                <p className="mt-3 text-sm leading-relaxed text-foreground">{result.summary}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {(result.intents || []).map((it) => (
                    <span key={it} className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-medium text-muted-foreground">{it.replace(/_/g, " ")}</span>
                  ))}
                </div>
              </div>

              {result.suggested_appointment && (
                <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
                  <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Suggested Appointment</div>
                  <div className="mt-2 text-sm text-foreground">
                    {result.suggested_appointment.provider} · {result.suggested_appointment.type?.replace(/_/g, " ")}<br />
                    {result.suggested_appointment.date} at {result.suggested_appointment.time}
                  </div>
                </div>
              )}

              {result.create_escalation && (
                <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 p-4">
                  <AlertTriangle className="mt-0.5 h-4 w-4 text-amber-600" />
                  <div className="text-sm text-amber-800">
                    <div className="font-semibold">Escalation recommended</div>
                    <p className="mt-0.5">{result.escalation_reason || "This call may require clinical attention."}</p>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                <Button size="sm" className="gap-1.5" disabled={!!acting} onClick={() => act("log")}>
                  {acting === "log" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save Call Log
                </Button>
                {result.suggested_appointment && (
                  <Button size="sm" variant="secondary" className="gap-1.5" disabled={!!acting} onClick={() => act("schedule")}>
                    {acting === "schedule" ? <Loader2 className="h-4 w-4 animate-spin" /> : <CalendarPlus className="h-4 w-4" />} Book Appointment
                  </Button>
                )}
                {result.create_escalation && (
                  <Button size="sm" variant="destructive" className="gap-1.5" disabled={!!acting} onClick={() => act("escalate")}>
                    {acting === "escalate" ? <Loader2 className="h-4 w-4 animate-spin" /> : <AlertTriangle className="h-4 w-4" />} Create Escalation
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}