import React, { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard, CalendarClock, UserCheck, AlertTriangle, ListChecks,
  ShieldQuestion, DollarSign, ArrowRight, Clock, Stethoscope,
} from "lucide-react";
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
} from "recharts";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import StatusBadge from "@/components/StatusBadge";
import { cn } from "@/lib/utils";

const PRIORITY_RANK = { urgent: 0, high: 1, medium: 2, low: 3 };
const PRIORITY_TONE = {
  urgent: "bg-rose-100 text-rose-700",
  high: "bg-amber-100 text-amber-700",
  medium: "bg-sky-100 text-sky-700",
  low: "bg-slate-100 text-slate-600",
};
const STATUS_COLORS = {
  scheduled: "hsl(var(--chart-4))",
  confirmed: "hsl(var(--chart-3))",
  checked_in: "hsl(var(--chart-2))",
  in_progress: "hsl(var(--chart-1))",
  completed: "hsl(var(--chart-5))",
  cancelled: "hsl(0 0% 70%)",
  no_show: "hsl(var(--destructive))",
};

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [appointments, setAppointments] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [escalations, setEscalations] = useState([]);
  const [stats, setStats] = useState({
    appointmentsToday: 0,
    inOffice: 0,
    openEscalations: 0,
    openTasks: 0,
    pendingInsurance: 0,
    outstandingRevenue: 0,
  });

  const today = new Date().toLocaleDateString("en-CA");
  const todayLabel = new Date().toLocaleDateString("en-US", {
    weekday: "long", month: "long", day: "numeric",
  });

  useEffect(() => {
    async function load() {
      const [apptPage, taskPage, escPage, openEscCount, openTaskCount, pendingIns, rev] = await Promise.all([
        base44.entities.Appointment.filter({ appointment_date: today }, { sort: "appointment_time", limit: 100 }).then((p) => p.items).catch(() => []),
        base44.entities.Task.filter({ status: { $in: ["open", "in_progress", "blocked"] } }, { sort: "-created_date", limit: 6 }).then((p) => p.items).catch(() => []),
        base44.entities.Escalation.filter({ status: { $in: ["open", "in_progress", "waiting"] } }, { sort: "-created_date", limit: 5 }).then((p) => p.items).catch(() => []),
        base44.entities.Escalation.count({ status: { $in: ["open", "in_progress", "waiting"] } }).catch(() => 0),
        base44.entities.Task.count({ status: { $in: ["open", "in_progress", "blocked"] } }).catch(() => 0),
        base44.entities.Patient.count({ insurance_status: { $in: ["pending", "unverified", "denied"] } }).catch(() => 0),
        base44.entities.Claim.aggregate({
          query: { status: { $in: ["ready", "submitted", "partially_paid", "on_hold"] } },
          sum: "amount",
        }).catch(() => ({ rows: [] })),
      ]);

      setAppointments(apptPage);
      setTasks(taskPage.sort((a, b) => (PRIORITY_RANK[a.priority] ?? 9) - (PRIORITY_RANK[b.priority] ?? 9)));
      setEscalations(escPage);
      setStats({
        appointmentsToday: apptPage.length,
        inOffice: apptPage.filter((a) => a.status === "checked_in" || a.status === "in_progress").length,
        openEscalations: openEscCount,
        openTasks: openTaskCount,
        pendingInsurance: pendingIns,
        outstandingRevenue: rev.rows?.[0]?.sum_amount || 0,
      });
      setLoading(false);
    }
    load();
  }, [today]);

  const byProvider = useMemo(() => {
    const map = new Map();
    appointments.forEach((a) => {
      const key = a.provider || "Unassigned";
      if (!map.has(key)) map.set(key, []);
      map.get(key).push(a);
    });
    return Array.from(map.entries());
  }, [appointments]);

  const statusData = useMemo(() => {
    const counts = {};
    appointments.forEach((a) => { counts[a.status] = (counts[a.status] || 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [appointments]);

  const fmtMoney = (n) => (n >= 1000 ? `$${(n / 1000).toFixed(1)}k` : `$${n.toFixed(0)}`);

  return (
    <div>
      <PageHeader
        title="Dashboard"
        subtitle={todayLabel}
        icon={LayoutDashboard}
        actions={
          <Link to="/scheduling" className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline">
            Open scheduler <ArrowRight className="h-4 w-4" />
          </Link>
        }
      />

      <div className="space-y-6 p-6 sm:p-8">
        {/* Stat cards */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
          <StatCard label="Appts today" value={stats.appointmentsToday} icon={CalendarClock} accent="sky" hint={stats.inOffice ? `${stats.inOffice} in office now` : "—"} />
          <StatCard label="In office" value={stats.inOffice} icon={UserCheck} accent="teal" hint="Checked in / in progress" />
          <StatCard label="Open tasks" value={stats.openTasks} icon={ListChecks} accent="indigo" hint="Work queue" />
          <StatCard label="Escalations" value={stats.openEscalations} icon={AlertTriangle} accent="rose" hint="Needs attention" />
          <StatCard label="Insurance" value={stats.pendingInsurance} icon={ShieldQuestion} accent="amber" hint="Pending / unverified" />
          <StatCard label="Outstanding" value={fmtMoney(stats.outstandingRevenue)} icon={DollarSign} accent="gold" hint="Unpaid claims" />
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Today by provider */}
          <section className="lg:col-span-2 rounded-2xl border border-border bg-card p-5 shadow-soft">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-bold tracking-tight text-foreground">Today’s schedule by provider</h2>
              <span className="text-xs font-medium text-muted-foreground">{appointments.length} appointments</span>
            </div>
            {loading ? (
              <div className="space-y-3">
                {[0, 1, 2].map((i) => <div key={i} className="h-20 animate-pulse rounded-xl bg-muted" />)}
              </div>
            ) : byProvider.length === 0 ? (
              <EmptyState icon={CalendarClock} text="No appointments scheduled for today." />
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {byProvider.map(([provider, list]) => (
                  <div key={provider} className="rounded-xl border border-border bg-surface/60 p-4">
                    <div className="mb-3 flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent text-primary">
                        <Stethoscope className="h-4 w-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="truncate text-sm font-semibold text-foreground">{provider}</div>
                        <div className="text-[11px] text-muted-foreground">{list.length} {list.length === 1 ? "appt" : "appts"}</div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {list.map((a) => (
                        <div key={a.id} className="flex items-center justify-between gap-2 rounded-lg bg-card px-3 py-2 ring-1 ring-border/60">
                          <div className="min-w-0">
                            <div className="truncate text-[13px] font-medium text-foreground">{a.patient_name}</div>
                            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                              <Clock className="h-3 w-3" /> {a.appointment_time || "—"} · {a.type?.replace("_", " ")}
                            </div>
                          </div>
                          <StatusBadge status={a.status} kind="appointment" className="shrink-0" />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Work queue */}
          <section className="rounded-2xl border border-border bg-card p-5 shadow-soft">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-bold tracking-tight text-foreground">Work queue</h2>
              <Link to="/tasks" className="text-xs font-medium text-primary hover:underline">View all</Link>
            </div>
            {loading ? (
              <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-muted" />)}</div>
            ) : tasks.length === 0 ? (
              <EmptyState icon={ListChecks} text="No open tasks right now." />
            ) : (
              <div className="space-y-2.5">
                {tasks.map((t) => (
                  <Link key={t.id} to="/tasks" className="block rounded-xl border border-border bg-surface/60 p-3 transition-colors hover:border-primary/40 hover:bg-accent/40">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="truncate text-[13px] font-semibold text-foreground">{t.title}</div>
                        <div className="mt-0.5 truncate text-[11px] text-muted-foreground">
                          {t.patient_name || "General"} · {t.task_type?.replace("_", " ")}
                        </div>
                      </div>
                      <span className={cn("shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", PRIORITY_TONE[t.priority] || PRIORITY_TONE.low)}>
                        {t.priority}
                      </span>
                    </div>
                    {t.due_date && (
                      <div className="mt-1.5 flex items-center gap-1 text-[11px] text-muted-foreground">
                        <CalendarClock className="h-3 w-3" /> Due {t.due_date}
                      </div>
                    )}
                  </Link>
                ))}
              </div>
            )}
          </section>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Escalations */}
          <section className="lg:col-span-2 rounded-2xl border border-border bg-card p-5 shadow-soft">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-bold tracking-tight text-foreground">Escalations needing attention</h2>
              <Link to="/escalations" className="text-xs font-medium text-primary hover:underline">View all</Link>
            </div>
            {loading ? (
              <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-muted" />)}</div>
            ) : escalations.length === 0 ? (
              <EmptyState icon={AlertTriangle} text="No active escalations. All clear." />
            ) : (
              <div className="divide-y divide-border">
                {escalations.map((e) => (
                  <Link key={e.id} to="/escalations" className="flex items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-semibold text-foreground">{e.caller_name} · {e.reason?.replace("_", " ")}</div>
                      <div className="truncate text-[11px] text-muted-foreground">{e.category} · {e.ai_summary || e.notes || "No summary"}</div>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <StatusBadge status={e.priority} kind="escalation" />
                      <StatusBadge status={e.status} kind="escalation" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </section>

          {/* Status donut */}
          <section className="rounded-2xl border border-border bg-card p-5 shadow-soft">
            <h2 className="mb-4 font-display text-base font-bold tracking-tight text-foreground">Appointment status</h2>
            {loading ? (
              <div className="h-48 animate-pulse rounded-xl bg-muted" />
            ) : statusData.length === 0 ? (
              <EmptyState icon={CalendarClock} text="No appointments today." />
            ) : (
              <>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={48} outerRadius={72} paddingAngle={2}>
                        {statusData.map((d) => (
                          <Cell key={d.name} fill={STATUS_COLORS[d.name] || "hsl(0 0% 70%)"} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ borderRadius: 12, border: "1px solid hsl(var(--border))", fontSize: 12 }}
                        formatter={(v, n) => [`${v} appt${v === 1 ? "" : "s"}`, n.replace("_", " ")]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5">
                  {statusData.map((d) => (
                    <div key={d.name} className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: STATUS_COLORS[d.name] || "hsl(0 0% 70%)" }} />
                      <span className="capitalize">{d.name.replace("_", " ")}</span>
                      <span className="font-semibold text-foreground">{d.value}</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}

function EmptyState({ icon: Icon, text }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
      <div className="flex h-11 w-11 items-center justify-center rounded-full bg-muted text-muted-foreground">
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-sm text-muted-foreground">{text}</p>
    </div>
  );
}