import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { HeartPulse, Activity, Clock, Plus, Loader2, ChevronRight, AlertTriangle } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import VitalsChart from "@/components/clinical/VitalsChart";
import AlertsPanel, { alertSummary } from "@/components/rpm/AlertsPanel";
import VitalsTrendsWidget from "@/components/rpm/VitalsTrendsWidget";
import LogTimeDialog from "@/components/rpm/LogTimeDialog";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function RpmMonitoring() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [patients, setPatients] = useState([]);
  const [vitals, setVitals] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const load = () =>
    Promise.all([
      base44.entities.Patient.list("-created_date", 300),
      base44.entities.VitalReading.list("-recorded_at", 400),
      base44.entities.RpmSession.list("-recorded_at", 200),
    ])
      .then(([p, v, s]) => {
        setPatients(p);
        setVitals(v);
        setSessions(s);
      })
      .finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const rpmPatients = useMemo(
    () => patients.filter((p) => p.chronic_conditions?.length > 0),
    [patients]
  );

  useEffect(() => {
    if (!selectedId && rpmPatients.length > 0) setSelectedId(rpmPatients[0].id);
  }, [rpmPatients, selectedId]);

  const selected = useMemo(() => patients.find((p) => p.id === selectedId), [patients, selectedId]);

  const selectedVitals = useMemo(
    () => vitals.filter((v) => v.patient_id === selectedId),
    [vitals, selectedId]
  );

  const selectedSessions = useMemo(
    () => sessions.filter((s) => s.patient_id === selectedId),
    [sessions, selectedId]
  );

  const alerts = useMemo(() => alertSummary(selectedVitals), [selectedVitals]);

  const stats = useMemo(() => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const weekAgo = Date.now() - 7 * 86400000;
    const activeAlerts = new Set();
    patients.forEach((p) => {
      const pv = vitals.filter((v) => v.patient_id === p.id);
      const summary = alertSummary(pv);
      if (summary.length) activeAlerts.add(p.id);
    });
    const monthMinutes = sessions
      .filter((s) => (s.recorded_at || "") >= monthStart)
      .reduce((sum, s) => sum + Number(s.minutes || 0), 0);
    const recentReaders = new Set(
      vitals.filter((v) => new Date(v.recorded_at || 0).getTime() >= weekAgo).map((v) => v.patient_id)
    ).size;
    return { enrolled: rpmPatients.length, activeAlerts: activeAlerts.size, monthMinutes, recentReaders };
  }, [patients, vitals, sessions, rpmPatients]);

  return (
    <div>
      <PageHeader
        title="Remote Patient Monitoring"
        subtitle="Vital trends, device alerts, and RPM/CCM time tracking for enrolled patients"
        icon={HeartPulse}
      />

      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Enrolled Patients" value={stats.enrolled} icon={HeartPulse} accent="sky" />
          <StatCard label="Active Alerts" value={stats.activeAlerts} icon={AlertTriangle} accent="rose" />
          <StatCard label="Min This Month" value={stats.monthMinutes} icon={Clock} accent="amber" />
          <StatCard label="Recent Readers" value={stats.recentReaders} icon={Activity} accent="emerald" />
        </div>

        <VitalsTrendsWidget />

        {loading ? (
          <div className="py-16 text-center text-muted-foreground">Loading monitoring data…</div>
        ) : rpmPatients.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card/50 py-12 text-center text-muted-foreground">
            No RPM-eligible patients yet. Add chronic conditions to a patient to enroll them in monitoring.
          </div>
        ) : (
          <div className="grid gap-5 lg:grid-cols-[280px_1fr]">
            {/* Patient list */}
            <div className="rounded-xl border border-border bg-card shadow-sm">
              <div className="border-b border-border px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Enrolled Patients
              </div>
              <ul className="max-h-[560px] divide-y divide-border overflow-y-auto">
                {rpmPatients.map((p) => {
                  const pAlerts = alertSummary(vitals.filter((v) => v.patient_id === p.id));
                  return (
                    <li key={p.id}>
                      <button
                        onClick={() => setSelectedId(p.id)}
                        className={cn(
                          "flex w-full items-center justify-between gap-2 px-4 py-3 text-left transition-colors",
                          selectedId === p.id ? "bg-accent/60" : "hover:bg-muted/50"
                        )}
                      >
                        <div className="min-w-0">
                          <div className="truncate text-sm font-semibold text-foreground">{p.full_name}</div>
                          <div className="truncate text-xs text-muted-foreground">{p.chronic_conditions?.join(", ")}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          {pAlerts.length > 0 && (
                            <span className="rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-bold text-rose-700">{pAlerts.length}</span>
                          )}
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        </div>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Detail */}
            <div className="space-y-4">
              {selected && (
                <>
                  <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <div className="font-display text-lg font-bold text-foreground">{selected.full_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {selected.chronic_conditions?.join(" · ") || "No chronic conditions"}
                      </div>
                    </div>
                    <Button size="sm" variant="gold" className="h-8 gap-1.5 text-xs" onClick={() => setDialogOpen(true)}>
                      <Plus className="h-3.5 w-3.5" /> Log Monitoring Time
                    </Button>
                  </div>

                  <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
                    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
                      <h3 className="mb-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">Vital Trends</h3>
                      <VitalsChart vitals={selectedVitals} />
                    </div>
                    <AlertsPanel alerts={alerts} />
                  </div>

                  <div className="rounded-xl border border-border bg-card shadow-sm">
                    <div className="flex items-center justify-between border-b border-border px-4 py-3">
                      <h3 className="font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">Monitoring Time Log</h3>
                      <span className="text-xs font-semibold text-muted-foreground">
                        {selectedSessions.reduce((s, x) => s + Number(x.minutes || 0), 0)} min total
                      </span>
                    </div>
                    {selectedSessions.length === 0 ? (
                      <div className="px-4 py-8 text-center text-sm text-muted-foreground">No monitoring time logged yet.</div>
                    ) : (
                      <ul className="divide-y divide-border">
                        {selectedSessions.map((s) => (
                          <li key={s.id} className="flex items-center justify-between px-4 py-3">
                            <div className="flex items-center gap-3">
                              <span className={cn("rounded-md px-2 py-0.5 text-[10px] font-bold uppercase", s.session_type === "rpm" ? "bg-sky-100 text-sky-700" : "bg-violet-100 text-violet-700")}>
                                {s.session_type}
                              </span>
                              <div>
                                <div className="text-sm font-medium text-foreground">{s.minutes} min</div>
                                {s.notes && <div className="text-xs text-muted-foreground">{s.notes}</div>}
                              </div>
                            </div>
                            <div className="text-right text-xs text-muted-foreground">
                              {s.recorded_at ? new Date(s.recorded_at).toLocaleDateString() : "—"}
                              {s.recorded_by && <div>by {s.recorded_by}</div>}
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        )}
      </div>

      {selected && (
        <LogTimeDialog
          patient={selected}
          user={user}
          open={dialogOpen}
          onClose={() => setDialogOpen(false)}
          onLogged={() => { setDialogOpen(false); load(); }}
        />
      )}
    </div>
  );
}