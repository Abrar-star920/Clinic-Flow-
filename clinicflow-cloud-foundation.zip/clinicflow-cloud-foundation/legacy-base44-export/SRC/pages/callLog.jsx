import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { PhoneCall, PhoneMissed, Voicemail, Phone, Clock, ArrowUpRight } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import StatCard from "@/components/StatCard";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const REASON_LABELS = {
  schedule: "Schedule",
  reschedule: "Reschedule",
  insurance_question: "Insurance Q",
  prescription_refill: "Refill",
  billing: "Billing",
  medical_question: "Medical Q",
  results: "Results",
  other: "Other",
};

export default function CallLog() {
  const { toast } = useToast();
  const [calls, setCalls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const [escalatingId, setEscalatingId] = useState(null);

  useEffect(() => {
    base44.entities.CallLog.list("-created_date", 200)
      .then(setCalls)
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(
    () => (statusFilter === "all" ? calls : calls.filter((c) => c.status === statusFilter)),
    [calls, statusFilter]
  );

  const counts = useMemo(
    () => ({
      total: calls.length,
      answered: calls.filter((c) => c.status === "answered").length,
      missed: calls.filter((c) => c.status === "missed").length,
      escalated: calls.filter((c) => c.status === "escalated").length,
    }),
    [calls]
  );

  async function escalate(c) {
    setEscalatingId(c.id);
    try {
      await base44.functions.invoke("createEscalationFromCall", {
        call_log_id: c.id,
        caller_name: c.caller_name,
        phone: c.phone,
        call_reason: c.reason,
        summary: c.summary,
      });
      setCalls((prev) => prev.map((x) => (x.id === c.id ? { ...x, status: "escalated" } : x)));
      toast({ title: "Escalation created", description: `Alert sent to #front-desk for ${c.caller_name}.` });
    } catch (err) {
      toast({ variant: "destructive", title: "Escalation failed", description: err?.response?.data?.error || err?.message });
    } finally {
      setEscalatingId(null);
    }
  }

  return (
    <div>
      <PageHeader
        title="Call Log"
        subtitle="Inbound calls routed through the IVR phone system"
        icon={PhoneCall}
        actions={
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Calls</SelectItem>
              <SelectItem value="answered">Answered</SelectItem>
              <SelectItem value="missed">Missed</SelectItem>
              <SelectItem value="voicemail">Voicemail</SelectItem>
              <SelectItem value="escalated">Escalated</SelectItem>
            </SelectContent>
          </Select>
        }
      />

      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Total Calls" value={counts.total} icon={PhoneCall} accent="sky" />
          <StatCard label="Answered" value={counts.answered} icon={Phone} accent="emerald" />
          <StatCard label="Missed" value={counts.missed} icon={PhoneMissed} accent="rose" />
          <StatCard label="Escalated" value={counts.escalated} icon={ArrowUpRight} accent="amber" />
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
          <ul className="divide-y divide-border">
            {loading && <li className="px-5 py-10 text-center text-muted-foreground">Loading calls…</li>}
            {!loading && filtered.length === 0 && (
              <li className="px-5 py-10 text-center text-muted-foreground">No calls match this filter.</li>
            )}
            {filtered.map((c) => (
              <li key={c.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                  <div className="mt-0.5 flex h-9 w-9 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                    {c.status === "missed" ? <PhoneMissed className="h-4 w-4" /> : <PhoneCall className="h-4 w-4" />}
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">{c.caller_name}</div>
                    <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Phone className="h-3 w-3" /> {c.phone}</span>
                      <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {c.duration_seconds ? `${Math.floor(c.duration_seconds / 60)}m ${c.duration_seconds % 60}s` : "—"}</span>
                      <span className="rounded-md bg-muted px-1.5 py-0.5 font-medium">{REASON_LABELS[c.reason] || c.reason}</span>
                    </div>
                    {c.summary && <p className="mt-1.5 max-w-xl text-xs text-muted-foreground">{c.summary}</p>}
                    {c.ivr_menu_path && <p className="mt-1 text-[11px] text-muted-foreground/70">IVR path: {c.ivr_menu_path}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={c.status} />
                  {c.status !== "escalated" && c.status !== "answered" && (
                    <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" disabled={escalatingId === c.id} onClick={() => escalate(c)}>
                      <ArrowUpRight className="h-3.5 w-3.5" /> {escalatingId === c.id ? "Escalating…" : "Escalate"}
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}