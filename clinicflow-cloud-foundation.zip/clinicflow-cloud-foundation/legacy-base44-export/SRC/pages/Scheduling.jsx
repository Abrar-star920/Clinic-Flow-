import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { CalendarClock, Clock, User, Stethoscope, CheckCircle2, LayoutList, CalendarRange, RefreshCw, DownloadCloud } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import StatCard from "@/components/StatCard";
import ProviderCalendar from "@/components/ProviderCalendar";
import GoogleCalendarConnect from "@/components/GoogleCalendarConnect";
import EligibilityBlockDialog from "@/components/scheduling/EligibilityBlockDialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";
import Avatar from "@/components/Avatar";

const PROVIDERS = ["Dr. A. Reyes", "Dr. M. Chen", "Dr. S. Patel", "NP L. Okafor"];

export default function Scheduling() {
  const { toast } = useToast();
  const [appts, setAppts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("calendar");
  const [syncing, setSyncing] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [blockResult, setBlockResult] = useState(null);

  useEffect(() => {
    Promise.all([
      base44.entities.Appointment.list("-created_date", 200),
      base44.entities.Doctor.list("-created_date", 50),
      base44.entities.Patient.list("-created_date", 200),
    ])
      .then(([a, d, p]) => { setAppts(a); setDoctors(d); setPatients(p); })
      .finally(() => setLoading(false));
  }, []);

  const reload = () =>
    base44.entities.Appointment.list("-created_date", 200).then(setAppts);

  async function syncFromPatientApp() {
    setSyncing(true);
    try {
      const { data } = await base44.functions.invoke("pullAppointmentsFromPatientApp", {});
      await reload();
      toast({
        title: "Sync complete",
        description: `Pulled ${data.pulled} · ${data.created} created · ${data.updated} updated`,
      });
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Sync failed",
        description: err?.response?.data?.error || err?.message || "Could not reach the patient app.",
      });
    } finally {
      setSyncing(false);
    }
  }

  const today = new Date().toISOString().slice(0, 10);

  const todays = useMemo(
    () => appts.filter((a) => a.appointment_date === today).sort((a, b) => (a.appointment_time || "").localeCompare(b.appointment_time || "")),
    [appts, today]
  );

  const counts = useMemo(
    () => ({
      today: todays.length,
      confirmed: todays.filter((a) => a.status === "confirmed" || a.status === "checked_in").length,
      pending: todays.filter((a) => a.status === "scheduled").length,
      completed: todays.filter((a) => a.status === "completed").length,
    }),
    [todays]
  );

  const doctorMap = useMemo(() => {
    const m = new Map();
    doctors.forEach((d) => m.set(d.full_name, d));
    return m;
  }, [doctors]);

  const patientMap = useMemo(() => {
    const m = new Map();
    patients.forEach((p) => {
      if (p.email) m.set(p.email, p);
      m.set(p.full_name, p);
    });
    return m;
  }, [patients]);

  const providerList = useMemo(() => {
    const names = doctors.map((d) => d.full_name);
    PROVIDERS.forEach((p) => { if (!names.includes(p)) names.push(p); });
    return names;
  }, [doctors]);

  async function advanceStatus(id, status) {
    // Scheduling rules engine: confirm is gated on identity + insurance + HMO authorization.
    if (status === "confirmed") {
      const appt = appts.find((a) => a.id === id);
      if (appt) {
        try {
          const { data } = await base44.functions.invoke("evaluateBookingEligibility", {
            patient_id: appt.patient_id,
            patient_email: appt.patient_email,
            patient_name: appt.patient_name,
            appointment_type: appt.type,
          });
          if (data && !data.eligible) { setBlockResult(data); return; }
        } catch { /* rules engine unavailable — fall back to existing behavior */ }
      }
    }
    await base44.entities.Appointment.update(id, { status });
    setAppts((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
    // When an appointment is confirmed, push it to the staff member's Google Calendar (best-effort).
    if (status === "confirmed") {
      const appt = appts.find((a) => a.id === id);
      if (appt) {
        try {
          await base44.functions.invoke("syncAppointmentToCalendar", {
            patient_name: appt.patient_name,
            appointment_date: appt.appointment_date,
            appointment_time: appt.appointment_time,
            duration_minutes: appt.duration_minutes,
            provider: appt.provider,
            type: appt.type,
            room: appt.room,
          });
        } catch {
          /* not connected or sync failed — keep the workflow moving */
        }
      }
    }
  }

  return (
    <div>
      <PageHeader
        title="Scheduling"
        subtitle={`Today's appointments · ${new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}`}
        icon={CalendarClock}
        actions={
          <div className="flex items-center gap-2">
            <GoogleCalendarConnect />
            <Button
              size="sm"
              variant="gold"
              className="h-8 gap-1.5 text-xs"
              onClick={syncFromPatientApp}
              disabled={syncing}
            >
              {syncing ? <RefreshCw className="h-3.5 w-3.5 animate-spin" /> : <DownloadCloud className="h-3.5 w-3.5" />}
              {syncing ? "Syncing…" : "Sync from Patient App"}
            </Button>
            <div className="flex items-center rounded-lg border border-border bg-card p-0.5">
            <button
              onClick={() => setView("calendar")}
              className={cn(
                "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors",
                view === "calendar" ? "bg-gold text-gold-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <CalendarRange className="h-3.5 w-3.5" /> Calendar
            </button>
            <button
              onClick={() => setView("list")}
              className={cn(
                "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-semibold transition-colors",
                view === "list" ? "bg-gold text-gold-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <LayoutList className="h-3.5 w-3.5" /> List
            </button>
            </div>
          </div>
        }
      />

      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Today's Appointments" value={counts.today} icon={CalendarClock} accent="sky" />
          <StatCard label="Confirmed" value={counts.confirmed} icon={CheckCircle2} accent="emerald" />
          <StatCard label="Awaiting Confirm" value={counts.pending} icon={Clock} accent="amber" />
          <StatCard label="Completed" value={counts.completed} icon={CheckCircle2} accent="indigo" />
        </div>

        {view === "calendar" && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="font-display text-sm font-bold text-foreground">Provider Calendar · Today</h2>
              <span className="text-xs text-muted-foreground">Columns by provider · rows by 30-min slot (08:00–17:00)</span>
            </div>
            {loading ? (
              <div className="py-16 text-center text-muted-foreground">Loading calendar…</div>
            ) : (
              <ProviderCalendar appointments={todays} providers={providerList} doctorMap={doctorMap} onAdvance={advanceStatus} />
            )}
          </>
        )}

        {view === "list" && (
        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
          <div className="border-b border-border bg-muted/40 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Today's Schedule
          </div>
          <ul className="divide-y divide-border">
            {loading && <li className="px-5 py-10 text-center text-muted-foreground">Loading schedule…</li>}
            {!loading && todays.length === 0 && (
              <li className="px-5 py-10 text-center text-muted-foreground">No appointments scheduled for today.</li>
            )}
            {todays.map((a) => (
              <li key={a.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex w-16 flex-col items-center rounded-lg bg-accent px-2 py-1.5 text-accent-foreground">
                    <span className="font-display text-base font-bold leading-none">{a.appointment_time?.slice(0, 5) || "—"}</span>
                    <span className="text-[10px] uppercase tracking-wide opacity-70">{a.duration_minutes || 30}m</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <Avatar name={a.patient_name} src={patientMap.get(a.patient_email)?.photo_url || patientMap.get(a.patient_name)?.photo_url} size="sm" />
                      <span className="font-semibold text-foreground">{a.patient_name}</span>
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Avatar name={a.provider} src={doctorMap.get(a.provider)?.photo_url} size="xs" /> {a.provider}</span>
                      <span className="capitalize">{a.type?.replace("_", " ")}</span>
                      {a.room && <span>Room {a.room}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <StatusBadge status={a.status} />
                  <div className="flex gap-1.5">
                    {a.status === "scheduled" && (
                      <Button size="sm" variant="gold" className="h-7 text-xs" onClick={() => advanceStatus(a.id, "confirmed")}>
                        Confirm
                      </Button>
                    )}
                    {a.status === "confirmed" && (
                      <Button size="sm" variant="gold" className="h-7 text-xs" onClick={() => advanceStatus(a.id, "checked_in")}>
                        Check In
                      </Button>
                    )}
                    {a.status === "checked_in" && (
                      <Button size="sm" variant="gold" className="h-7 text-xs" onClick={() => advanceStatus(a.id, "in_progress")}>
                        Start
                      </Button>
                    )}
                    {a.status === "in_progress" && (
                      <Button size="sm" variant="gold" className="h-7 text-xs" onClick={() => advanceStatus(a.id, "completed")}>
                        Complete
                      </Button>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
        )}
        <EligibilityBlockDialog result={blockResult} onClose={() => setBlockResult(null)} />
      </div>
    </div>
  );
}