import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Stethoscope, UserPlus, Mail, Phone, Pencil, Trash2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import Avatar from "@/components/Avatar";
import DoctorDialog from "@/components/DoctorDialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

export default function Doctors() {
  const { toast } = useToast();
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  useEffect(() => {
    base44.entities.Doctor.list("-created_date", 100)
      .then(setDoctors)
      .finally(() => setLoading(false));
  }, []);

  function openNew() { setEditing(null); setDialogOpen(true); }
  function openEdit(d) { setEditing(d); setDialogOpen(true); }

  function onSaved(saved) {
    setDoctors((prev) => {
      const idx = prev.findIndex((d) => d.id === saved.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = saved;
        return next;
      }
      return [saved, ...prev];
    });
    toast({ title: editing ? "Doctor updated" : "Doctor added" });
  }

  async function remove(d) {
    try {
      await base44.entities.Doctor.delete(d.id);
      setDoctors((prev) => prev.filter((x) => x.id !== d.id));
      toast({ title: "Doctor removed" });
    } catch {
      toast({ variant: "destructive", title: "Could not remove doctor" });
    }
  }

  return (
    <div>
      <PageHeader
        title="Doctors"
        subtitle="Manage provider profiles and photos"
        icon={Stethoscope}
        actions={
          <Button size="sm" variant="gold" className="gap-1.5" onClick={openNew}>
            <UserPlus className="h-4 w-4" /> Add Doctor
          </Button>
        }
      />

      <div className="p-6 sm:p-8">
        {loading ? (
          <div className="py-16 text-center text-muted-foreground">Loading doctors…</div>
        ) : doctors.length === 0 ? (
          <div className="py-16 text-center text-muted-foreground">No doctors yet. Click “Add Doctor” to create one.</div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {doctors.map((d) => (
              <div key={d.id} className="rounded-2xl border border-border bg-card p-5 shadow-soft">
                <div className="flex items-start gap-4">
                  <Avatar name={d.full_name} src={d.photo_url} size="xl" />
                  <div className="min-w-0 flex-1">
                    <div className="font-display text-base font-bold text-foreground">{d.full_name}</div>
                    <div className="text-sm text-primary">{d.specialty || "—"}</div>
                  </div>
                </div>
                {d.bio && <p className="mt-3 line-clamp-3 text-sm text-muted-foreground">{d.bio}</p>}
                <div className="mt-3 space-y-1 text-xs text-muted-foreground">
                  {d.email && <div className="flex items-center gap-1.5"><Mail className="h-3 w-3" /> {d.email}</div>}
                  {d.phone && <div className="flex items-center gap-1.5"><Phone className="h-3 w-3" /> {d.phone}</div>}
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <Button size="sm" variant="outline" className="h-7 gap-1.5 text-xs" onClick={() => openEdit(d)}>
                    <Pencil className="h-3 w-3" /> Edit
                  </Button>
                  <Button size="sm" variant="ghost" className="h-7 gap-1.5 text-xs text-destructive hover:text-destructive" onClick={() => remove(d)}>
                    <Trash2 className="h-3 w-3" /> Remove
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <DoctorDialog open={dialogOpen} onOpenChange={setDialogOpen} onSaved={onSaved} doctor={editing} />
    </div>
  );
}