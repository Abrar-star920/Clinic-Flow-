import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Stethoscope, DoorOpen, ShieldCheck, Clock, CheckCircle2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatusBadge from "@/components/StatusBadge";
import StatCard from "@/components/StatCard";
import { Button } from "@/components/ui/button";

export default function Procedures() {
  const [procs, setProcs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Procedure.list("-created_date", 200)
      .then(setProcs)
      .finally(() => setLoading(false));
  }, []);

  const today = new Date().toISOString().slice(0, 10);

  const todays = useMemo(
    () => procs.filter((p) => p.scheduled_date === today).sort((a, b) => (a.scheduled_time || "").localeCompare(b.scheduled_time || "")),
    [procs, today]
  );

  const counts = useMemo(
    () => ({
      today: todays.length,
      inProgress: todays.filter((p) => p.status === "in_progress").length,
      preAuthPending: todays.filter((p) => p.pre_auth_status === "pending").length,
      completed: todays.filter((p) => p.status === "completed").length,
    }),
    [todays]
  );

  async function setStatus(id, status) {
    await base44.entities.Procedure.update(id, { status });
    setProcs((prev) => prev.map((p) => (p.id === id ? { ...p, status } : p)));
  }

  async function approveAuth(id) {
    await base44.entities.Procedure.update(id, { pre_auth_status: "approved" });
    setProcs((prev) => prev.map((p) => (p.id === id ? { ...p, pre_auth_status: "approved" } : p)));
    const p = procs.find((x) => x.id === id);
    try {
      await base44.entities.AuditLog.create({
        entity_type: "Procedure",
        entity_id: id,
        patient_name: p?.patient_name,
        action: "status_change",
        actor_email: "staff",
        summary: `Pre-authorization approved for ${p?.name || "procedure"} (${p?.patient_name || "patient"})`,
      });
    } catch { /* non-blocking */ }
  }

  return (
    <div>
      <PageHeader
        title="Procedures"
        subtitle="Today's procedures, rooms, and pre-authorization status"
        icon={Stethoscope}
      />

      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Scheduled Today" value={counts.today} icon={Stethoscope} accent="sky" />
          <StatCard label="In Progress" value={counts.inProgress} icon={Clock} accent="indigo" />
          <StatCard label="Pre-Auth Pending" value={counts.preAuthPending} icon={ShieldCheck} accent="amber" />
          <StatCard label="Completed" value={counts.completed} icon={CheckCircle2} accent="emerald" />
        </div>

        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {loading && <div className="col-span-full py-10 text-center text-muted-foreground">Loading procedures…</div>}
          {!loading && todays.length === 0 && (
            <div className="col-span-full py-10 text-center text-muted-foreground">No procedures scheduled for today.</div>
          )}
          {todays.map((p) => (
            <div key={p.id} className="flex flex-col rounded-xl border border-border bg-card p-4 shadow-sm">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-display font-bold text-foreground">{p.name}</div>
                  <div className="mt-0.5 text-sm text-muted-foreground">{p.patient_name}</div>
                </div>
                <div className="flex h-10 w-10 flex-col items-center justify-center rounded-lg bg-accent text-accent-foreground">
                  <span className="font-display text-sm font-bold leading-none">{p.scheduled_time?.slice(0, 5) || "—"}</span>
                  <span className="text-[9px] uppercase opacity-70">{p.duration_minutes || 60}m</span>
                </div>
              </div>

              <div className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                <div className="flex items-center gap-2"><Stethoscope className="h-3.5 w-3.5" /> {p.provider}</div>
                <div className="flex items-center gap-2"><DoorOpen className="h-3.5 w-3.5" /> Room {p.room || "TBD"}</div>
              </div>

              <div className="mt-3 flex items-center gap-2">
                <StatusBadge status={p.status} />
                {p.requires_pre_auth && <StatusBadge status={p.pre_auth_status} />}
              </div>

              <div className="mt-3 flex items-center gap-2 border-t border-border pt-3">
                {p.requires_pre_auth && p.pre_auth_status === "pending" && (
                  <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => approveAuth(p.id)}>
                    <ShieldCheck className="h-3.5 w-3.5" /> Approve Auth
                  </Button>
                )}
                {p.status === "scheduled" && (
                  <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setStatus(p.id, "prep")}>Start Prep</Button>
                )}
                {p.status === "prep" && (
                  <Button size="sm" variant="default" className="h-7 text-xs" onClick={() => setStatus(p.id, "in_progress")}>Begin</Button>
                )}
                {p.status === "in_progress" && (
                  <Button size="sm" variant="default" className="h-7 text-xs" onClick={() => setStatus(p.id, "recovery")}>Recovery</Button>
                )}
                {p.status === "recovery" && (
                  <Button size="sm" variant="gold" className="h-7 text-xs" onClick={() => setStatus(p.id, "completed")}>Complete</Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}