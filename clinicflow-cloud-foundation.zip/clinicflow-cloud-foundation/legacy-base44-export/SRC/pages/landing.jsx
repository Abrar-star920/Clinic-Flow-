import React from "react";
import LandingNav from "@/components/landing/LandingNav";
import LandingHero from "@/components/landing/LandingHero";
import StatsBand from "@/components/landing/StatsBand";
import FeatureGrid from "@/components/landing/FeatureGrid";
import HowItWorks from "@/components/landing/HowItWorks";
import ContactSection from "@/components/landing/ContactSection";
import ClosingCta from "@/components/landing/ClosingCta";
import LandingFooter from "@/components/landing/LandingFooter";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <LandingNav />
      <main>
        <LandingHero />
        <StatsBand />
        <FeatureGrid />
        <HowItWorks />
        <ContactSection />
        <ClosingCta />
      </main>
      <LandingFooter />
    </div>
  );
}