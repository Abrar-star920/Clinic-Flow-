import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { MessagesSquare } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import MessageThread from "@/components/messaging/MessageThread";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export default function Messages() {
  const { toast } = useToast();
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeThread, setActiveThread] = useState(null);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    base44.entities.Message.list("created_date", 500)
      .then(setMessages)
      .finally(() => setLoading(false));
  }, []);

  const reload = () => base44.entities.Message.list("created_date", 500).then(setMessages);

  const threads = useMemo(() => {
    const map = new Map();
    messages.forEach((m) => {
      const t = map.get(m.thread_id) || {
        thread_id: m.thread_id, patient_id: m.patient_id, patient_name: m.patient_name,
        patient_email: m.patient_email, messages: [], last: null, unread: 0,
      };
      t.messages.push(m);
      if (!t.last || (m.created_date || "") > (t.last.created_date || "")) t.last = m;
      if (m.sender_role === "patient" && !m.read) t.unread++;
      map.set(m.thread_id, t);
    });
    return [...map.values()].sort((a, b) => (b.last?.created_date || "").localeCompare(a.last?.created_date || ""));
  }, [messages]);

  const active = threads.find((t) => t.thread_id === activeThread);
  const activeMessages = active
    ? [...active.messages].sort((a, b) => (a.created_date || "").localeCompare(b.created_date || ""))
    : [];

  async function send(body) {
    if (!active) return;
    setSending(true);
    try {
      const msg = await base44.entities.Message.create({
        thread_id: active.thread_id,
        patient_id: active.patient_id,
        patient_name: active.patient_name,
        patient_email: active.patient_email,
        sender_role: "staff",
        sender_name: "Staff",
        body,
        read: false,
      });
      try {
        await base44.entities.AuditLog.create({
          entity_type: "Message", entity_id: msg.id, patient_id: active.patient_id,
          patient_name: active.patient_name, action: "create", actor_email: "staff",
          summary: `Staff replied: "${body.slice(0, 60)}"`,
        });
      } catch { /* non-blocking */ }
      await reload();
    } catch (err) {
      toast({ variant: "destructive", title: "Could not send", description: err?.message });
    } finally {
      setSending(false);
    }
  }

  return (
    <div>
      <PageHeader title="Secure Messages" subtitle="Staff ↔ patient messaging threads" icon={MessagesSquare} />
      <div className="grid h-[calc(100vh-180px)] grid-cols-1 gap-0 p-6 sm:grid-cols-[300px_1fr] sm:p-8">
        <div className="overflow-hidden rounded-l-xl border border-border bg-card shadow-sm">
          <div className="border-b border-border bg-muted/40 px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Conversations</div>
          <ul className="divide-y divide-border">
            {loading && <li className="px-4 py-8 text-center text-sm text-muted-foreground">Loading…</li>}
            {!loading && threads.length === 0 && <li className="px-4 py-8 text-center text-sm text-muted-foreground">No conversations yet.</li>}
            {threads.map((t) => (
              <li key={t.thread_id}>
                <button
                  onClick={() => setActiveThread(t.thread_id)}
                  className={cn("flex w-full items-center justify-between gap-2 px-4 py-3 text-left transition-colors", activeThread === t.thread_id ? "bg-accent" : "hover:bg-muted/50")}
                >
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold text-foreground">{t.patient_name || t.patient_email}</div>
                    <div className="truncate text-xs text-muted-foreground">{t.last?.body || "—"}</div>
                  </div>
                  {t.unread > 0 && <span className="shrink-0 rounded-full bg-rose-500 px-1.5 py-0.5 text-[10px] font-bold text-white">{t.unread}</span>}
                </button>
              </li>
            ))}
          </ul>
        </div>
        <div className="overflow-hidden rounded-r-xl border border-l-0 border-border bg-card shadow-sm">
          {active
            ? <MessageThread messages={activeMessages} onSend={send} sending={sending} />
            : <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Select a conversation</div>}
        </div>
      </div>
    </div>
  );
}