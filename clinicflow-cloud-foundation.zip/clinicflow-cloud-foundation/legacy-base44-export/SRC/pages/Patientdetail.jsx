import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ArrowLeft, User } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import AddMedicationDialog from "@/components/clinical/AddMedicationDialog";
import AddVisitNoteDialog from "@/components/clinical/AddVisitNoteDialog";
import PatientOverviewTab from "@/components/patient/tabs/PatientOverviewTab";
import AppointmentsTab from "@/components/patient/tabs/AppointmentsTab";
import BillingTab from "@/components/patient/tabs/BillingTab";
import ClaimsTab from "@/components/patient/tabs/ClaimsTab";
import ClinicalTab from "@/components/patient/tabs/ClinicalTab";

export default function PatientDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const [patient, setPatient] = useState(null);
  const [medications, setMedications] = useState([]);
  const [allergies, setAllergies] = useState([]);
  const [vitals, setVitals] = useState([]);
  const [notes, setNotes] = useState([]);
  const [audit, setAudit] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState(null);
  const [summaryLoading, setSummaryLoading] = useState(false);
  const [medOpen, setMedOpen] = useState(false);
  const [noteOpen, setNoteOpen] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([
      base44.entities.Patient.get(id),
      base44.entities.Medication.filter({ patient_id: id }, "-created_date", 100),
      base44.entities.Allergy.filter({ patient_id: id }, "-created_date", 50),
      base44.entities.VitalReading.filter({ patient_id: id }, "-recorded_at", 200),
      base44.entities.VisitNote.filter({ patient_id: id }, "-created_at", 50),
      base44.entities.AuditLog.filter({ patient_id: id }, "-created_date", 20),
    ])
      .then(([p, m, a, v, n, au]) => {
        setPatient(p);
        setMedications(m);
        setAllergies(a);
        setVitals(v);
        setNotes(n);
        setAudit(au);
      })
      .finally(() => setLoading(false));

    // Optional datasets: role-based access may restrict these, so degrade gracefully.
    base44.entities.Appointment.filter({ patient_id: id }, "-appointment_date", 200)
      .then(setAppointments)
      .catch(() => setAppointments([]));
    base44.entities.Claim.filter({ patient_id: id }, "-created_date", 100)
      .then(setClaims)
      .catch(() => setClaims([]));
  }, [id]);

  useEffect(() => { load(); }, [load]);

  async function logAudit(action, summaryText, entityRef) {
    try {
      await base44.entities.AuditLog.create({
        entity_type: entityRef?.type || "Patient",
        entity_id: entityRef?.id || id,
        patient_id: id,
        patient_name: patient?.full_name,
        action,
        actor_email: "staff",
        summary: summaryText,
      });
    } catch { /* non-blocking */ }
  }

  async function addMedication(data) {
    const rec = await base44.entities.Medication.create({
      ...data,
      patient_id: id,
      patient_email: patient?.email || "",
      patient_name: patient?.full_name || "",
      start_date: new Date().toISOString().slice(0, 10),
    });
    setMedications((prev) => [rec, ...prev]);
    await logAudit("create", `Added medication ${data.name} ${data.dosage || ""}`.trim(), { type: "Medication", id: rec.id });
    toast({ title: "Medication added" });
  }

  async function addNote(data) {
    const rec = await base44.entities.VisitNote.create({
      ...data,
      patient_id: id,
      patient_email: patient?.email || "",
      patient_name: patient?.full_name || "",
      created_at: new Date().toISOString(),
    });
    setNotes((prev) => [rec, ...prev]);
    await logAudit("create", `Added ${data.note_type} visit note`, { type: "VisitNote", id: rec.id });
    toast({ title: "Visit note added" });
  }

  async function generateSummary() {
    setSummaryLoading(true);
    try {
      const { data } = await base44.functions.invoke("generatePatientSummary", { patient_id: id });
      setSummary(data.summary);
      load();
    } catch (err) {
      toast({ variant: "destructive", title: "Summary failed", description: err?.message });
    } finally {
      setSummaryLoading(false);
    }
  }

  if (loading) return <div className="py-24 text-center text-muted-foreground">Loading patient…</div>;
  if (!patient) return <div className="py-24 text-center text-muted-foreground">Patient not found.</div>;

  return (
    <div>
      <PageHeader
        title={patient.full_name}
        subtitle={`DOB ${patient.dob || "—"} · ${patient.email || "No email"}`}
        icon={User}
        actions={
          <Button asChild variant="outline" size="sm">
            <Link to="/"><ArrowLeft className="h-4 w-4" /> Back</Link>
          </Button>
        }
      />
      <div className="px-6 py-6 sm:px-8">
        <Tabs defaultValue="overview">
          <TabsList className="mb-5 flex-wrap">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            <TabsTrigger value="claims">Insurance Claims</TabsTrigger>
            <TabsTrigger value="clinical">Clinical</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <PatientOverviewTab
              patient={patient}
              patientId={id}
              summary={summary}
              summaryLoading={summaryLoading}
              onGenerateSummary={generateSummary}
              audit={audit}
            />
          </TabsContent>

          <TabsContent value="appointments">
            <AppointmentsTab appointments={appointments} />
          </TabsContent>

          <TabsContent value="billing">
            <BillingTab claims={claims} />
          </TabsContent>

          <TabsContent value="claims">
            <ClaimsTab patientId={id} patient={patient} claims={claims} />
          </TabsContent>

          <TabsContent value="clinical">
            <ClinicalTab
              vitals={vitals}
              medications={medications}
              allergies={allergies}
              notes={notes}
              onAddMedication={() => setMedOpen(true)}
              onAddNote={() => setNoteOpen(true)}
            />
          </TabsContent>
        </Tabs>
      </div>
      <AddMedicationDialog open={medOpen} onOpenChange={setMedOpen} onAdd={addMedication} />
      <AddVisitNoteDialog open={noteOpen} onOpenChange={setNoteOpen} onAdd={addNote} />
    </div>
  );
}