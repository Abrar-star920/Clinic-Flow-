import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { ScrollText, Search, ShieldCheck, Stethoscope, UserCog } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

const FILTERS = [
  { id: "all", label: "All Activity" },
  { id: "insurance", label: "Insurance Updates" },
  { id: "procedure", label: "Procedure Approvals" },
];

const isInsurance = (l) =>
  /insurance|verified/i.test(l.summary || "") || (l.entity_type === "Patient" && l.action === "status_change");
const isProcedure = (l) =>
  /auth|pre-authorization|procedure/i.test(l.summary || "") || l.entity_type === "Procedure";

function meta(l) {
  if (isProcedure(l)) return { icon: Stethoscope, color: "bg-indigo-100 text-indigo-700" };
  if (isInsurance(l)) return { icon: ShieldCheck, color: "bg-emerald-100 text-emerald-700" };
  return { icon: UserCog, color: "bg-sky-100 text-sky-700" };
}

function formatTime(d) {
  if (!d) return "";
  const dt = new Date(d);
  if (isNaN(dt)) return d.slice(0, 16).replace("T", " ");
  return (
    dt.toLocaleDateString(undefined, { month: "short", day: "numeric" }) +
    " · " +
    dt.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" })
  );
}

export default function ActivityLog() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");

  useEffect(() => {
    base44.entities.AuditLog.list("-created_date", 300)
      .then(setLogs)
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    return logs.filter((l) => {
      const q = query.toLowerCase();
      const matchesQuery =
        !q ||
        l.summary?.toLowerCase().includes(q) ||
        l.patient_name?.toLowerCase().includes(q) ||
        l.actor_email?.toLowerCase().includes(q);
      const matchesFilter =
        filter === "all" ||
        (filter === "insurance" && isInsurance(l)) ||
        (filter === "procedure" && isProcedure(l));
      return matchesQuery && matchesFilter;
    });
  }, [logs, query, filter]);

  const counts = useMemo(
    () => ({
      total: logs.length,
      insurance: logs.filter(isInsurance).length,
      procedures: logs.filter(isProcedure).length,
    }),
    [logs]
  );

  return (
    <div>
      <PageHeader
        title="Activity Log"
        subtitle="Insurance updates, procedure approvals, and record changes"
        icon={ScrollText}
      />
      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-3">
          <StatCard label="Total Events" value={counts.total} icon={ScrollText} accent="sky" />
          <StatCard label="Insurance Updates" value={counts.insurance} icon={ShieldCheck} accent="emerald" />
          <StatCard label="Procedure Approvals" value={counts.procedures} icon={Stethoscope} accent="indigo" />
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center rounded-lg border border-border bg-card p-0.5">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  "rounded-md px-3 py-1.5 text-xs font-semibold transition-colors",
                  filter === f.id ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="relative sm:w-72">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search activity…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
          {loading ? (
            <div className="px-5 py-10 text-center text-muted-foreground">Loading activity…</div>
          ) : filtered.length === 0 ? (
            <div className="px-5 py-10 text-center text-muted-foreground">No activity recorded.</div>
          ) : (
            <ul className="divide-y divide-border">
              {filtered.map((l) => {
                const M = meta(l);
                return (
                  <li key={l.id} className="flex items-start gap-3 px-5 py-4">
                    <div className={cn("mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg", M.color)}>
                      <M.icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-foreground">{l.summary}</div>
                      <div className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
                        <span className="capitalize">{l.entity_type}</span>
                        {l.patient_name && <span>· {l.patient_name}</span>}
                        <span>· {l.actor_email || "system"}</span>
                      </div>
                    </div>
                    <span className="whitespace-nowrap text-xs text-muted-foreground">{formatTime(l.created_date)}</span>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}