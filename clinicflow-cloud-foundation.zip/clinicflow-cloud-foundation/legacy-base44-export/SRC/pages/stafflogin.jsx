import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ShieldCheck, Lock } from "lucide-react";
import { safeReturnTo } from "@/lib/authReturnTo";
import { ClinicFlowLogo } from "@/components/branding/ClinicFlowMark";
import LoginIllustration from "@/components/branding/LoginIllustration";

export default function StaffLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.auth.loginViaEmailPassword(email, password);
      const returnTo = safeReturnTo();
      window.location.href = returnTo && returnTo !== "/" ? returnTo : "/app";
    } catch (err) {
      setError(err.message || "Invalid email or password");
      // Report the failed attempt to the intrusion detector (fire-and-forget).
      base44.functions
        .invoke("reportSecurityEvent", { event_type: "failed_login", email, source: "staff_login" })
        .catch(() => {});
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Illustration side */}
      <div className="relative hidden flex-col justify-between bg-accent p-10 lg:flex">
        <ClinicFlowLogo size={40} />
        <div className="flex flex-1 items-center justify-center">
          <LoginIllustration className="w-full max-w-md drop-shadow-sm" />
        </div>
        <div className="max-w-sm">
          <h2 className="font-display text-2xl font-bold tracking-tight text-foreground">
            Secure access for clinic and hospital staff
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Manage intake, scheduling, clinical records, billing and patient communication — all in one compliant workspace.
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs font-medium text-accent-foreground">
            <ShieldCheck className="h-4 w-4" /> HIPAA-aware · Role-based access · Audit logged
          </div>
        </div>
      </div>

      {/* Form side */}
      <div className="flex flex-col bg-background">
        <header className="flex items-center justify-between px-6 py-8 sm:px-10">
          <div className="lg:hidden"><ClinicFlowLogo size={34} /></div>
          <div className="hidden lg:block" />
          <Link to="/portal" className="text-xs font-medium text-muted-foreground hover:text-foreground">
            Patient? Self-service portal →
          </Link>
        </header>

        <div className="flex flex-1 items-center justify-center px-6 pb-16 sm:px-10">
          <div className="w-full max-w-sm">
            <div className="mb-6">
              <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">Staff sign in</h1>
              <p className="mt-1.5 text-sm text-muted-foreground">Access the ClinicFlow dashboard.</p>
            </div>

            {error && (
              <div className="mb-5 rounded-lg bg-destructive/10 p-3 text-sm font-medium text-destructive">{error}</div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email">Work email</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  autoFocus
                  placeholder="you@clinic.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <Link to="/forgot-password" className="text-xs font-medium text-primary hover:underline">Forgot password?</Link>
                </div>
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? (<><Loader2 className="h-4 w-4 animate-spin" /> Signing in…</>) : "Sign in"}
              </Button>
            </form>

            <div className="mt-6 flex items-start gap-2 rounded-lg border border-border bg-surface p-3 text-xs text-muted-foreground">
              <Lock className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              <span>
                Staff accounts are invite-only. New accounts can't be created here — an administrator invites staff by email.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}