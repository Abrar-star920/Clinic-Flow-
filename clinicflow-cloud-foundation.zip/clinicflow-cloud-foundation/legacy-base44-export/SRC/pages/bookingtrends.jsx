import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { CalendarClock, CalendarCheck, CalendarX, TrendingDown, Gauge } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";

const RANGES = [
  { value: 7, label: "7 days" },
  { value: 14, label: "14 days" },
  { value: 30, label: "30 days" },
  { value: 90, label: "90 days" },
];

const fmtDay = (d) => d.toLocaleDateString(undefined, { month: "short", day: "numeric" });

export default function BookingTrends() {
  const [appts, setAppts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState(30);

  useEffect(() => {
    base44.entities.Appointment
      .list("-created_date", 1000)
      .then(setAppts)
      .finally(() => setLoading(false));
  }, []);

  const series = useMemo(() => {
    const dayMs = 24 * 60 * 60 * 1000;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const days = [];
    for (let i = range - 1; i >= 0; i--) {
      const d = new Date(today.getTime() - i * dayMs);
      const key = d.toISOString().slice(0, 10);
      days.push({ key, label: fmtDay(d), confirmed: 0, cancelled: 0 });
    }
    const idx = new Map(days.map((d, i) => [d.key, i]));
    appts.forEach((a) => {
      if (!a.appointment_date) return;
      const i = idx.get(a.appointment_date);
      if (i === undefined) return;
      if (a.status === "confirmed" || a.status === "completed") days[i].confirmed += 1;
      else if (a.status === "cancelled") days[i].cancelled += 1;
    });
    let running = 0;
    return days.map((d) => { running += d.confirmed - d.cancelled; return { ...d, net: running }; });
  }, [appts, range]);

  const totals = useMemo(() => {
    const confirmed = series.reduce((s, d) => s + d.confirmed, 0);
    const cancelled = series.reduce((s, d) => s + d.cancelled, 0);
    const booked = confirmed + cancelled;
    const cancelRate = booked ? Math.round((cancelled / booked) * 100) : 0;
    const avgConfirmed = series.length ? Math.round((confirmed / series.length) * 10) / 10 : 0;
    return { confirmed, cancelled, booked, cancelRate, avgConfirmed };
  }, [series]);

  return (
    <div>
      <PageHeader
        title="Booking Trends"
        subtitle="Daily confirmed vs cancelled appointments — track clinic capacity"
        icon={CalendarClock}
        actions={
          <div className="inline-flex rounded-lg border border-input bg-card p-0.5 shadow-soft">
            {RANGES.map((r) => (
              <button
                key={r.value}
                onClick={() => setRange(r.value)}
                className={
                  "rounded-md px-3 py-1.5 text-xs font-semibold transition-colors " +
                  (range === r.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted")
                }
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      />

      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Confirmed" value={totals.confirmed} icon={CalendarCheck} accent="emerald" />
          <StatCard label="Cancelled" value={totals.cancelled} icon={CalendarX} accent="amber" />
          <StatCard label="Cancellation Rate" value={`${totals.cancelRate}%`} icon={TrendingDown} accent="sky" />
          <StatCard label="Avg Confirmed / Day" value={totals.avgConfirmed} icon={Gauge} accent="indigo" />
        </div>

        <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
            <div>
              <h3 className="font-display text-sm font-bold text-foreground">Daily Bookings · Last {range} Days</h3>
              <p className="text-xs text-muted-foreground">Confirmed appointments versus cancellations, with running net bookings.</p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-emerald-500" /> Confirmed</span>
              <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-rose-400" /> Cancelled</span>
              <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-primary" /> Net</span>
            </div>
          </div>
          {loading ? (
            <div className="py-16 text-center text-muted-foreground">Loading booking trends…</div>
          ) : (
            <ResponsiveContainer width="100%" height={320}>
              <ComposedChart data={series} margin={{ left: -16, right: 8 }}>
                <defs>
                  <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#005696" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#005696" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} interval={Math.max(0, Math.floor(range / 8))} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid hsl(var(--border))", fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="confirmed" name="Confirmed" stackId="b" fill="#10b981" radius={[0, 0, 0, 0]} maxBarSize={28} />
                <Bar dataKey="cancelled" name="Cancelled" stackId="b" fill="#fb7185" radius={[4, 4, 0, 0]} maxBarSize={28} />
                <Line type="monotone" dataKey="net" name="Net bookings" stroke="#005696" strokeWidth={2} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
          <h3 className="mb-3 font-display text-sm font-bold text-foreground">Daily Breakdown</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <th className="py-2 pr-4 font-semibold">Date</th>
                  <th className="py-2 pr-4 font-semibold">Confirmed</th>
                  <th className="py-2 pr-4 font-semibold">Cancelled</th>
                  <th className="py-2 pr-4 font-semibold">Net</th>
                  <th className="py-2 pr-4 font-semibold">Capacity used</th>
                </tr>
              </thead>
              <tbody>
                {[...series].reverse().map((d) => {
                  const pct = totals.avgConfirmed ? Math.round((d.confirmed / (totals.avgConfirmed || 1)) * 100) : 0;
                  return (
                    <tr key={d.key} className="border-b border-border/60 last:border-0">
                      <td className="py-2 pr-4 font-medium text-foreground">{d.label}</td>
                      <td className="py-2 pr-4 text-emerald-600">{d.confirmed}</td>
                      <td className="py-2 pr-4 text-rose-500">{d.cancelled}</td>
                      <td className="py-2 pr-4 font-semibold text-foreground">{d.net}</td>
                      <td className="py-2 pr-4">
                        <div className="flex items-center gap-2">
                          <div className="h-2 w-24 overflow-hidden rounded-full bg-muted">
                            <div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, pct)}%` }} />
                          </div>
                          <span className="text-xs text-muted-foreground">{pct}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}