import React, { useState, useEffect, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { ListChecks, Plus, Pencil, CheckCircle2, Trash2, AlertTriangle } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import TaskDialog from "@/components/tasks/TaskDialog";
import { Button } from "@/components/ui/button";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const STAFF = ["Maya R. (Front Desk)", "Devin T. (Intake)", "Priya N. (Billing)", "Owen L. (RN Triage)"];

const COLUMNS = [
  { key: "open", label: "Open" },
  { key: "in_progress", label: "In Progress" },
  { key: "blocked", label: "Blocked" },
  { key: "completed", label: "Completed" },
];

const TYPE_LABEL = {
  follow_up: "Follow-up", authorization_issue: "Auth Issue", clinical_message: "Clinical Msg",
  records_request: "Records Request", prescription_refill: "Refill", callback: "Callback", other: "Other",
};

const PRIORITY_STYLE = {
  low: "bg-slate-100 text-slate-600",
  medium: "bg-amber-100 text-amber-700",
  high: "bg-orange-100 text-orange-700",
  urgent: "bg-rose-100 text-rose-700",
};

const todayStr = () => new Date().toISOString().slice(0, 10);

export default function Tasks() {
  const { toast } = useToast();
  const [tasks, setTasks] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [filterType, setFilterType] = useState("all");
  const [filterAssignee, setFilterAssignee] = useState("all");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [t, p] = await Promise.all([
        base44.entities.Task.list("-created_date", 500),
        base44.entities.Patient.list("-created_date", 200),
      ]);
      setTasks(t);
      setPatients(p);
    } catch (e) {
      toast({ variant: "destructive", title: "Could not load work queue", description: e?.message });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const filtered = useMemo(() => {
    return tasks.filter((t) =>
      (filterType === "all" || t.task_type === filterType) &&
      (filterAssignee === "all" || (filterAssignee === "unassigned" ? !t.assigned_to : t.assigned_to === filterAssignee)) &&
      t.status !== "cancelled"
    );
  }, [tasks, filterType, filterAssignee]);

  const byColumn = useMemo(() => {
    const map = { open: [], in_progress: [], blocked: [], completed: [] };
    filtered.forEach((t) => { if (map[t.status]) map[t.status].push(t); });
    return map;
  }, [filtered]);

  const stats = useMemo(() => {
    const open = tasks.filter((t) => t.status === "open" || t.status === "in_progress").length;
    const urgent = tasks.filter((t) => (t.status === "open" || t.status === "in_progress") && t.priority === "urgent").length;
    const overdue = tasks.filter((t) => (t.status === "open" || t.status === "in_progress") && t.due_date && t.due_date < todayStr()).length;
    const done = tasks.filter((t) => t.status === "completed").length;
    return { open, urgent, overdue, done };
  }, [tasks]);

  async function createOrUpdate(payload) {
    try {
      if (payload.id) {
        const { id, ...rest } = payload;
        await base44.entities.Task.update(id, rest);
        toast({ title: "Task updated" });
      } else {
        await base44.entities.Task.create({ ...payload, status: payload.status || "open" });
        toast({ title: "Task created" });
      }
      setDialogOpen(false);
      setEditing(null);
      await load();
    } catch (e) {
      toast({ variant: "destructive", title: "Could not save task", description: e?.message });
    }
  }

  async function setStatus(task, status) {
    try {
      const updates = { status };
      if (status === "completed") updates.resolution_notes = task.resolution_notes || "Completed via work queue";
      await base44.entities.Task.update(task.id, updates);
      await load();
    } catch (e) {
      toast({ variant: "destructive", title: "Update failed", description: e?.message });
    }
  }

  async function remove(task) {
    try {
      await base44.entities.Task.delete(task.id);
      await load();
    } catch (e) {
      toast({ variant: "destructive", title: "Delete failed", description: e?.message });
    }
  }

  const STAT_CARDS = [
    { label: "Active", value: stats.open, tone: "text-primary" },
    { label: "Urgent", value: stats.urgent, tone: "text-rose-600" },
    { label: "Overdue", value: stats.overdue, tone: "text-orange-600" },
    { label: "Completed", value: stats.done, tone: "text-emerald-600" },
  ];

  return (
    <div>
      <PageHeader
        title="Work Queue"
        subtitle="Follow-ups, authorization issues, clinical messages & records requests"
        icon={ListChecks}
        actions={
          <Button variant="gold" onClick={() => { setEditing(null); setDialogOpen(true); }} className="gap-1.5">
            <Plus className="h-4 w-4" /> New Task
          </Button>
        }
      />

      <div className="px-6 sm:px-8">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {STAT_CARDS.map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-card p-4 shadow-soft">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{s.label}</div>
              <div className={cn("mt-1 font-display text-2xl font-bold tabular-nums", s.tone)}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {Object.entries(TYPE_LABEL).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterAssignee} onValueChange={setFilterAssignee}>
            <SelectTrigger className="w-52"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All assignees</SelectItem>
              <SelectItem value="unassigned">Unassigned</SelectItem>
              {STAFF.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        {/* Board */}
        <div className="mt-5 grid grid-cols-1 gap-4 lg:grid-cols-4">
          {COLUMNS.map((col) => (
            <div key={col.key} className="rounded-xl border border-border bg-muted/30 p-3">
              <div className="mb-3 flex items-center justify-between px-1">
                <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{col.label}</span>
                <span className="rounded-full bg-card px-2 py-0.5 text-[10px] font-bold text-muted-foreground shadow-soft">{byColumn[col.key].length}</span>
              </div>
              <div className="space-y-2.5">
                {loading && <div className="py-6 text-center text-xs text-muted-foreground">Loading…</div>}
                {!loading && byColumn[col.key].length === 0 && (
                  <div className="py-6 text-center text-xs text-muted-foreground">No tasks</div>
                )}
                {byColumn[col.key].map((t) => {
                  const overdue = t.due_date && t.due_date < todayStr() && t.status !== "completed";
                  return (
                    <div key={t.id} className="rounded-lg border border-border bg-card p-3 shadow-soft">
                      <div className="flex items-start justify-between gap-2">
                        <div className="text-sm font-semibold leading-snug text-foreground">{t.title}</div>
                        <span className={cn("shrink-0 rounded-full px-1.5 py-0.5 text-[10px] font-bold uppercase", PRIORITY_STYLE[t.priority] || PRIORITY_STYLE.medium)}>{t.priority}</span>
                      </div>
                      {t.description && <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{t.description}</p>}
                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px] font-semibold text-secondary-foreground">{TYPE_LABEL[t.task_type] || t.task_type}</span>
                        {t.patient_name && <span className="rounded bg-sky-50 px-1.5 py-0.5 text-[10px] font-medium text-sky-700">{t.patient_name}</span>}
                        {overdue && <span className="inline-flex items-center gap-0.5 rounded bg-rose-50 px-1.5 py-0.5 text-[10px] font-semibold text-rose-700"><AlertTriangle className="h-2.5 w-2.5" /> {t.due_date}</span>}
                        {!overdue && t.due_date && <span className="text-[10px] text-muted-foreground">due {t.due_date}</span>}
                      </div>
                      {t.assigned_to && <div className="mt-1.5 text-[11px] text-muted-foreground">👤 {t.assigned_to}</div>}
                      <div className="mt-2.5 flex items-center gap-1.5 border-t border-border pt-2">
                        {t.status !== "completed" && (
                          <Select value={t.status} onValueChange={(v) => setStatus(t, v)}>
                            <SelectTrigger className="h-7 flex-1 text-xs"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {COLUMNS.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        )}
                        <button onClick={() => { setEditing(t); setDialogOpen(true); }} className="rounded-md p-1 text-muted-foreground hover:bg-muted hover:text-foreground"><Pencil className="h-3.5 w-3.5" /></button>
                        {t.status !== "completed" ? (
                          <button onClick={() => setStatus(t, "completed")} className="rounded-md p-1 text-muted-foreground hover:bg-emerald-50 hover:text-emerald-600"><CheckCircle2 className="h-3.5 w-3.5" /></button>
                        ) : null}
                        <button onClick={() => remove(t)} className="rounded-md p-1 text-muted-foreground hover:bg-rose-50 hover:text-rose-600"><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      <TaskDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSaved={createOrUpdate}
        patients={patients}
        staff={STAFF}
        task={editing}
      />
    </div>
  );
}