import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import PageHeader from "@/components/PageHeader";
import { ShieldCheck, Loader2, Lock, FlaskConical, PlugZap, Building2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EligibilityForm from "@/components/assistant/EligibilityForm";
import ClaimDetailPanel from "@/components/assistant/ClaimDetailPanel";
import DraftPanel from "@/components/assistant/DraftPanel";
import FetchAcknowledgmentsButton from "@/components/assistant/FetchAcknowledgmentsButton";

function EnvBadge({ connected, env, providerConfigured }) {
  if (!connected) {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">
        <PlugZap className="h-3.5 w-3.5" /> Stedi not connected
      </span>
    );
  }
  if (env === "production") {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
        <ShieldCheck className="h-3.5 w-3.5" /> Production
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-700 ring-1 ring-amber-200">
      <FlaskConical className="h-3.5 w-3.5" /> Test
    </span>
  );
}

export default function InsuranceAssistant() {
  const [claims, setClaims] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState({ connected: false, env: "test", providerConfigured: false });

  useEffect(() => {
    base44.functions.invoke("clearinghouseRequest", {})
      .then((res) => setStatus(res.data))
      .catch(() => setStatus({ connected: false, env: "test", providerConfigured: false }));
    base44.entities.Claim.filter({}, { sort: "-created_date", limit: 100 })
      .then(({ items }) => {
        setClaims(items);
        if (items.length) setSelectedId(items[0].id);
      })
      .finally(() => setLoading(false));
  }, []);

  function refreshClaims() {
    base44.entities.Claim.filter({}, { sort: "-created_date", limit: 100 })
      .then(({ items }) => setClaims(items));
  }

  const selected = claims.find((c) => c.id === selectedId);
  const { connected, env, providerConfigured } = status;

  return (
    <div>
      <PageHeader
        title="Insurance Assistant"
        subtitle="Stedi clearinghouse — eligibility, claim status, submission, and AI-drafted appeals. Staff review only."
        icon={ShieldCheck}
        actions={<EnvBadge connected={connected} env={env} providerConfigured={providerConfigured} />}
      />

      <div className="px-6 py-6 sm:px-8">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-surface px-3 py-1.5 text-xs text-muted-foreground">
            <Lock className="h-3.5 w-3.5" /> HIPAA: minimum-necessary data, masked identifiers, every action audited. AI can read results but never submit.
          </div>
          {connected && !providerConfigured && (
            <span className="inline-flex items-center gap-1.5 rounded-lg bg-amber-50 px-3 py-1.5 text-xs font-medium text-amber-800 ring-1 ring-amber-200">
              <Building2 className="h-3.5 w-3.5" /> Billing provider details not configured — set NPI/name/tax ID in Settings → Secrets.
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
            <div className="mb-4 flex items-center justify-between gap-2">
              <h3 className="font-display text-sm font-bold text-foreground">Claims</h3>
              <FetchAcknowledgmentsButton connected={connected} onUpdated={refreshClaims} />
            </div>
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : claims.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No claims found.</p>
            ) : (
              <>
                <select
                  value={selectedId || ""}
                  onChange={(e) => setSelectedId(e.target.value)}
                  className="mb-4 w-full rounded-lg border border-input bg-transparent px-3 py-2 text-sm shadow-sm outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  {claims.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.invoice_number || c.id} — {c.patient_name} ({c.status})
                    </option>
                  ))}
                </select>
                <ClaimDetailPanel claim={selected} env={env} connected={connected} />
              </>
            )}
          </section>

          <section className="rounded-xl border border-border bg-card p-5 shadow-sm">
            <Tabs defaultValue="eligibility">
              <TabsList className="mb-4">
                <TabsTrigger value="eligibility">Eligibility</TabsTrigger>
                <TabsTrigger value="drafts">Drafts</TabsTrigger>
              </TabsList>
              <TabsContent value="eligibility">
                <EligibilityForm env={env} connected={connected} />
              </TabsContent>
              <TabsContent value="drafts">
                <DraftPanel claim={selected} />
              </TabsContent>
            </Tabs>
          </section>
        </div>
      </div>
    </div>
  );
}