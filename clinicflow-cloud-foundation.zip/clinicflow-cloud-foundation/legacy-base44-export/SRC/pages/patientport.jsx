import React, { useEffect, useState, useMemo, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import {
  CalendarClock,
  ShieldCheck,
  CalendarPlus,
  LogOut,
  Activity,
  Clock,
  Stethoscope,
  CheckCircle2,
  AlertCircle,
  CreditCard,
} from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import PatientInvoices from "@/components/patient/PatientInvoices";
import ConciergeChat from "@/components/concierge/ConciergeChat";
import GoogleCalendarConnect from "@/components/GoogleCalendarConnect";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const PROVIDERS = ["Dr. A. Reyes", "Dr. M. Chen", "Dr. S. Patel", "NP L. Okafor"];
const TYPES = [
  { value: "new_patient", label: "New Patient" },
  { value: "follow_up", label: "Follow-up" },
  { value: "procedure", label: "Procedure" },
  { value: "telehealth", label: "Telehealth" },
  { value: "lab_work", label: "Lab Work" },
];

const todayStr = () => new Date().toISOString().slice(0, 10);

export default function PatientPortal() {
  const { user, logout } = useAuth();
  const [patient, setPatient] = useState(null);
  const [appts, setAppts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ date: "", time: "", provider: PROVIDERS[0], type: "follow_up", reason: "" });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    if (!user?.email) return;
    setLoading(true);
    try {
      const [patients, appointments] = await Promise.all([
        base44.entities.Patient.filter({ email: user.email }, "-created_date", 5),
        base44.entities.Appointment.filter({ patient_email: user.email }, "-appointment_date", 50),
      ]);
      setPatient(patients[0] || null);
      setAppts(appointments);
    } finally {
      setLoading(false);
    }
  }, [user?.email]);

  useEffect(() => {
    load();
  }, [load]);

  const { upcoming, past } = useMemo(() => {
    const today = todayStr();
    const sorted = [...appts].sort((a, b) =>
      `${a.appointment_date} ${a.appointment_time || ""}`.localeCompare(`${b.appointment_date} ${b.appointment_time || ""}`)
    );
    return {
      upcoming: sorted.filter((a) => (a.appointment_date || "") >= today && a.status !== "cancelled"),
      past: sorted.filter((a) => (a.appointment_date || "") < today || a.status === "completed" || a.status === "cancelled"),
    };
  }, [appts]);

  async function submitRequest(e) {
    e.preventDefault();
    setError("");
    if (!form.date || !form.time) {
      setError("Please choose a date and time.");
      return;
    }
    setSubmitting(true);
    try {
      const created = await base44.entities.Appointment.create({
        patient_name: patient?.full_name || user?.full_name || user?.email,
        patient_email: user.email,
        appointment_date: form.date,
        appointment_time: form.time,
        duration_minutes: 30,
        provider: form.provider,
        type: form.type,
        status: "scheduled",
        room: "",
      });
      // Best-effort: push the requested appointment to the patient's Google Calendar.
      try {
        await base44.functions.invoke("syncAppointmentToCalendar", {
          patient_name: created.patient_name,
          appointment_date: created.appointment_date,
          appointment_time: created.appointment_time,
          duration_minutes: created.duration_minutes,
          provider: created.provider,
          type: created.type,
          room: created.room,
        });
      } catch {
        /* not connected or sync failed — request still succeeds */
      }
      setSubmitted(true);
      setForm({ date: "", time: "", provider: PROVIDERS[0], type: "follow_up", reason: "" });
      await load();
    } catch (err) {
      setError("We couldn't submit your request. Please try again or call the clinic.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-background to-background">
      {/* Patient top bar */}
      <header className="border-b border-border bg-card/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-400 to-sky-500 text-white shadow-sm">
              <Activity className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <div className="font-display text-[15px] font-bold tracking-tight text-foreground">ClinicFlow</div>
              <div className="text-[11px] font-medium text-muted-foreground">Patient Portal</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden text-right sm:block">
              <div className="text-[13px] font-semibold text-foreground">{patient?.full_name || user?.full_name || "Patient"}</div>
              <div className="text-[11px] text-muted-foreground">{user?.email}</div>
            </div>
            <GoogleCalendarConnect />
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => logout()}>
              <LogOut className="h-4 w-4" /> Sign Out
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 py-8">
        <div className="mb-6">
          <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">
            Welcome, {patient?.full_name?.split(" ")[0] || "Patient"}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            View your appointments, check insurance coverage, review invoices, and request a new visit.
          </p>
        </div>

        {loading ? (
          <div className="py-20 text-center text-muted-foreground">Loading your records…</div>
        ) : (
          <Tabs defaultValue="appointments" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="appointments" className="gap-1.5">
                <CalendarClock className="h-4 w-4" /> Appointments
              </TabsTrigger>
              <TabsTrigger value="insurance" className="gap-1.5">
                <ShieldCheck className="h-4 w-4" /> Insurance
              </TabsTrigger>
              <TabsTrigger value="billing" className="gap-1.5">
                <CreditCard className="h-4 w-4" /> Billing
              </TabsTrigger>
              <TabsTrigger value="request" className="gap-1.5">
                <CalendarPlus className="h-4 w-4" /> Request
              </TabsTrigger>
            </TabsList>

            {/* Appointments */}
            <TabsContent value="appointments" className="mt-5 space-y-6">
              <section>
                <h2 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
                  <Clock className="h-4 w-4" /> Upcoming
                </h2>
                {upcoming.length === 0 ? (
                  <EmptyCard icon={CalendarClock} text="You have no upcoming appointments." />
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {upcoming.map((a) => (
                      <AppointmentCard key={a.id} a={a} />
                    ))}
                  </div>
                )}
              </section>
              <section>
                <h2 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
                  <CheckCircle2 className="h-4 w-4" /> History
                </h2>
                {past.length === 0 ? (
                  <EmptyCard icon={CheckCircle2} text="No past appointments on record." />
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {past.map((a) => (
                      <AppointmentCard key={a.id} a={a} />
                    ))}
                  </div>
                )}
              </section>
            </TabsContent>

            {/* Insurance */}
            <TabsContent value="insurance" className="mt-5">
              {!patient ? (
                <EmptyCard icon={AlertCircle} text="No patient profile is linked to your account yet. Please contact the clinic to verify your details." />
              ) : (
                <div className="grid gap-4 sm:grid-cols-2">
                  <InfoTile label="Insurance Provider" value={patient.insurance_provider || "—"} />
                  <InfoTile label="Member ID" value={patient.insurance_member_id || "—"} />
                  <div className="rounded-xl border border-border bg-card p-4 shadow-sm sm:col-span-2">
                    <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Verification Status</div>
                    <div className="mt-2 flex items-center gap-2">
                      <StatusBadge status={patient.insurance_status} />
                      <span className="text-sm text-muted-foreground">
                        {patient.insurance_status === "verified"
                          ? "Your coverage is verified. You're all set for visits."
                          : patient.insurance_status === "pending"
                          ? "Verification is in progress. The clinic will confirm shortly."
                          : patient.insurance_status === "denied"
                          ? "Coverage was denied. Please contact the clinic to discuss options."
                          : "Insurance not yet verified. Please contact the front desk."}
                      </span>
                    </div>
                  </div>
                  <InfoTile label="Date of Birth" value={patient.dob || "—"} />
                  <InfoTile label="Last Visit" value={patient.last_visit || "—"} />
                </div>
              )}
            </TabsContent>

            {/* Billing */}
            <TabsContent value="billing" className="mt-5">
              <PatientInvoices user={user} />
            </TabsContent>

            {/* Request */}
            <TabsContent value="request" className="mt-5">
              <div className="max-w-xl rounded-xl border border-border bg-card p-6 shadow-sm">
                <h2 className="font-display text-base font-bold text-foreground">Request an Appointment</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Choose a preferred date, time, and provider. The front desk will confirm your booking.
                </p>

                {submitted ? (
                  <div className="mt-5 flex items-start gap-3 rounded-lg border border-emerald-200 bg-emerald-50 p-4">
                    <CheckCircle2 className="mt-0.5 h-5 w-5 text-emerald-600" />
                    <div>
                      <div className="font-semibold text-emerald-800">Request submitted</div>
                      <p className="mt-0.5 text-sm text-emerald-700">
                        We've received your request. The clinic will confirm your appointment shortly — check the Appointments tab.
                      </p>
                      <Button variant="outline" size="sm" className="mt-3" onClick={() => setSubmitted(false)}>
                        Request another
                      </Button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={submitRequest} className="mt-5 space-y-4">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="date">Preferred Date</Label>
                        <Input id="date" type="date" min={todayStr()} value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="time">Preferred Time</Label>
                        <Input id="time" type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} required />
                      </div>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <div className="space-y-1.5">
                        <Label>Provider</Label>
                        <Select value={form.provider} onValueChange={(v) => setForm({ ...form, provider: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {PROVIDERS.map((p) => (<SelectItem key={p} value={p}>{p}</SelectItem>))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-1.5">
                        <Label>Visit Type</Label>
                        <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {TYPES.map((t) => (<SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="reason">Reason for Visit (optional)</Label>
                      <Textarea id="reason" rows={3} placeholder="Briefly describe your symptoms or reason…" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} />
                    </div>
                    {error && (
                      <div className="flex items-center gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-700">
                        <AlertCircle className="h-4 w-4" /> {error}
                      </div>
                    )}
                    <Button type="submit" disabled={submitting} className="gap-1.5">
                      <CalendarPlus className="h-4 w-4" /> {submitting ? "Submitting…" : "Submit Request"}
                    </Button>
                  </form>
                )}
              </div>
            </TabsContent>
          </Tabs>
        )}
      </main>

      <ConciergeChat
        variant="widget"
        patientContext={{
          name: patient?.full_name || user?.full_name,
          email: user?.email,
          conditions: patient?.chronic_conditions || [],
          insurance_status: patient?.insurance_status,
        }}
      />
    </div>
  );
}

function AppointmentCard({ a }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="font-display text-base font-bold text-foreground">
            {a.appointment_date ? new Date(a.appointment_date + "T00:00:00").toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }) : "—"}
          </div>
          <div className="text-sm font-medium text-primary">{a.appointment_time?.slice(0, 5) || "—"}</div>
        </div>
        <StatusBadge status={a.status} />
      </div>
      <div className="mt-3 space-y-1.5 text-sm text-muted-foreground">
        <div className="flex items-center gap-2"><Stethoscope className="h-3.5 w-3.5" /> {a.provider}</div>
        <div className="capitalize">{a.type?.replace("_", " ")}</div>
        {a.room && <div>Room {a.room}</div>}
      </div>
    </div>
  );
}

function InfoTile({ label, value }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 font-display text-base font-semibold text-foreground">{value}</div>
    </div>
  );
}

function EmptyCard({ icon: Icon, text }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 px-6 py-12 text-center">
      <Icon className="h-7 w-7 text-muted-foreground/60" />
      <p className="mt-3 max-w-xs text-sm text-muted-foreground">{text}</p>
    </div>
  );
}