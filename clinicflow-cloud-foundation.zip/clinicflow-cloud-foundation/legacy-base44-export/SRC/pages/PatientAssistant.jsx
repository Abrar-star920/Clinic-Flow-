import React, { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import {
  Send, Loader2, Headset, ShieldAlert, ArrowLeft, Bot, UserRound, Lock,
} from "lucide-react";
import ClinicFlowMark from "@/components/branding/ClinicFlowMark";

export default function PatientAssistant() {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const [supportSent, setSupportSent] = useState(false);
  const [sendingSupport, setSendingSupport] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    (async () => {
      if (!user?.email) return;
      try {
        const { items } = await base44.entities.AIMessage.filter(
          { owner_email: user.email },
          { sort: "created_date", limit: 50 }
        );
        setMessages(items.map((m) => ({ role: m.role, content: m.content })));
        const { items: convs } = await base44.entities.AIConversation.filter(
          { owner_email: user.email },
          { sort: "-created_date", limit: 1 }
        );
        if (convs.length) setConversationId(convs[0].id);
      } catch (e) {
        /* first visit: no history yet */
      }
    })();
  }, [user?.email]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    setMessages((m) => [...m, { role: "user", content: text }]);
    setLoading(true);
    try {
      const res = await base44.functions.invoke("patientAssistant", { message: text, conversationId });
      setMessages((m) => [...m, { role: "assistant", content: res.data.reply }]);
      if (res.data.conversationId) setConversationId(res.data.conversationId);
    } catch (err) {
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "Sorry, I couldn't process that right now. Please try again or use “Talk to staff.”" },
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function talkToStaff() {
    if (supportSent || sendingSupport) return;
    setSendingSupport(true);
    try {
      await base44.entities.SupportRequest.create({
        patient_email: user?.email || "",
        patient_name: user?.full_name || "",
        reason: "Patient requested staff assistance from the AI assistant.",
        status: "open",
        source: "assistant",
      });
      setSupportSent(true);
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "I've sent a request to our staff. Someone from the clinic will follow up with you shortly." },
      ]);
    } catch (e) {
      setMessages((m) => [...m, { role: "assistant", content: "I couldn't send the request. Please call the clinic directly." }]);
    } finally {
      setSendingSupport(false);
    }
  }

  return (
    <div className="flex h-screen flex-col bg-surface">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3">
        <Link to="/portal" className="flex items-center gap-2.5">
          <ClinicFlowMark size={32} />
          <div className="leading-tight">
            <div className="font-display text-sm font-extrabold uppercase tracking-[0.06em] text-brand">Clinic Flow</div>
            <div className="text-[11px] text-muted-foreground">Patient Assistant</div>
          </div>
        </Link>
        <Link to="/portal" className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to portal
        </Link>
      </header>

      {/* Disclaimer */}
      <div className="flex items-start gap-2 border-b border-amber-200 bg-amber-50/70 px-4 py-2.5 text-xs text-amber-800">
        <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
        <p>
          You are chatting with an AI assistant. It can't give medical advice. For emergencies call your local emergency number.
          <span className="mx-1">·</span>
          <Link to="/portal" className="font-semibold underline underline-offset-2">Privacy policy</Link>
        </p>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-5">
        <div className="mx-auto max-w-2xl space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-primary">
                <Bot className="h-6 w-6" />
              </div>
              <h2 className="font-display text-lg font-bold text-foreground">How can I help you today?</h2>
              <p className="max-w-sm text-sm text-muted-foreground">
                Ask me about your appointments, bills, insurance coverage, or general clinic questions.
              </p>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={`flex gap-2.5 ${m.role === "user" ? "flex-row-reverse" : ""}`}>
              <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-accent text-primary"}`}>
                {m.role === "user" ? <UserRound className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${m.role === "user" ? "bg-primary text-primary-foreground" : "bg-card text-foreground ring-1 ring-border"}`}>
                <p className="whitespace-pre-wrap">{m.content}</p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent text-primary">
                <Bot className="h-4 w-4" />
              </div>
              <div className="flex items-center gap-1 rounded-2xl bg-card px-4 py-3 ring-1 ring-border">
                <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.3s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.15s]" />
                <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground" />
              </div>
            </div>
          )}
          <div ref={scrollRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-border bg-card px-4 py-3">
        <div className="mx-auto max-w-2xl">
          <div className="mb-2 flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground">
              <Lock className="h-3 w-3" /> Your data is protected under HIPAA
            </span>
            <button
              onClick={talkToStaff}
              disabled={supportSent || sendingSupport}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-muted disabled:opacity-60"
            >
              {sendingSupport ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Headset className="h-3.5 w-3.5" />}
              {supportSent ? "Request sent" : "Talk to staff"}
            </button>
          </div>
          <form onSubmit={send} className="flex items-end gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              rows={1}
              placeholder="Ask about your appointment, bill, or insurance…"
              className="flex-1 resize-none rounded-xl border border-input bg-transparent px-4 py-2.5 text-sm shadow-sm outline-none focus-visible:ring-1 focus-visible:ring-ring"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm transition-colors hover:bg-primary/90 disabled:opacity-50"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}