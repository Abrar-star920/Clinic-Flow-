import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { CreditCard, DollarSign, FileText, Clock, Plus, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import StatCard from "@/components/StatCard";
import StatusBadge from "@/components/StatusBadge";
import NewInvoiceDialog from "@/components/billing/NewInvoiceDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const STATUSES = ["all", "ready", "submitted", "partially_paid", "paid", "denied", "on_hold"];

export default function Billing() {
  const { toast } = useToast();
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [payingId, setPayingId] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const load = () =>
    base44.entities.Claim.list("-created_date", 300).then(setClaims).finally(() => setLoading(false));

  useEffect(() => {
    load();
    const params = new URLSearchParams(window.location.search);
    if (params.get("paid")) toast({ title: "Payment received", description: "The invoice has been marked as paid." });
    if (params.get("cancelled")) toast({ variant: "destructive", title: "Payment cancelled" });
    if (params.get("paid") || params.get("cancelled")) {
      window.history.replaceState({}, "", "/billing");
    }
  }, []);

  const filtered = useMemo(() => {
    return claims.filter((c) => {
      const matchesFilter = filter === "all" || c.status === filter;
      const q = query.toLowerCase();
      const matchesQuery = !q || c.patient_name?.toLowerCase().includes(q) || c.invoice_number?.toLowerCase().includes(q);
      return matchesFilter && matchesQuery;
    });
  }, [claims, filter, query]);

  const stats = useMemo(() => {
    const outstanding = claims.filter((c) => c.status !== "paid").reduce((s, c) => s + Number(c.amount || 0), 0);
    const collected = claims.filter((c) => c.status === "paid").reduce((s, c) => s + Number(c.amount || 0), 0);
    return {
      outstanding,
      collected,
      count: claims.length,
      denied: claims.filter((c) => c.status === "denied").length,
    };
  }, [claims]);

  async function collectPayment(claim) {
    if (window.self !== window.top) {
      toast({
        variant: "destructive",
        title: "Open in published app",
        description: "Stripe checkout works only from the published app, not the preview.",
      });
      return;
    }
    setPayingId(claim.id);
    try {
      const { data } = await base44.functions.invoke("createStripeCheckoutSession", { claim_id: claim.id });
      if (data?.url) window.location.href = data.url;
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Checkout failed",
        description: err?.response?.data?.error || err?.message,
      });
    } finally {
      setPayingId(null);
    }
  }

  const money = (n) => `$${Number(n || 0).toFixed(2)}`;

  return (
    <div>
      <PageHeader
        title="Billing & Payments"
        subtitle="Invoice status, claims, and Stripe payment collection"
        icon={CreditCard}
        actions={
          <Button size="sm" variant="gold" className="h-8 gap-1.5 text-xs" onClick={() => setDialogOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> New Invoice
          </Button>
        }
      />

      <div className="space-y-5 p-6 sm:p-8">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard label="Outstanding" value={money(stats.outstanding)} icon={Clock} accent="amber" />
          <StatCard label="Collected" value={money(stats.collected)} icon={DollarSign} accent="emerald" />
          <StatCard label="Total Invoices" value={stats.count} icon={FileText} accent="sky" />
          <StatCard label="Denied" value={stats.denied} icon={AlertCircle} accent="indigo" />
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex flex-wrap items-center rounded-lg border border-border bg-card p-0.5">
            {STATUSES.map((s) => (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={cn(
                  "rounded-md px-3 py-1.5 text-xs font-semibold capitalize transition-colors",
                  filter === s ? "bg-gold text-gold-foreground" : "text-muted-foreground hover:text-foreground"
                )}
              >
                {s.replace("_", " ")}
              </button>
            ))}
          </div>
          <Input
            placeholder="Search invoices…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="sm:w-72"
          />
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
          <div className="hidden grid-cols-[1.5fr_1fr_1fr_1fr_1fr] gap-4 border-b border-border bg-muted/40 px-5 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground md:grid">
            <span>Patient</span>
            <span>Invoice</span>
            <span>Amount</span>
            <span>Status</span>
            <span className="text-right">Action</span>
          </div>
          <ul className="divide-y divide-border">
            {loading && <li className="px-5 py-10 text-center text-muted-foreground">Loading invoices…</li>}
            {!loading && filtered.length === 0 && (
              <li className="px-5 py-10 text-center text-muted-foreground">No invoices found.</li>
            )}
            {filtered.map((c) => (
              <li
                key={c.id}
                className="grid grid-cols-1 gap-3 px-5 py-4 md:grid-cols-[1.5fr_1fr_1fr_1fr_1fr] md:items-center md:gap-4"
              >
                <div>
                  <div className="font-semibold text-foreground">{c.patient_name}</div>
                  {c.description && <div className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{c.description}</div>}
                </div>
                <div className="text-sm">
                  <div className="font-medium text-foreground">{c.invoice_number || "—"}</div>
                  {c.cpt_codes?.length > 0 && <div className="text-xs text-muted-foreground">{c.cpt_codes.join(", ")}</div>}
                </div>
                <div className="font-display font-bold text-foreground">{money(c.amount)}</div>
                <div><StatusBadge status={c.status} /></div>
                <div className="flex justify-start md:justify-end">
                  {c.status !== "paid" ? (
                    <Button
                      size="sm"
                      variant="gold"
                      className="h-8 gap-1.5 text-xs"
                      disabled={payingId === c.id}
                      onClick={() => collectPayment(c)}
                    >
                      {payingId === c.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CreditCard className="h-3.5 w-3.5" />}
                      Collect
                    </Button>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600">
                      <CheckCircle2 className="h-4 w-4" /> Paid
                    </span>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <NewInvoiceDialog open={dialogOpen} onClose={() => setDialogOpen(false)} onCreated={() => { setDialogOpen(false); load(); }} />
    </div>
  );
}