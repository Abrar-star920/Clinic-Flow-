import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function LogTimeDialog({ patient, user, open, onClose, onLogged }) {
  const { toast } = useToast();
  const [form, setForm] = useState({ session_type: "rpm", minutes: "", notes: "" });
  const [saving, setSaving] = useState(false);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    const mins = Number(form.minutes);
    if (!mins || mins <= 0) return toast({ variant: "destructive", title: "Enter valid minutes" });
    setSaving(true);
    try {
      await base44.entities.RpmSession.create({
        patient_id: patient.id,
        patient_name: patient.full_name,
        patient_email: patient.email,
        session_type: form.session_type,
        minutes: mins,
        notes: form.notes || undefined,
        recorded_at: new Date().toISOString(),
        recorded_by: user?.email || "staff",
      });
      toast({ title: "Monitoring time logged" });
      setForm({ session_type: "rpm", minutes: "", notes: "" });
      onLogged();
    } catch (err) {
      toast({ variant: "destructive", title: "Could not log time", description: err?.message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Log Monitoring Time — {patient?.full_name}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Type</Label>
              <select
                value={form.session_type}
                onChange={(e) => update("session_type", e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
              >
                <option value="rpm">RPM</option>
                <option value="ccm">CCM</option>
              </select>
            </div>
            <div className="space-y-1.5">
              <Label>Minutes</Label>
              <Input type="number" min="1" value={form.minutes} onChange={(e) => update("minutes", e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Textarea rows={2} value={form.notes} onChange={(e) => update("notes", e.target.value)} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 animate-spin" />} Log Time
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}