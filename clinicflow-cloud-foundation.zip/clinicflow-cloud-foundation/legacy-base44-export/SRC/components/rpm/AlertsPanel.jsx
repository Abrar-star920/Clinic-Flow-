import React, { useMemo } from "react";
import { AlertTriangle, TrendingDown, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

const RANGES = {
  bp_systolic: { low: 90, high: 140, unit: "mmHg" },
  bp_diastolic: { low: 60, high: 90, unit: "mmHg" },
  heart_rate: { low: 50, high: 100, unit: "bpm" },
  temperature: { low: 95, high: 100.4, unit: "°F" },
  spo2: { low: 92, high: null, unit: "%" },
  respiratory_rate: { low: 12, high: 20, unit: "/min" },
  glucose: { low: 70, high: 180, unit: "mg/dL" },
};

const LABELS = {
  bp_systolic: "BP Systolic", bp_diastolic: "BP Diastolic", heart_rate: "Heart Rate",
  temperature: "Temperature", spo2: "SpO2", respiratory_rate: "Respiratory Rate", glucose: "Glucose",
};

export function readingAlert(v) {
  const r = RANGES[v.type];
  if (!r) return null;
  if (r.high != null && v.value > r.high) return { dir: "high" };
  if (r.low != null && v.value < r.low) return { dir: "low" };
  return null;
}

export function alertSummary(vitals) {
  const seen = {};
  vitals.forEach((v) => {
    const a = readingAlert(v);
    if (!a) return;
    const prev = seen[v.type];
    const date = v.recorded_at || "";
    if (!prev || date > prev.date) seen[v.type] = { value: v.value, dir: a.dir, date, unit: RANGES[v.type]?.unit };
  });
  return Object.entries(seen).map(([type, info]) => ({ type, ...info }));
}

export default function AlertsPanel({ alerts }) {
  const items = useMemo(() => alerts, [alerts]);
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-center gap-2">
        <AlertTriangle className="h-4 w-4 text-amber-500" />
        <h3 className="font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">Device Alerts</h3>
      </div>
      {items.length === 0 ? (
        <div className="mt-4 flex flex-col items-center py-6 text-center">
          <span className="text-xs font-semibold uppercase tracking-wide text-emerald-600">All readings in range</span>
          <p className="mt-1 text-xs text-muted-foreground">No abnormal vital readings for this patient.</p>
        </div>
      ) : (
        <ul className="mt-3 space-y-2">
          {items.map((a) => (
            <li key={a.type} className="flex items-center justify-between rounded-lg border border-border bg-amber-50/50 px-3 py-2">
              <div className="flex items-center gap-2">
                {a.dir === "high" ? <TrendingUp className="h-4 w-4 text-rose-500" /> : <TrendingDown className="h-4 w-4 text-sky-500" />}
                <span className="text-sm font-medium text-foreground">{LABELS[a.type] || a.type}</span>
              </div>
              <div className="text-right">
                <span className={cn("font-display text-sm font-bold", a.dir === "high" ? "text-rose-600" : "text-sky-600")}>
                  {a.value}{a.unit ? ` ${a.unit}` : ""}
                </span>
                <span className="ml-1 text-[10px] font-semibold uppercase text-muted-foreground">{a.dir}</span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}