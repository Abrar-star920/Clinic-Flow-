import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Activity, Loader2, TrendingUp, TrendingDown, AlertTriangle, ArrowUpRight,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, ReferenceLine,
} from "recharts";
import { cn } from "@/lib/utils";
import { readingAlert } from "@/components/rpm/AlertsPanel";
import { Link } from "react-router-dom";

const METRICS = [
  { key: "bp_systolic", label: "Systolic BP", unit: "mmHg", color: "hsl(var(--chart-1))", low: 90, high: 140 },
  { key: "heart_rate", label: "Heart Rate", unit: "bpm", color: "#ef4444", low: 50, high: 100 },
  { key: "spo2", label: "SpO₂", unit: "%", color: "#8b5cf6", low: 92, high: null },
  { key: "glucose", label: "Glucose", unit: "mg/dL", color: "#ec4899", low: 70, high: 180 },
  { key: "temperature", label: "Temperature", unit: "°F", color: "#f59e0b", low: 95, high: 100.4 },
  { key: "respiratory_rate", label: "Resp Rate", unit: "/min", color: "#14b8a6", low: 12, high: 20 },
];

const LABELS = {
  bp_systolic: "Systolic BP", bp_diastolic: "Diastolic BP", heart_rate: "Heart Rate",
  temperature: "Temperature", spo2: "SpO₂", respiratory_rate: "Respiratory Rate", glucose: "Glucose",
};

function unitFor(type) {
  return METRICS.find((m) => m.key === type)?.unit || "";
}

function daysAgo(iso) {
  if (!iso) return "—";
  const diff = Date.now() - new Date(iso).getTime();
  const d = Math.floor(diff / 86400000);
  if (d <= 0) return "today";
  if (d === 1) return "1 day ago";
  return `${d} days ago`;
}

export default function VitalsTrendsWidget() {
  const [vitals, setVitals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [metric, setMetric] = useState("bp_systolic");

  useEffect(() => {
    let active = true;
    base44.entities.VitalReading.list("-recorded_at", 500)
      .then((v) => active && setVitals(v || []))
      .finally(() => active && setLoading(false));
    return () => { active = false; };
  }, []);

  const activeMetric = METRICS.find((m) => m.key === metric);

  // 30-day daily averages for the selected metric
  const trend = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const dayMs = 86400000;
    const buckets = [];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(now.getTime() - i * dayMs);
      buckets.push({
        key: d.toISOString().slice(0, 10),
        label: d.toLocaleDateString("en-US", { month: "short", day: "numeric" }),
        sum: 0, n: 0,
      });
    }
    const idx = new Map(buckets.map((b, i) => [b.key, i]));
    for (const v of vitals) {
      if (v.type !== metric || !v.recorded_at) continue;
      const i = idx.get(new Date(v.recorded_at).toISOString().slice(0, 10));
      if (i === undefined) continue;
      buckets[i].sum += Number(v.value) || 0;
      buckets[i].n += 1;
    }
    return buckets.map((b) => ({ label: b.label, avg: b.n ? Math.round(b.sum / b.n) : null }));
  }, [vitals, metric]);

  // week-over-week delta for the selected metric
  const delta = useMemo(() => {
    const recent = trend.slice(-7).filter((t) => t.avg != null);
    const prev = trend.slice(-14, -7).filter((t) => t.avg != null);
    if (!recent.length || !prev.length) return null;
    const rAvg = Math.round(recent.reduce((s, t) => s + t.avg, 0) / recent.length);
    const pAvg = Math.round(prev.reduce((s, t) => s + t.avg, 0) / prev.length);
    return { value: rAvg - pAvg, recent: rAvg };
  }, [trend]);

  // latest abnormal readings across all patients, to surface critical changes
  const critical = useMemo(() => {
    const latest = new Map();
    for (const v of vitals) {
      const k = `${v.patient_id}|${v.type}`;
      const ex = latest.get(k);
      if (!ex || new Date(v.recorded_at) > new Date(ex.recorded_at)) latest.set(k, v);
    }
    const flagged = [];
    for (const v of latest.values()) {
      const a = readingAlert(v);
      if (a) flagged.push({ ...v, dir: a.dir });
    }
    flagged.sort((x, y) => (x.dir === "high" ? 0 : 1) - (y.dir === "high" ? 0 : 1));
    return flagged.slice(0, 6);
  }, [vitals]);

  const stats = useMemo(() => {
    const inRange = vitals.filter((v) => v.type === metric).length;
    const abnormal = critical.length;
    const patients = new Set(vitals.map((v) => v.patient_id).filter(Boolean)).size;
    return { readings: inRange, abnormal, patients };
  }, [vitals, metric, critical]);

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex flex-col gap-3 border-b border-border bg-gradient-to-r from-sky-50/70 to-teal-50/40 px-5 py-3.5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-sky-500 to-teal-500 text-white shadow-soft">
            <Activity className="h-4 w-4" />
          </div>
          <div>
            <h3 className="font-display text-sm font-bold tracking-tight text-foreground">30-Day Vitals Trends</h3>
            <p className="text-[11px] text-muted-foreground">Spot critical health changes across monitored patients</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {METRICS.map((m) => (
            <button
              key={m.key}
              onClick={() => setMetric(m.key)}
              className={cn(
                "rounded-md px-2.5 py-1 text-[11px] font-semibold transition-colors",
                metric === m.key ? "bg-gold text-gold-foreground shadow-sm" : "bg-muted text-muted-foreground hover:text-foreground"
              )}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      ) : (
        <div className="grid gap-0 lg:grid-cols-5">
          {/* Trend chart */}
          <div className="border-b border-border p-5 lg:col-span-3 lg:border-b-0 lg:border-r">
            <div className="mb-1 flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Avg {activeMetric.label} · 30 days
              </span>
              {delta && (
                <span
                  className={cn(
                    "inline-flex items-center gap-1 text-xs font-semibold",
                    delta.value > 0 ? "text-rose-600" : delta.value < 0 ? "text-emerald-600" : "text-muted-foreground"
                  )}
                >
                  {delta.value > 0 ? <TrendingUp className="h-3.5 w-3.5" /> : delta.value < 0 ? <TrendingDown className="h-3.5 w-3.5" /> : null}
                  {delta.value > 0 ? "+" : ""}{delta.value} {activeMetric.unit} vs last week
                </span>
              )}
            </div>
            <div className="h-44">
              {trend.some((t) => t.avg != null) ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trend} margin={{ top: 8, right: 8, bottom: 0, left: -22 }}>
                    <defs>
                      <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={activeMetric.color} stopOpacity={0.35} />
                        <stop offset="100%" stopColor={activeMetric.color} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis dataKey="label" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} interval={4} />
                    <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={40} />
                    <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid hsl(var(--border))", fontSize: 12 }} />
                    {activeMetric.high != null && (
                      <ReferenceLine y={activeMetric.high} stroke="#f43f5e" strokeDasharray="4 4" strokeOpacity={0.6} />
                    )}
                    {activeMetric.low != null && (
                      <ReferenceLine y={activeMetric.low} stroke="#0ea5e9" strokeDasharray="4 4" strokeOpacity={0.6} />
                    )}
                    <Area type="monotone" dataKey="avg" name={activeMetric.label} stroke={activeMetric.color} strokeWidth={2.5} fill="url(#trendFill)" connectNulls />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
                  No {activeMetric.label} readings in the last 30 days
                </div>
              )}
            </div>

            <div className="mt-4 grid grid-cols-3 gap-3">
              <MiniStat label="Monitored patients" value={stats.patients} icon={Activity} />
              <MiniStat label={`${activeMetric.label} readings`} value={stats.readings} icon={TrendingUp} />
              <MiniStat label="Flagged readings" value={stats.abnormal} icon={AlertTriangle} accent="rose" />
            </div>
          </div>

          {/* Critical changes */}
          <div className="p-5 lg:col-span-2">
            <div className="mb-2 flex items-center gap-1.5">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Critical changes</span>
            </div>
            {critical.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-8 text-center">
                <Activity className="h-6 w-6 text-emerald-500" />
                <p className="mt-2 text-xs text-muted-foreground">All latest vitals within range</p>
              </div>
            ) : (
              <ul className="space-y-2">
                {critical.map((c) => (
                  <li key={c.id}>
                    <Link
                      to={`/patients/${c.patient_id}`}
                      className="block rounded-lg border border-border bg-background/50 p-3 transition-colors hover:border-primary/40 hover:bg-accent"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-sm font-semibold text-foreground">{c.patient_name || "Unknown"}</span>
                        <span
                          className={cn(
                            "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase",
                            c.dir === "high"
                              ? "bg-rose-100 text-rose-700 ring-1 ring-rose-200"
                              : "bg-sky-100 text-sky-700 ring-1 ring-sky-200"
                          )}
                        >
                          {c.dir === "high" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                          {c.dir}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[11px] text-muted-foreground">
                        <span>
                          {LABELS[c.type] || c.type}:{" "}
                          <span className="font-semibold text-foreground">{c.value} {unitFor(c.type)}</span>
                        </span>
                        <span>{daysAgo(c.recorded_at)}</span>
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
            <Link to="/rpm" className="mt-3 inline-flex items-center gap-0.5 text-xs font-semibold text-primary hover:underline">
              Open RPM <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value, icon: Icon, accent = "default" }) {
  return (
    <div className="rounded-lg border border-border bg-background/50 p-2.5">
      <div className={cn("flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide", accent === "rose" ? "text-rose-600" : "text-muted-foreground")}>
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className="mt-0.5 font-display text-base font-bold text-foreground">{value}</div>
    </div>
  );
}