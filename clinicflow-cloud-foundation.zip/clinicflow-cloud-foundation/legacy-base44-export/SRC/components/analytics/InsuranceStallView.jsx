import React, { useMemo } from "react";
import { Link } from "react-router-dom";
import { ShieldQuestion, Hourglass, AlertOctagon, ChevronRight } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { cn } from "@/lib/utils";

const STALL_STATUSES = ["pending", "unverified", "denied"];
const dayMs = 24 * 60 * 60 * 1000;

function stallTier(days) {
  if (days >= 14) return { key: "critical", label: "Critical", cls: "bg-rose-100 text-rose-700 ring-1 ring-rose-200" };
  if (days >= 7) return { key: "high", label: "High", cls: "bg-orange-100 text-orange-700 ring-1 ring-orange-200" };
  if (days >= 3) return { key: "medium", label: "Medium", cls: "bg-amber-100 text-amber-700 ring-1 ring-amber-200" };
  return { key: "low", label: "Recent", cls: "bg-slate-100 text-slate-600 ring-1 ring-slate-200" };
}

export default function InsuranceStallView({ patients, loading }) {
  const stalled = useMemo(() => {
    const now = Date.now();
    return patients
      .filter((p) => STALL_STATUSES.includes(p.insurance_status))
      .map((p) => {
        const created = new Date(p.created_date).getTime();
        const days = isNaN(created) ? 0 : Math.floor((now - created) / dayMs);
        return { ...p, daysStalled: days };
      })
      .sort((a, b) => b.daysStalled - a.daysStalled);
  }, [patients]);

  const summary = useMemo(() => {
    if (!stalled.length) return { count: 0, avg: 0, max: 0, critical: 0 };
    const sum = stalled.reduce((s, p) => s + p.daysStalled, 0);
    return {
      count: stalled.length,
      avg: Math.round(sum / stalled.length),
      max: stalled[0].daysStalled,
      critical: stalled.filter((p) => p.daysStalled >= 14).length,
    };
  }, [stalled]);

  const buckets = useMemo(() => {
    const b = { critical: 0, high: 0, medium: 0, low: 0 };
    stalled.forEach((p) => { b[stallTier(p.daysStalled).key]++; });
    return b;
  }, [stalled]);

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm lg:col-span-2">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h3 className="font-display text-sm font-bold text-foreground">Insurance Verification Backlog</h3>
          <p className="text-xs text-muted-foreground">
            Patients stalled in pending / unverified / denied — ranked by days waiting.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <MiniStat icon={Hourglass} label="Stalled" value={summary.count} />
          <MiniStat icon={AlertOctagon} label="Avg days" value={summary.avg} />
          <MiniStat icon={ShieldQuestion} label="Oldest" value={`${summary.max}d`} />
        </div>
      </div>

      {/* Stall distribution bar */}
      {stalled.length > 0 && (
        <div className="mb-4">
          <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-muted">
            {["critical", "high", "medium", "low"].map((k) => {
              const w = stalled.length ? (buckets[k] / stalled.length) * 100 : 0;
              if (!w) return null;
              const color = { critical: "bg-rose-500", high: "bg-orange-500", medium: "bg-amber-500", low: "bg-slate-400" }[k];
              return <div key={k} className={cn("h-full", color)} style={{ width: `${w}%` }} />;
            })}
          </div>
          <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
            <Legend color="bg-rose-500" label={`Critical (14d+) · ${buckets.critical}`} />
            <Legend color="bg-orange-500" label={`High (7–13d) · ${buckets.high}`} />
            <Legend color="bg-amber-500" label={`Medium (3–6d) · ${buckets.medium}`} />
            <Legend color="bg-slate-400" label={`Recent (0–2d) · ${buckets.low}`} />
          </div>
        </div>
      )}

      {loading ? (
        <div className="space-y-2">
          {[0, 1, 2, 3].map((i) => <div key={i} className="h-12 animate-pulse rounded-lg bg-muted" />)}
        </div>
      ) : stalled.length === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-accent text-primary">
            <ShieldQuestion className="h-5 w-5" />
          </div>
          <p className="text-sm text-muted-foreground">No patients stalled in insurance verification.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                <th className="pb-2 pr-3 font-semibold">Patient</th>
                <th className="pb-2 pr-3 font-semibold">Status</th>
                <th className="hidden pb-2 pr-3 font-semibold sm:table-cell">Provider</th>
                <th className="hidden pb-2 pr-3 font-semibold md:table-cell">Member ID</th>
                <th className="pb-2 pr-3 text-right font-semibold">Days stalled</th>
                <th className="pb-2 pl-3 font-semibold">Tier</th>
                <th className="pb-2" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {stalled.slice(0, 25).map((p) => {
                const tier = stallTier(p.daysStalled);
                return (
                  <tr key={p.id} className="transition-colors hover:bg-muted/40">
                    <td className="py-2.5 pr-3">
                      <Link to={`/patients/${p.id}`} className="font-medium text-foreground hover:text-primary">
                        {p.full_name}
                      </Link>
                      <div className="text-[11px] text-muted-foreground">
                        Added {new Date(p.created_date).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                      </div>
                    </td>
                    <td className="py-2.5 pr-3"><StatusBadge status={p.insurance_status} /></td>
                    <td className="hidden py-2.5 pr-3 text-muted-foreground sm:table-cell">{p.insurance_provider || "—"}</td>
                    <td className="hidden py-2.5 pr-3 font-mono text-xs text-muted-foreground md:table-cell">{p.insurance_member_id || "—"}</td>
                    <td className="py-2.5 pr-3 text-right font-display font-bold tabular-nums text-foreground">{p.daysStalled}d</td>
                    <td className="py-2.5 pl-3">
                      <span className={cn("inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", tier.cls)}>
                        {tier.label}
                      </span>
                    </td>
                    <td className="py-2.5 pl-2 text-right">
                      <Link to={`/patients/${p.id}`} className="text-muted-foreground hover:text-primary">
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {stalled.length > 25 && (
            <div className="pt-3 text-center text-xs text-muted-foreground">
              Showing 25 of {stalled.length} stalled patients
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MiniStat({ icon: Icon, label, value }) {
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-1 text-foreground">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
        <span className="font-display text-lg font-bold tabular-nums">{value}</span>
      </div>
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}

function Legend({ color, label }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className={cn("h-2.5 w-2.5 rounded-full", color)} />
      {label}
    </div>
  );
}