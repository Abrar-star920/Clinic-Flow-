import React, { useMemo } from "react";
import { Stethoscope, TrendingUp, CalendarDays } from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";

const PALETTE = ["#0ea5e9", "#14b8a6", "#6366f1", "#f59e0b", "#ec4899", "#10b981", "#8b5cf6", "#f43f5e", "#22d3ee", "#a3e635"];
const MONTHS = 12;

export default function ProcedureVolumeChart({ procedures }) {
  const { data, procNames, summary } = useMemo(() => {
    const dayMs = 24 * 60 * 60 * 1000;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const buckets = [];
    for (let i = MONTHS - 1; i >= 0; i--) {
      const d = new Date(today.getTime() - i * 30.44 * dayMs);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      buckets.push({
        key,
        label: d.toLocaleDateString(undefined, { month: "short" }) + " " + String(d.getFullYear()).slice(2),
        byName: {},
      });
    }
    const idx = new Map(buckets.map((b, i) => [b.key, i]));

    let total = 0;
    const nameTotals = {};
    procedures.forEach((p) => {
      const raw = p.scheduled_date;
      if (!raw) return;
      const t = new Date(raw).getTime();
      if (isNaN(t)) return;
      const key = new Date(raw).toISOString().slice(0, 7);
      const i = idx.get(key);
      if (i === undefined) return;
      const name = p.name || "Unknown";
      buckets[i].byName[name] = (buckets[i].byName[name] || 0) + 1;
      nameTotals[name] = (nameTotals[name] || 0) + 1;
      total++;
    });

    const procNames = Object.entries(nameTotals)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([n]) => n);

    const data = buckets.map((b) => {
      const row = { month: b.label };
      procNames.forEach((n) => { row[n] = b.byName[n] || 0; });
      return row;
    });

    const monthCounts = buckets.map((b) => Object.values(b.byName).reduce((s, v) => s + v, 0));
    const busiestIdx = monthCounts.reduce((best, c, i) => (c > monthCounts[best] ? i : best), 0);

    const summary = {
      total,
      topProcedure: procNames[0] || "—",
      busiestMonth: buckets[busiestIdx]?.label || "—",
    };
    return { data, procNames, summary };
  }, [procedures]);

  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-sm lg:col-span-2">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h3 className="font-display text-sm font-bold text-foreground">Procedure Volume by Month</h3>
          <p className="text-xs text-muted-foreground">
            Most frequently performed procedures over the last 12 months — for resource planning.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <MiniStat icon={Stethoscope} label="Procedures" value={summary.total} />
          <MiniStat icon={TrendingUp} label="Top" value={summary.topProcedure} text />
          <MiniStat icon={CalendarDays} label="Busiest" value={summary.busiestMonth} text />
        </div>
      </div>

      {summary.total === 0 ? (
        <div className="flex flex-col items-center justify-center gap-2 py-12 text-center">
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-accent text-primary">
            <Stethoscope className="h-5 w-5" />
          </div>
          <p className="text-sm text-muted-foreground">No procedures scheduled in the last 12 months.</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data} margin={{ left: -16 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
            <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} allowDecimals={false} />
            <Tooltip
              contentStyle={{ borderRadius: 8, border: "1px solid hsl(var(--border))", fontSize: 12 }}
              cursor={{ fill: "hsl(var(--muted))" }}
            />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            {procNames.map((n, i) => (
              <Bar key={n} dataKey={n} stackId="a" fill={PALETTE[i % PALETTE.length]} radius={i === procNames.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]} />
            ))}
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}

function MiniStat({ icon: Icon, label, value, text }) {
  return (
    <div className="text-center">
      <div className="flex items-center justify-center gap-1 text-foreground">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
        <span className={text ? "font-display text-sm font-bold" : "font-display text-lg font-bold tabular-nums"}>{value}</span>
      </div>
      <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}