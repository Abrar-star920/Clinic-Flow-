import React from "react";
import StatusBadge from "@/components/StatusBadge";
import { User, Stethoscope, DoorClosed } from "lucide-react";
import { cn } from "@/lib/utils";
import Avatar from "@/components/Avatar";

const SLOT_MINUTES = 30;
const ROW_HEIGHT = 44; // px per 30-min slot
const START_HOUR = 8; // 08:00
const END_HOUR = 17; // 17:00

function timeToMinutes(time) {
  if (!time) return null;
  const [h, m] = time.split(":").map(Number);
  return h * 60 + m;
}

function formatHour(h) {
  const period = h >= 12 ? "PM" : "AM";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:00 ${period}`;
}

const TYPE_ACCENT = {
  new_patient: "border-l-sky-400 bg-sky-50",
  follow_up: "border-l-teal-400 bg-teal-50",
  procedure: "border-l-indigo-400 bg-indigo-50",
  telehealth: "border-l-violet-400 bg-violet-50",
  lab_work: "border-l-amber-400 bg-amber-50",
};

export default function ProviderCalendar({ appointments, providers, doctorMap, onAdvance }) {
  const startMin = START_HOUR * 60;
  const endMin = END_HOUR * 60;
  const slotCount = (endMin - startMin) / SLOT_MINUTES;
  const slots = Array.from({ length: slotCount }, (_, i) => startMin + i * SLOT_MINUTES);
  const hours = [];
  for (let h = START_HOUR; h <= END_HOUR; h++) hours.push(h);

  const advanceMap = {
    scheduled: { label: "Confirm", next: "confirmed", variant: "outline" },
    confirmed: { label: "Check In", next: "checked_in", variant: "outline" },
    checked_in: { label: "Start", next: "in_progress", variant: "default" },
    in_progress: { label: "Complete", next: "completed", variant: "default" },
  };

  return (
    <div className="overflow-x-auto rounded-xl border border-border bg-card shadow-sm">
      <div className="min-w-[820px]">
        {/* Provider header row */}
        <div
          className="grid border-b border-border bg-muted/40"
          style={{ gridTemplateColumns: `72px repeat(${providers.length}, minmax(0, 1fr))` }}
        >
          <div className="px-3 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
            Time
          </div>
          {providers.map((p) => (
            <div
              key={p}
              className="flex items-center gap-2 border-l border-border px-3 py-2 text-xs font-bold text-foreground"
            >
              <Avatar name={p} src={doctorMap?.get(p)?.photo_url} size="sm" />
              <span className="truncate">{p}</span>
            </div>
          ))}
        </div>

        {/* Grid body */}
        <div
          className="relative grid"
          style={{
            gridTemplateColumns: `72px repeat(${providers.length}, minmax(0, 1fr))`,
          }}
        >
          {/* Time gutter */}
          <div className="relative">
            {hours.map((h, idx) => (
              <div
                key={h}
                className="absolute right-2 -translate-y-1/2 text-[10px] font-medium text-muted-foreground"
                style={{ top: (h - START_HOUR) * 60 * (ROW_HEIGHT / SLOT_MINUTES) }}
              >
                {idx === hours.length - 1 ? "" : formatHour(h)}
              </div>
            ))}
            {/* total height spacer */}
            <div style={{ height: slotCount * ROW_HEIGHT }} />
          </div>

          {/* Provider columns */}
          {providers.map((provider) => {
            const colAppts = appointments.filter((a) => a.provider === provider);
            return (
              <div key={provider} className="relative border-l border-border">
                {/* slot gridlines */}
                {slots.map((s, i) => (
                  <div
                    key={s}
                    className={cn(
                      "absolute left-0 right-0 border-t",
                      s % 60 === 0 ? "border-border/80" : "border-border/40"
                    )}
                    style={{ top: i * ROW_HEIGHT, height: ROW_HEIGHT }}
                  />
                ))}
                {/* appointments */}
                {colAppts.map((a) => {
                  const startM = timeToMinutes(a.appointment_time);
                  if (startM == null || startM < startMin || startM >= endMin) return null;
                  const top = ((startM - startMin) / SLOT_MINUTES) * ROW_HEIGHT;
                  const duration = a.duration_minutes || 30;
                  const height = Math.max((duration / SLOT_MINUTES) * ROW_HEIGHT - 4, 36);
                  const accent = TYPE_ACCENT[a.type] || "border-l-slate-300 bg-slate-50";
                  const action = advanceMap[a.status];
                  return (
                    <div
                      key={a.id}
                      className={cn(
                        "absolute left-1 right-1 overflow-hidden rounded-md border-l-[3px] px-2 py-1 shadow-sm",
                        accent
                      )}
                      style={{ top: top + 2, height }}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="truncate text-[11px] font-bold text-foreground">{a.patient_name}</span>
                        <span className="shrink-0 text-[9px] font-semibold text-muted-foreground">{a.appointment_time?.slice(0, 5)}</span>
                      </div>
                      <div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-muted-foreground">
                        <span className="capitalize">{a.type?.replace("_", " ")}</span>
                        {a.room && <span className="flex items-center gap-0.5"><DoorClosed className="h-2.5 w-2.5" />{a.room}</span>}
                      </div>
                      <div className="mt-1 flex items-center justify-between gap-1">
                        <StatusBadge status={a.status} className="px-1.5 py-0.5 text-[9px]" />
                        {action && (
                          <button
                            onClick={() => onAdvance(a.id, action.next)}
                            className={cn(
                              "rounded px-1.5 py-0.5 text-[9px] font-semibold transition-colors",
                              action.variant === "default"
                                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                                : "border border-border bg-card text-foreground hover:bg-muted"
                            )}
                          >
                            {action.label}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
                {/* height spacer */}
                <div style={{ height: slotCount * ROW_HEIGHT }} />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}