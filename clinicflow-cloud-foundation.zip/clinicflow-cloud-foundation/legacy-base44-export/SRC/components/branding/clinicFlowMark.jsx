import React from "react";
import { cn } from "@/lib/utils";

// Original scalloped "stamp" icon path: a ring of touching semicircle bumps
// bulging outward from a base circle, drawn once at module load.
function scallopedCircle(cx, cy, R, N) {
  const half = Math.PI / N;
  const r = R * Math.sin(half);
  let d = "";
  for (let i = 0; i < N; i++) {
    const a1 = (2 * Math.PI * i) / N - half;
    const a2 = (2 * Math.PI * (i + 1)) / N - half;
    const x1 = cx + R * Math.cos(a1);
    const y1 = cy + R * Math.sin(a1);
    const x2 = cx + R * Math.cos(a2);
    const y2 = cy + R * Math.sin(a2);
    if (i === 0) d += `M ${x1.toFixed(2)} ${y1.toFixed(2)} `;
    d += `A ${r.toFixed(2)} ${r.toFixed(2)} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)} `;
  }
  return d + "Z";
}
const SCALLOPED = scallopedCircle(50, 50, 41, 16);

export default function ClinicFlowMark({ size = 36, className }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className={className}
      role="img"
      aria-label="ClinicFlow"
    >
      <path d={SCALLOPED} fill="hsl(var(--brand))" />
      <text
        x="50"
        y="54"
        textAnchor="middle"
        dominantBaseline="middle"
        fontFamily="'Inter', ui-sans-serif, system-ui, sans-serif"
        fontWeight="800"
        fontSize="40"
        letterSpacing="-3"
        fill="#ffffff"
      >
        cf
      </text>
    </svg>
  );
}

export function ClinicFlowLogo({ size = 36, className, light = false }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <ClinicFlowMark size={size} />
      <span
        className={cn(
          "font-display text-[17px] font-extrabold uppercase tracking-[0.06em]",
          light ? "text-white" : "text-brand"
        )}
      >
        Clinic Flow
      </span>
    </div>
  );
}