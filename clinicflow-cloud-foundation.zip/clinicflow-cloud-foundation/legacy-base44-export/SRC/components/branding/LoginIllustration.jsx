import React from "react";

export default function LoginIllustration({ className }) {
  return (
    <svg viewBox="0 0 520 560" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Clinic staff illustration">
      <rect width="520" height="560" rx="28" fill="#E0F3DF" />
      <circle cx="260" cy="210" r="150" fill="#ffffff" opacity="0.55" />

      {/* calendar card */}
      <rect x="92" y="96" width="150" height="120" rx="16" fill="#ffffff" />
      <rect x="92" y="96" width="150" height="34" rx="16" fill="#1f9c92" />
      <rect x="110" y="150" width="24" height="24" rx="6" fill="#E0F3DF" />
      <rect x="142" y="150" width="24" height="24" rx="6" fill="#1f9c92" />
      <rect x="174" y="150" width="24" height="24" rx="6" fill="#E0F3DF" />
      <rect x="110" y="182" width="24" height="24" rx="6" fill="#E0F3DF" />
      <rect x="142" y="182" width="24" height="24" rx="6" fill="#E0F3DF" />
      <rect x="174" y="182" width="24" height="24" rx="6" fill="#1f9c92" opacity="0.6" />

      {/* heart */}
      <path d="M390 150c-10-14-32-14-40 2-8-16-30-16-40-2-9 13-3 30 8 41l32 28 32-28c11-11 17-28 8-41z" fill="#ff7a7a" opacity="0.9" />
      <path d="M370 168l-4 8 8-2 6 10 2-12 8-2-8-4 2-8-8 4-6-8-2 10z" fill="#fff" opacity="0.7" />

      {/* doctor */}
      <g>
        <rect x="210" y="250" width="120" height="150" rx="20" fill="#ffffff" />
        <circle cx="270" cy="300" r="34" fill="#ffd9c2" />
        <path d="M238 296c0-22 14-38 32-38s32 16 32 38c0 6-2 12-2 12s-4-22-30-22-30 22-30 22-2-6-2-12z" fill="#3a3a44" />
        <rect x="252" y="328" width="36" height="14" rx="7" fill="#ffd9c2" />
        <path d="M232 350h76l8 50h-92z" fill="#1f9c92" />
        <rect x="258" y="362" width="24" height="30" rx="6" fill="#ffffff" />
        <path d="M270 366v22M259 377h22" stroke="#1f9c92" strokeWidth="3" strokeLinecap="round" />
      </g>

      {/* stethoscope */}
      <path d="M150 420c0 30 24 54 54 54s54-24 54-54" stroke="#2f8f86" strokeWidth="8" fill="none" strokeLinecap="round" />
      <circle cx="150" cy="412" r="12" fill="#2f8f86" />
      <circle cx="258" cy="412" r="12" fill="#2f8f86" />

      {/* chart */}
      <rect x="330" y="360" width="120" height="120" rx="16" fill="#ffffff" />
      <path d="M348 450v-40M372 450v-64M396 450v-30M420 450v-52" stroke="#1f9c92" strokeWidth="8" strokeLinecap="round" />
      <path d="M348 410l24-24 24 14 24-26" stroke="#7ed3a8" strokeWidth="4" strokeLinecap="round" fill="none" />

      {/* medical cross badge */}
      <g>
        <circle cx="300" cy="250" r="26" fill="#1f9c92" />
        <path d="M300 236v28M286 250h28" stroke="#fff" strokeWidth="6" strokeLinecap="round" />
      </g>
    </svg>
  );
}