import React from "react";
import { cn } from "@/lib/utils";

const accents = {
  sky: "from-blue-50 to-blue-100/60 text-[#005696] ring-blue-100",
  teal: "from-teal-50 to-teal-100/50 text-teal-600 ring-teal-100",
  amber: "from-amber-50 to-amber-100/50 text-amber-600 ring-amber-100",
  rose: "from-rose-50 to-rose-100/50 text-rose-600 ring-rose-100",
  indigo: "from-indigo-50 to-indigo-100/50 text-indigo-600 ring-indigo-100",
  emerald: "from-emerald-50 to-emerald-100/50 text-emerald-600 ring-emerald-100",
  gold: "from-amber-50 to-amber-100/70 text-[#b8860b] ring-amber-200",
};

export default function StatCard({ label, value, icon: Icon, accent = "sky", hint }) {
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-border bg-card p-5 shadow-soft transition-all duration-200 hover:-translate-y-0.5 hover:shadow-card">
      <div className="flex items-start justify-between gap-3">
        <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">{label}</span>
        {Icon && (
          <div className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ring-1", accents[accent])}>
            <Icon className="h-[18px] w-[18px]" />
          </div>
        )}
      </div>
      <div className="mt-4 font-display text-3xl font-bold tracking-tight tabular-nums text-foreground">{value}</div>
      {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
    </div>
  );
}