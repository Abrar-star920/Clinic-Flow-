import React, { useEffect, useRef, useState } from "react";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Loader2, LogOut } from "lucide-react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";

const IDLE_MS = 15 * 60 * 1000; // 15 minutes
const WARN_MS = 60 * 1000; // 60 second warning

export default function InactivityLogout() {
  const { isAuthenticated, logout } = useAuth();
  const [warning, setWarning] = useState(false);
  const [countdown, setCountdown] = useState(WARN_MS);
  const last = useRef(Date.now());
  const warnTimer = useRef(null);
  const tickTimer = useRef(null);

  function bump() {
    last.current = Date.now();
    setWarning(false);
  }

  useEffect(() => {
    if (!isAuthenticated) return;
    const events = ["mousedown", "keydown", "touchstart", "scroll", "mousemove"];
    events.forEach((e) => window.addEventListener(e, bump, { passive: true }));
    warnTimer.current = setInterval(() => {
      const elapsed = Date.now() - last.current;
      if (!warning && elapsed >= IDLE_MS - WARN_MS) setWarning(true);
    }, 1000);
    return () => {
      events.forEach((e) => window.removeEventListener(e, bump));
      if (warnTimer.current) clearInterval(warnTimer.current);
      if (tickTimer.current) clearInterval(tickTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated]);

  useEffect(() => {
    if (!warning) {
      if (tickTimer.current) clearInterval(tickTimer.current);
      return;
    }
    const deadline = last.current + IDLE_MS;
    tickTimer.current = setInterval(() => {
      const remaining = deadline - Date.now();
      setCountdown(remaining);
      if (remaining <= 0) {
        clearInterval(tickTimer.current);
        logout(true);
      }
    }, 250);
    return () => tickTimer.current && clearInterval(tickTimer.current);
  }, [warning, logout]);

  if (!isAuthenticated) return null;
  const secs = Math.max(0, Math.ceil(countdown / 1000));

  return (
    <Dialog open={warning} onOpenChange={(v) => { if (v) return; bump(); }}>
      <DialogContent className="max-w-sm" onCloseAutoFocus={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <LogOut className="h-5 w-5 text-primary" /> Still there?
          </DialogTitle>
          <DialogDescription>
            For your security, you'll be signed out automatically due to inactivity.
          </DialogDescription>
        </DialogHeader>
        <div className="flex items-center justify-center gap-2 rounded-lg bg-accent py-3 text-sm font-semibold text-accent-foreground">
          <Loader2 className="h-4 w-4 animate-spin" />
          Signing out in {secs}s…
        </div>
        <DialogFooter>
          <Button variant="outline" className="w-full" onClick={bump}>Stay signed in</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}