import React, { useEffect, useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { CreditCard, CheckCircle2, Loader2, FileText } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

export default function PatientInvoices({ user }) {
  const { toast } = useToast();
  const [claims, setClaims] = useState([]);
  const [loading, setLoading] = useState(true);
  const [payingId, setPayingId] = useState(null);

  const load = () =>
    base44.entities.Claim.filter({ patient_email: user.email }, "-created_date", 50)
      .then(setClaims)
      .finally(() => setLoading(false));

  useEffect(() => {
    if (user?.email) load();
    const params = new URLSearchParams(window.location.search);
    if (params.get("paid")) toast({ title: "Payment received", description: "Your invoice has been marked as paid." });
    if (params.get("cancelled")) toast({ variant: "destructive", title: "Payment cancelled" });
    if (params.get("paid") || params.get("cancelled")) window.history.replaceState({}, "", window.location.pathname);
  }, [user?.email]);

  const { outstanding, paid } = useMemo(() => {
    const out = claims.filter((c) => c.status !== "paid");
    const pd = claims.filter((c) => c.status === "paid");
    return { outstanding: out, paid: pd };
  }, [claims]);

  const money = (n) => `$${Number(n || 0).toFixed(2)}`;

  async function pay(claim) {
    if (window.self !== window.top) {
      toast({
        variant: "destructive",
        title: "Open in published app",
        description: "Payment works only from the published app, not the preview.",
      });
      return;
    }
    setPayingId(claim.id);
    try {
      const { data } = await base44.functions.invoke("createStripeCheckoutSession", { claim_id: claim.id });
      if (data?.url) window.location.href = data.url;
    } catch (err) {
      toast({ variant: "destructive", title: "Checkout failed", description: err?.response?.data?.error || err?.message });
    } finally {
      setPayingId(null);
    }
  }

  function InvoiceRow({ c }) {
    return (
      <div className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-display text-sm font-bold text-foreground">{c.invoice_number || "Invoice"}</span>
            <StatusBadge status={c.status} />
          </div>
          {c.description && <div className="mt-0.5 truncate text-xs text-muted-foreground">{c.description}</div>}
          {c.due_date && <div className="mt-0.5 text-xs text-muted-foreground">Due {c.due_date}</div>}
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="font-display text-base font-bold text-foreground">{money(c.amount)}</div>
          </div>
          {c.status !== "paid" ? (
            <Button size="sm" className="h-8 gap-1.5 text-xs" disabled={payingId === c.id} onClick={() => pay(c)}>
              {payingId === c.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CreditCard className="h-3.5 w-3.5" />}
              Pay Now
            </Button>
          ) : (
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600">
              <CheckCircle2 className="h-4 w-4" /> Paid
            </span>
          )}
        </div>
      </div>
    );
  }

  if (loading) return <div className="py-10 text-center text-muted-foreground">Loading your invoices…</div>;

  return (
    <div className="space-y-6">
      <section>
        <h2 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <CreditCard className="h-4 w-4" /> Outstanding
        </h2>
        {outstanding.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 px-6 py-10 text-center">
            <CheckCircle2 className="h-7 w-7 text-emerald-500" />
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">You have no outstanding invoices. You're all paid up.</p>
          </div>
        ) : (
          <div className="space-y-3">{outstanding.map((c) => <InvoiceRow key={c.id} c={c} />)}</div>
        )}
      </section>

      <section>
        <h2 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <FileText className="h-4 w-4" /> Payment History
        </h2>
        {paid.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card/50 px-6 py-8 text-center text-sm text-muted-foreground">
            No payments on record yet.
          </div>
        ) : (
          <div className="space-y-3">{paid.map((c) => <InvoiceRow key={c.id} c={c} />)}</div>
        )}
      </section>
    </div>
  );
}