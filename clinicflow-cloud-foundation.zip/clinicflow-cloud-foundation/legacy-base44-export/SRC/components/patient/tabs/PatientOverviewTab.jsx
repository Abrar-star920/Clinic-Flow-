import React from "react";
import { Phone, Mail, Droplet, ShieldPlus, Cake, Languages, ScrollText, UserRound } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import Avatar from "@/components/Avatar";
import ClinicalSummary from "@/components/clinical/ClinicalSummary";
import PatientContactsSection from "@/components/clinical/PatientContactsSection";
import IdentityHistorySection from "@/components/clinical/IdentityHistorySection";
import SectionCard from "@/components/patient/SectionCard";

function Info({ icon: Icon, label, value }) {
  if (!value) return null;
  return (
    <div className="flex items-center gap-2">
      <Icon className="h-3.5 w-3.5 text-muted-foreground" />
      <span className="text-muted-foreground">{label}:</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}

export default function PatientOverviewTab({ patient, patientId, summary, summaryLoading, onGenerateSummary, audit }) {
  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <div className="space-y-4">
        <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <Avatar name={patient.full_name} src={patient.photo_url} size="lg" />
            <h3 className="font-display text-sm font-bold text-foreground">Patient Information</h3>
          </div>
          <dl className="mt-3 space-y-2 text-sm">
            <Info icon={Phone} label="Phone" value={patient.phone} />
            <Info icon={Mail} label="Email" value={patient.email} />
            <Info icon={Cake} label="DOB" value={patient.dob} />
            <Info icon={Droplet} label="Blood Type" value={patient.blood_type && patient.blood_type !== "unknown" ? patient.blood_type : null} />
            <Info icon={Languages} label="Language" value={patient.preferred_language} />
            <Info
              icon={ShieldPlus}
              label="Emergency Contact"
              value={patient.emergency_contact_name ? `${patient.emergency_contact_name} ${patient.emergency_contact_phone || ""}`.trim() : null}
            />
          </dl>
          {patient.chronic_conditions?.length > 0 && (
            <div className="mt-3">
              <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Chronic Conditions</div>
              <div className="mt-1 flex flex-wrap gap-1.5">
                {patient.chronic_conditions.map((c, i) => (
                  <span key={i} className="status-badge bg-amber-100 text-amber-700 ring-1 ring-amber-200">{c}</span>
                ))}
              </div>
            </div>
          )}
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">Chart:</span>
            <StatusBadge status={patient.chart_status || "existing"} />
            {patient.identity_verified && (
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-700 ring-1 ring-emerald-200">Identity Verified</span>
            )}
          </div>
          <div className="mt-1 flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Insurance:</span>
            <StatusBadge status={patient.insurance_status} />
          </div>
        </div>
        <ClinicalSummary summary={summary} loading={summaryLoading} onGenerate={onGenerateSummary} />
      </div>

      <div className="space-y-4 lg:col-span-2">
        <div className="grid gap-4 md:grid-cols-2">
          <PatientContactsSection patientId={patientId} patient={patient} />
          <IdentityHistorySection patientId={patientId} />
        </div>
        <SectionCard title="Audit Trail" icon={ScrollText}>
          {audit.length === 0 ? (
            <div className="py-4 text-center text-sm text-muted-foreground">No activity recorded.</div>
          ) : (
            <ul className="space-y-2">
              {audit.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 border-b border-border pb-2 last:border-0 last:pb-0">
                  <div>
                    <div className="text-sm font-medium text-foreground">{a.summary}</div>
                    <div className="text-xs text-muted-foreground">{a.actor_email || "system"}</div>
                  </div>
                  <span className="text-xs text-muted-foreground">{(a.created_date || "").slice(0, 16).replace("T", " ")}</span>
                </li>
              ))}
            </ul>
          )}
        </SectionCard>
      </div>
    </div>
  );
}