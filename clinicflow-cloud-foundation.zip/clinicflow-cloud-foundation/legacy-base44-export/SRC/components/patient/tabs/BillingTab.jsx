import React from "react";
import { CreditCard, CheckCircle2, Wallet, ReceiptText } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";

const money = (n) => `$${Number(n || 0).toFixed(2)}`;

function Stat({ icon: Icon, label, value, tone }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        <Icon className="h-4 w-4 text-primary" /> {label}
      </div>
      <div className={`mt-1.5 font-display text-xl font-bold ${tone || "text-foreground"}`}>{value}</div>
    </div>
  );
}

export default function BillingTab({ claims }) {
  const outstanding = claims.filter((c) => c.status !== "paid");
  const paid = claims.filter((c) => c.status === "paid");
  const outstandingTotal = outstanding.reduce((s, c) => s + Number(c.amount || 0), 0);
  const paidTotal = paid.reduce((s, c) => s + Number(c.amount || 0), 0);

  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-3">
        <Stat icon={Wallet} label="Outstanding Balance" value={money(outstandingTotal)} tone={outstandingTotal > 0 ? "text-destructive" : "text-emerald-600"} />
        <Stat icon={CheckCircle2} label="Paid to Date" value={money(paidTotal)} tone="text-emerald-600" />
        <Stat icon={ReceiptText} label="Total Claims" value={claims.length} />
      </div>

      <section>
        <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <CreditCard className="h-4 w-4" /> Outstanding
        </h3>
        {outstanding.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 px-6 py-10 text-center">
            <CheckCircle2 className="h-7 w-7 text-emerald-500" />
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">No outstanding invoices — this patient is all paid up.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {outstanding.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm font-bold text-foreground">{c.invoice_number || "Invoice"}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  {c.description && <div className="mt-0.5 truncate text-xs text-muted-foreground">{c.description}</div>}
                  {c.due_date && <div className="mt-0.5 text-xs text-muted-foreground">Due {c.due_date}</div>}
                </div>
                <div className="font-display text-base font-bold text-foreground">{money(c.amount)}</div>
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <ReceiptText className="h-4 w-4" /> Payment History
        </h3>
        {paid.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card/50 py-8 text-center text-sm text-muted-foreground">
            No payments on record yet.
          </div>
        ) : (
          <div className="space-y-3">
            {paid.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm font-bold text-foreground">{c.invoice_number || "Invoice"}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  {c.paid_date && <div className="mt-0.5 text-xs text-muted-foreground">Paid {c.paid_date}</div>}
                </div>
                <div className="font-display text-base font-bold text-emerald-600">{money(c.amount)}</div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}