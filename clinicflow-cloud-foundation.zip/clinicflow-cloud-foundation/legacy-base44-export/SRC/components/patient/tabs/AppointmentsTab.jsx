import React from "react";
import { CalendarX } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";

export default function AppointmentsTab({ appointments }) {
  if (!appointments.length) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border bg-card/50 px-6 py-12 text-center">
        <CalendarX className="h-8 w-8 text-muted-foreground/60" />
        <p className="mt-3 text-sm text-muted-foreground">No appointments on record for this patient.</p>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-sm">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-border bg-surface text-left text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            <th className="px-4 py-3">Date</th>
            <th className="px-4 py-3">Time</th>
            <th className="px-4 py-3">Provider</th>
            <th className="px-4 py-3">Type</th>
            <th className="px-4 py-3">Room</th>
            <th className="px-4 py-3">Status</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map((a) => (
            <tr key={a.id} className="border-b border-border last:border-0 hover:bg-muted/50">
              <td className="whitespace-nowrap px-4 py-3 font-medium text-foreground">{a.appointment_date || "—"}</td>
              <td className="whitespace-nowrap px-4 py-3 text-muted-foreground">
                {a.appointment_time || "—"}
                {a.duration_minutes ? ` (${a.duration_minutes}m)` : ""}
              </td>
              <td className="px-4 py-3 text-foreground">{a.provider || "—"}</td>
              <td className="px-4 py-3 capitalize text-muted-foreground">{(a.type || "—").replace(/_/g, " ")}</td>
              <td className="px-4 py-3 text-muted-foreground">{a.room || "—"}</td>
              <td className="px-4 py-3"><StatusBadge status={a.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}