import React from "react";
import { Activity, Pill, ShieldPlus, FileText, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import VitalsChart from "@/components/clinical/VitalsChart";
import MedicationsList from "@/components/clinical/MedicationsList";
import AllergiesList from "@/components/clinical/AllergiesList";
import VisitNotesTimeline from "@/components/clinical/VisitNotesTimeline";
import SectionCard from "@/components/patient/SectionCard";

export default function ClinicalTab({ vitals, medications, allergies, notes, onAddMedication, onAddNote }) {
  return (
    <div className="space-y-4">
      <SectionCard title="Vital Trends" icon={Activity}>
        <VitalsChart vitals={vitals} />
      </SectionCard>
      <div className="grid gap-4 md:grid-cols-2">
        <SectionCard
          title="Medications"
          icon={Pill}
          action={
            <Button size="sm" variant="outline" className="h-7 text-xs" onClick={onAddMedication}>
              <Plus className="h-3.5 w-3.5" /> Add
            </Button>
          }
        >
          <MedicationsList medications={medications} />
        </SectionCard>
        <SectionCard title="Allergies" icon={ShieldPlus}>
          <AllergiesList allergies={allergies} />
        </SectionCard>
      </div>
      <SectionCard
        title="Visit Notes"
        icon={FileText}
        action={
          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={onAddNote}>
            <Plus className="h-3.5 w-3.5" /> Add
          </Button>
        }
      >
        <VisitNotesTimeline notes={notes} />
      </SectionCard>
    </div>
  );
}