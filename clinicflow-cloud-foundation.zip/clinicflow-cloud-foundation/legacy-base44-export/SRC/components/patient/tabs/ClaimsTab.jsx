import React from "react";
import { FileCheck2, Ban } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import InsuranceRecordsSection from "@/components/clinical/InsuranceRecordsSection";

const ACTIVE_STATUSES = ["draft", "ready", "approved_for_submission", "submitted", "partially_paid", "denied", "on_hold"];
const money = (n) => `$${Number(n || 0).toFixed(2)}`;

export default function ClaimsTab({ patientId, patient, claims }) {
  const active = claims.filter((c) => ACTIVE_STATUSES.includes(c.status));

  return (
    <div className="space-y-5">
      <section>
        <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <FileCheck2 className="h-4 w-4" /> Active Claims
        </h3>
        {active.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border bg-card/50 py-8 text-center text-sm text-muted-foreground">
            No active insurance claims for this patient.
          </div>
        ) : (
          <div className="space-y-3">
            {active.map((c) => (
              <div key={c.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm font-bold text-foreground">{c.invoice_number || "Claim"}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  <span className="font-display text-base font-bold text-foreground">{money(c.amount)}</span>
                </div>
                {c.description && <div className="mt-1 text-xs text-muted-foreground">{c.description}</div>}
                {c.cpt_codes?.length > 0 && (
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {c.cpt_codes.map((code, i) => (
                      <span key={i} className="rounded-md bg-secondary px-2 py-0.5 text-[11px] font-semibold text-secondary-foreground">{code}</span>
                    ))}
                  </div>
                )}
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-muted-foreground sm:grid-cols-4">
                  <div><span className="block font-semibold text-foreground/70">Clearinghouse</span>{c.clearinghouse_status || "—"}</div>
                  <div><span className="block font-semibold text-foreground/70">Stedi Control #</span>{c.stedi_control_number || "—"}</div>
                  <div><span className="block font-semibold text-foreground/70">Payer Claim #</span>{c.payer_claim_number || "—"}</div>
                  <div><span className="block font-semibold text-foreground/70">Last Status Check</span>{c.last_status_check ? c.last_status_check.slice(0, 16).replace("T", " ") : "—"}</div>
                </div>
                {c.denial_codes?.length > 0 && (
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <Ban className="h-3.5 w-3.5 text-destructive" />
                    {c.denial_codes.map((code, i) => (
                      <span key={i} className="rounded-md bg-red-50 px-2 py-0.5 text-[11px] font-semibold text-destructive ring-1 ring-red-200">{code}</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <InsuranceRecordsSection patientId={patientId} patient={patient} />
    </div>
  );
}