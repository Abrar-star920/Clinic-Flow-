import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";
import PhotoUpload from "@/components/PhotoUpload";

export default function PatientIntakeDialog({ open, onOpenChange, onCreated }) {
  const [form, setForm] = useState({
    full_name: "",
    dob: "",
    phone: "",
    email: "",
    insurance_provider: "",
    insurance_member_id: "",
    reason_for_visit: "",
    photo_url: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  function reset() {
    setForm({ full_name: "", dob: "", phone: "", email: "", insurance_provider: "", insurance_member_id: "", reason_for_visit: "", photo_url: "" });
    setError("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!form.full_name.trim()) {
      setError("Full name is required.");
      return;
    }
    setSubmitting(true);
    try {
      const created = await base44.entities.Patient.create({
        full_name: form.full_name.trim(),
        dob: form.dob || undefined,
        phone: form.phone || undefined,
        email: form.email || undefined,
        insurance_provider: form.insurance_provider || undefined,
        insurance_member_id: form.insurance_member_id || undefined,
        insurance_status: "pending",
        intake_status: "new",
        reason_for_visit: form.reason_for_visit || undefined,
        photo_url: form.photo_url || undefined,
      });
      onCreated?.(created);
      reset();
      onOpenChange(false);
    } catch (err) {
      setError("Could not save the patient. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!submitting) { onOpenChange(v); if (!v) reset(); } }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>New Patient Intake</DialogTitle>
          <DialogDescription>Register a new patient. Insurance defaults to pending verification.</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <PhotoUpload value={form.photo_url} onChange={(url) => setForm({ ...form, photo_url: url })} name={form.full_name} />
          <div className="space-y-1.5">
            <Label htmlFor="full_name">Full Name *</Label>
            <Input id="full_name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} placeholder="Jane Doe" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="dob">Date of Birth</Label>
              <Input id="dob" type="date" value={form.dob} onChange={(e) => setForm({ ...form, dob: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="(555) 123-4567" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="jane@example.com" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="insurance_provider">Insurance Provider</Label>
              <Input id="insurance_provider" value={form.insurance_provider} onChange={(e) => setForm({ ...form, insurance_provider: e.target.value })} placeholder="Blue Cross" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="insurance_member_id">Member ID</Label>
              <Input id="insurance_member_id" value={form.insurance_member_id} onChange={(e) => setForm({ ...form, insurance_member_id: e.target.value })} placeholder="XYZ123456" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="reason">Reason for Visit</Label>
            <Textarea id="reason" rows={2} value={form.reason_for_visit} onChange={(e) => setForm({ ...form, reason_for_visit: e.target.value })} placeholder="Brief reason…" />
          </div>

          {error && <p className="text-sm font-medium text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Cancel</Button>
            <Button type="submit" disabled={submitting} className="gap-1.5">
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</> : "Save Patient"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}