import React from "react";

export default function PageHeader({ title, subtitle, icon: Icon, actions }) {
  return (
    <div className="flex flex-col gap-3 border-b border-border bg-card px-6 py-6 sm:flex-row sm:items-center sm:justify-between sm:px-8">
      <div className="flex items-start gap-3.5">
        {Icon && (
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-primary ring-1 ring-primary/15">
            <Icon className="h-5 w-5" />
          </div>
        )}
        <div>
          <h1 className="font-display text-[22px] font-bold leading-tight tracking-tight text-foreground">{title}</h1>
          {subtitle && <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}