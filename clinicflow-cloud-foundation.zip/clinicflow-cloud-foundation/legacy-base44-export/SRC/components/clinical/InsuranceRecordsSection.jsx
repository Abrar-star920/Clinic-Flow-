import React, { useEffect, useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, ShieldCheck, ShieldAlert, RefreshCw, FileBadge } from "lucide-react";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import StatusBadge from "@/components/StatusBadge";

const PLAN_LABELS = { ppo: "PPO", hmo: "HMO", medicare: "Medicare", medicare_advantage: "Medicare Advantage" };

export default function InsuranceRecordsSection({ patientId, patient }) {
  const { toast } = useToast();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [config, setConfig] = useState(null);
  const [addOpen, setAddOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [recs, cfgs] = await Promise.all([
        base44.entities.InsuranceRecord.filter({ patient_id: patientId }, "-last_refresh_date", 50),
        base44.entities.ClinicConfig.list("-created_date", 1),
      ]);
      setRecords(recs || []);
      setConfig(cfgs?.[0] || null);
    } finally { setLoading(false); }
  }, [patientId]);

  useEffect(() => { load(); }, [load]);

  const gateRequired = config ? config.require_insurance_before_booking : true;
  const verifiedCount = records.filter((r) => r.eligibility_status === "verified").length;
  const authIssues = records.filter((r) =>
    r.plan_type === "hmo" && r.auth_status && r.auth_status !== "approved" && r.auth_status !== "not_required"
  );

  async function logAudit(summary) {
    try {
      await base44.entities.AuditLog.create({
        entity_type: "InsuranceRecord", entity_id: patientId, patient_id: patientId,
        patient_name: patient?.full_name, action: "status_change", actor_email: "staff", summary,
      });
    } catch { /* non-blocking */ }
  }

  async function verify(id) {
    const rec = records.find((r) => r.id === id);
    await base44.entities.InsuranceRecord.update(id, {
      eligibility_status: "verified",
      last_refresh_date: new Date().toISOString(),
      verified_by_type: "user",
    });
    setRecords((prev) => prev.map((r) => (r.id === id ? { ...r, eligibility_status: "verified", last_refresh_date: new Date().toISOString() } : r)));
    await logAudit(`Insurance verified (${PLAN_LABELS[rec?.plan_type]}) — ${rec?.payer}`);
    toast({ title: "Insurance verified" });
  }

  async function addRecord(data) {
    const rec = await base44.entities.InsuranceRecord.create({
      ...data,
      patient_id: patientId,
      patient_name: patient?.full_name || "",
      patient_email: patient?.email || "",
      last_refresh_date: new Date().toISOString(),
      verified_by_type: "user",
    });
    setRecords((prev) => [rec, ...prev]);
    await logAudit(`Insurance record added (${PLAN_LABELS[data.plan_type]}) — ${data.payer}`);
    toast({ title: "Insurance record added" });
    setAddOpen(false);
  }

  return (
    <div className="rounded-xl border border-border bg-card shadow-sm">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <FileBadge className="h-4 w-4 text-primary" />
          <h3 className="font-display text-sm font-bold text-foreground">Insurance & Verification</h3>
        </div>
        <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setAddOpen(true)}>
          <Plus className="h-3.5 w-3.5" /> Add
        </Button>
      </div>

      <div className="p-4">
        {gateRequired && verifiedCount === 0 && (
          <div className="mb-3 flex items-center gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs font-medium text-amber-800">
            <ShieldAlert className="h-4 w-4" /> Booking gated: insurance verification required before appointment booking.
          </div>
        )}
        {authIssues.length > 0 && (
          <div className="mb-3 flex items-center gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-800">
            <ShieldAlert className="h-4 w-4" /> {authIssues.length} HMO authorization(s) pending/invalid — booking blocked.
          </div>
        )}

        {loading ? (
          <div className="py-6 text-center text-sm text-muted-foreground">Loading insurance…</div>
        ) : records.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">No insurance records on file.</div>
        ) : (
          <div className="space-y-3">
            {records.map((r) => (
              <div key={r.id} className="rounded-lg border border-border bg-muted/20 p-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="rounded-md bg-primary/10 px-1.5 py-0.5 text-[10px] font-bold uppercase text-primary">{PLAN_LABELS[r.plan_type]}</span>
                      <span className="font-semibold text-foreground">{r.payer}</span>
                    </div>
                    <div className="mt-1 text-xs text-muted-foreground">
                      {r.plan_name || "—"} · Member {r.member_id || "—"} · Group {r.group_number || "—"}
                    </div>
                  </div>
                  <StatusBadge status={r.eligibility_status} />
                </div>
                <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-muted-foreground sm:grid-cols-3">
                  <span>Network: <span className="font-medium text-foreground">{r.network_status || "—"}</span></span>
                  <span>Copay: <span className="font-medium text-foreground">{r.specialist_copay || "—"}</span></span>
                  <span>Effective: <span className="font-medium text-foreground">{r.effective_date || "—"}</span></span>
                  {r.medical_group_ipa && <span>Med group/IPA: <span className="font-medium text-foreground">{r.medical_group_ipa}</span></span>}
                  {r.referral_auth_number && <span>Auth #: <span className="font-medium text-foreground">{r.referral_auth_number}</span></span>}
                  {r.referral_auth_number && <span>Auth status: <StatusBadge status={r.auth_status} /></span>}
                  <span>Last refresh: <span className="font-medium text-foreground">{(r.last_refresh_date || "").slice(0, 10)}</span></span>
                </div>
                {r.eligibility_status !== "verified" && (
                  <div className="mt-2 flex justify-end">
                    <Button size="sm" variant="outline" className="h-7 gap-1.5 text-xs" onClick={() => verify(r.id)}>
                      <ShieldCheck className="h-3.5 w-3.5" /> Verify eligibility
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <AddInsuranceDialog open={addOpen} onOpenChange={setAddOpen} onAdd={addRecord} />
    </div>
  );
}

const EMPTY = {
  plan_type: "ppo", payer: "", plan_name: "", member_id: "", group_number: "",
  eligibility_status: "pending", network_status: "unknown", effective_date: "", termination_date: "",
  specialist_copay: "", medical_group_ipa: "", referral_auth_number: "", auth_status: "not_required",
  auth_effective_date: "", auth_expiration_date: "", medicare_type: "unknown", notes: "",
};

function AddInsuranceDialog({ open, onOpenChange, onAdd }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  function reset() { setForm(EMPTY); }
  async function submit(e) {
    e.preventDefault();
    if (!form.payer.trim()) return;
    setSaving(true);
    try { await onAdd({ ...form, payer: form.payer.trim() }); reset(); }
    finally { setSaving(false); }
  }
  const isHmo = form.plan_type === "hmo";
  const isMedicare = form.plan_type === "medicare" || form.plan_type === "medicare_advantage";
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!saving) { onOpenChange(v); if (!v) reset(); } }}>
      <DialogContent className="max-w-2xl">
        <DialogHeader><DialogTitle>Add Insurance Record</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Plan Type *</Label>
              <Select value={form.plan_type} onValueChange={(v) => setForm({ ...form, plan_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ppo">PPO</SelectItem>
                  <SelectItem value="hmo">HMO</SelectItem>
                  <SelectItem value="medicare">Medicare</SelectItem>
                  <SelectItem value="medicare_advantage">Medicare Advantage</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Payer *</Label>
              <Input value={form.payer} onChange={(e) => setForm({ ...form, payer: e.target.value })} placeholder="Blue Cross" required />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label>Plan Name</Label><Input value={form.plan_name} onChange={(e) => setForm({ ...form, plan_name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Member ID</Label><Input value={form.member_id} onChange={(e) => setForm({ ...form, member_id: e.target.value })} /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5"><Label>Group Number</Label><Input value={form.group_number} onChange={(e) => setForm({ ...form, group_number: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Specialist Copay</Label><Input value={form.specialist_copay} onChange={(e) => setForm({ ...form, specialist_copay: e.target.value })} placeholder="$30" /></div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label>Eligibility</Label>
              <Select value={form.eligibility_status} onValueChange={(v) => setForm({ ...form, eligibility_status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="verified">Verified</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="unverified">Unverified</SelectItem>
                  <SelectItem value="denied">Denied</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Effective</Label><Input type="date" value={form.effective_date} onChange={(e) => setForm({ ...form, effective_date: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Termination</Label><Input type="date" value={form.termination_date} onChange={(e) => setForm({ ...form, termination_date: e.target.value })} /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Network Status</Label>
              <Select value={form.network_status} onValueChange={(v) => setForm({ ...form, network_status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="in_network">In Network</SelectItem>
                  <SelectItem value="out_of_network">Out of Network</SelectItem>
                  <SelectItem value="unknown">Unknown</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {isMedicare && (
              <div className="space-y-1.5">
                <Label>Medicare Type</Label>
                <Select value={form.medicare_type} onValueChange={(v) => setForm({ ...form, medicare_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="original">Original</SelectItem>
                    <SelectItem value="advantage">Advantage</SelectItem>
                    <SelectItem value="unknown">Unknown</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          {isHmo && (
            <div className="grid grid-cols-2 gap-4 rounded-lg border border-border bg-muted/30 p-3">
              <div className="space-y-1.5"><Label>Medical Group / IPA</Label><Input value={form.medical_group_ipa} onChange={(e) => setForm({ ...form, medical_group_ipa: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>Referral/Auth #</Label><Input value={form.referral_auth_number} onChange={(e) => setForm({ ...form, referral_auth_number: e.target.value })} /></div>
              <div className="space-y-1.5">
                <Label>Authorization Status</Label>
                <Select value={form.auth_status} onValueChange={(v) => setForm({ ...form, auth_status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="denied">Denied</SelectItem>
                    <SelectItem value="not_required">Not Required</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5"><Label>Auth Expiration</Label><Input type="date" value={form.auth_expiration_date} onChange={(e) => setForm({ ...form, auth_expiration_date: e.target.value })} /></div>
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving} className="gap-1.5">{saving ? <RefreshCw className="h-4 w-4 animate-spin" /> : null} Save Record</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}