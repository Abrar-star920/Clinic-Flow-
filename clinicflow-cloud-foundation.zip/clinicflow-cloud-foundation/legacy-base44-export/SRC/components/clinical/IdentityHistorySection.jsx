import React, { useEffect, useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Fingerprint } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";

const HIPAA_LABELS = {
  self: "Self", authorized_caller: "Authorized caller", not_authorized: "Not authorized", not_checked: "Not checked",
};

export default function IdentityHistorySection({ patientId }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const recs = await base44.entities.IdentityVerification.filter({ patient_id: patientId }, "-created_date", 30);
      setItems(recs || []);
    } finally { setLoading(false); }
  }, [patientId]);
  useEffect(() => { load(); }, [load]);

  return (
    <div className="rounded-xl border border-border bg-card shadow-sm">
      <div className="flex items-center gap-2 border-b border-border px-4 py-3">
        <Fingerprint className="h-4 w-4 text-primary" />
        <h3 className="font-display text-sm font-bold text-foreground">Identity Verification History</h3>
      </div>
      <div className="p-4">
        {loading ? (
          <div className="py-4 text-center text-sm text-muted-foreground">Loading…</div>
        ) : items.length === 0 ? (
          <div className="py-4 text-center text-sm text-muted-foreground">No verification attempts recorded.</div>
        ) : (
          <ul className="space-y-2">
            {items.map((v) => (
              <li key={v.id} className="flex items-start justify-between gap-3 border-b border-border pb-2 last:border-0 last:pb-0">
                <div>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={v.result} />
                    <span className="text-xs text-muted-foreground">{HIPAA_LABELS[v.hipaa_check] || v.hipaa_check}</span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    {v.caller_name} ({v.caller_relationship || "—"}) · {v.outcome === "proceed" ? "Proceeded" : "Escalated"}
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{(v.created_date || "").slice(0, 16).replace("T", " ")}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}