import React, { useEffect, useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, ShieldCheck, ShieldX, Users } from "lucide-react";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";

const REL_LABELS = {
  spouse: "Spouse", parent: "Parent", child: "Child", sibling: "Sibling",
  caregiver: "Caregiver", legal_guardian: "Legal Guardian", other: "Other",
};

export default function PatientContactsSection({ patientId, patient }) {
  const { toast } = useToast();
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const recs = await base44.entities.PatientContact.filter({ patient_id: patientId }, "-created_date", 50);
      setContacts(recs || []);
    } finally { setLoading(false); }
  }, [patientId]);
  useEffect(() => { load(); }, [load]);

  async function logAudit(summary) {
    try {
      await base44.entities.AuditLog.create({
        entity_type: "PatientContact", entity_id: patientId, patient_id: patientId,
        patient_name: patient?.full_name, action: "status_change", actor_email: "staff", summary,
      });
    } catch { /* non-blocking */ }
  }

  async function toggleAuth(c) {
    const authorized = !c.hipaa_authorized;
    const authorization_status = authorized ? "authorized" : "not_authorized";
    await base44.entities.PatientContact.update(c.id, {
      hipaa_authorized: authorized,
      authorization_status,
      authorization_on_file: authorized ? new Date().toISOString().slice(0, 10) : c.authorization_on_file,
    });
    setContacts((prev) => prev.map((x) => (x.id === c.id ? { ...x, hipaa_authorized: authorized, authorization_status } : x)));
    await logAudit(`${authorized ? "Granted" : "Revoked"} HIPAA authorization for ${c.full_name} (${REL_LABELS[c.relationship]})`);
    toast({ title: authorized ? "HIPAA authorization granted" : "HIPAA authorization revoked" });
  }

  async function addContact(data) {
    const rec = await base44.entities.PatientContact.create({
      ...data,
      patient_id: patientId,
      patient_name: patient?.full_name || "",
      patient_email: patient?.email || "",
      authorization_on_file: data.hipaa_authorized ? new Date().toISOString().slice(0, 10) : undefined,
    });
    setContacts((prev) => [rec, ...prev]);
    await logAudit(`Added contact ${data.full_name} (${REL_LABELS[data.relationship]}) — HIPAA ${data.hipaa_authorized ? "authorized" : "not authorized"}`);
    toast({ title: "Contact added" });
    setAddOpen(false);
  }

  return (
    <div className="rounded-xl border border-border bg-card shadow-sm">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-primary" />
          <h3 className="font-display text-sm font-bold text-foreground">Contacts & HIPAA Authorization</h3>
        </div>
        <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setAddOpen(true)}>
          <Plus className="h-3.5 w-3.5" /> Add
        </Button>
      </div>
      <div className="p-4">
        <div className="mb-3 rounded-lg border border-border bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
          Being listed as an emergency or support contact does <strong>not</strong> authorize disclosure.
          Only an explicit HIPAA authorization on file permits sharing patient information with a third party.
        </div>
        {loading ? (
          <div className="py-6 text-center text-sm text-muted-foreground">Loading contacts…</div>
        ) : contacts.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">No contacts on file.</div>
        ) : (
          <ul className="space-y-2">
            {contacts.map((c) => (
              <li key={c.id} className="flex items-center justify-between gap-3 rounded-lg border border-border bg-muted/20 p-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-foreground">{c.full_name}</span>
                    <span className="rounded-md bg-secondary px-1.5 py-0.5 text-[10px] font-medium text-secondary-foreground">{REL_LABELS[c.relationship]}</span>
                    {c.hipaa_authorized ? (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-bold uppercase text-emerald-700 ring-1 ring-emerald-200">
                        <ShieldCheck className="h-3 w-3" /> HIPAA Authorized
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-bold uppercase text-rose-700 ring-1 ring-rose-200">
                        <ShieldX className="h-3 w-3" /> Not Authorized
                      </span>
                    )}
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">{c.phone || "—"}{c.email ? ` · ${c.email}` : ""}</div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Authorized</span>
                  <Switch checked={c.hipaa_authorized} onCheckedChange={() => toggleAuth(c)} />
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
      <AddContactDialog open={addOpen} onOpenChange={setAddOpen} onAdd={addContact} />
    </div>
  );
}

function AddContactDialog({ open, onOpenChange, onAdd }) {
  const [form, setForm] = useState({ full_name: "", relationship: "spouse", phone: "", email: "", hipaa_authorized: false });
  const [saving, setSaving] = useState(false);
  function reset() { setForm({ full_name: "", relationship: "spouse", phone: "", email: "", hipaa_authorized: false }); }
  async function submit(e) {
    e.preventDefault();
    if (!form.full_name.trim()) return;
    setSaving(true);
    try { await onAdd({ ...form, full_name: form.full_name.trim() }); reset(); }
    finally { setSaving(false); }
  }
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!saving) { onOpenChange(v); if (!v) reset(); } }}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Add Contact</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Full Name *</Label>
            <Input value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Relationship</Label>
              <Select value={form.relationship} onValueChange={(v) => setForm({ ...form, relationship: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(REL_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
          </div>
          <div className="space-y-1.5"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div className="flex items-center gap-3 rounded-lg border border-border bg-muted/30 px-3 py-2.5">
            <Switch checked={form.hipaa_authorized} onCheckedChange={(v) => setForm({ ...form, hipaa_authorized: v })} />
            <div className="text-xs">
              <div className="font-medium text-foreground">HIPAA authorization on file</div>
              <div className="text-muted-foreground">Only enable if a signed authorization exists.</div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>Cancel</Button>
            <Button type="submit" disabled={saving}>Save Contact</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}