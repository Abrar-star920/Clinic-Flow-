import React from "react";
import { AlertTriangle } from "lucide-react";

const SEV = {
  severe: "text-rose-700 bg-rose-100 ring-1 ring-rose-200",
  moderate: "text-amber-700 bg-amber-100 ring-1 ring-amber-200",
  mild: "text-sky-700 bg-sky-100 ring-1 ring-sky-200",
  unknown: "text-slate-600 bg-slate-100 ring-1 ring-slate-200",
};

export default function AllergiesList({ allergies }) {
  if (!allergies.length) {
    return <div className="py-6 text-center text-sm text-muted-foreground">No known allergies.</div>;
  }
  return (
    <ul className="space-y-2">
      {allergies.map((a) => (
        <li key={a.id} className="flex items-start gap-3 rounded-lg border border-border bg-card p-3">
          <AlertTriangle className={`mt-0.5 h-4 w-4 ${a.severity === "severe" ? "text-rose-600" : "text-amber-500"}`} />
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-foreground">{a.allergen}</span>
              <span className={`status-badge ${SEV[a.severity] || SEV.unknown}`}>{a.severity}</span>
            </div>
            {a.reaction && <div className="mt-0.5 text-xs text-muted-foreground">Reaction: {a.reaction}</div>}
          </div>
        </li>
      ))}
    </ul>
  );
}