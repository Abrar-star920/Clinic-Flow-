import React from "react";
import { Pill } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";

export default function MedicationsList({ medications }) {
  if (!medications.length) {
    return <div className="py-6 text-center text-sm text-muted-foreground">No medications on record.</div>;
  }
  return (
    <ul className="divide-y divide-border">
      {medications.map((m) => (
        <li key={m.id} className="flex items-start justify-between gap-3 py-3">
          <div className="flex items-start gap-3">
            <div className="mt-0.5 flex h-8 w-8 items-center justify-center rounded-lg bg-sky-50 text-sky-700">
              <Pill className="h-4 w-4" />
            </div>
            <div>
              <div className="font-semibold text-foreground">
                {m.name} <span className="text-sm text-muted-foreground">{m.dosage}</span>
              </div>
              <div className="text-xs text-muted-foreground">
                {m.frequency} · {m.route}{m.prescribed_by ? ` · ${m.prescribed_by}` : ""}
              </div>
            </div>
          </div>
          <StatusBadge status={m.status} />
        </li>
      ))}
    </ul>
  );
}