import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export default function AddMedicationDialog({ open, onOpenChange, onAdd }) {
  const [form, setForm] = useState({ name: "", dosage: "", frequency: "", route: "oral", prescribed_by: "", status: "active", notes: "" });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    if (!form.name) return;
    setSaving(true);
    try {
      await onAdd(form);
      setForm({ name: "", dosage: "", frequency: "", route: "oral", prescribed_by: "", status: "active", notes: "" });
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader><DialogTitle>Add Medication</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div><Label>Name</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} required /></div>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Dosage</Label><Input value={form.dosage} onChange={(e) => set("dosage", e.target.value)} placeholder="500mg" /></div>
            <div><Label>Frequency</Label><Input value={form.frequency} onChange={(e) => set("frequency", e.target.value)} placeholder="BID" /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Route</Label>
              <Select value={form.route} onValueChange={(v) => set("route", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="oral">Oral</SelectItem>
                  <SelectItem value="topical">Topical</SelectItem>
                  <SelectItem value="injection">Injection</SelectItem>
                  <SelectItem value="inhalation">Inhalation</SelectItem>
                  <SelectItem value="sublingual">Sublingual</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => set("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="held">Held</SelectItem>
                  <SelectItem value="discontinued">Discontinued</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div><Label>Prescribed by</Label><Input value={form.prescribed_by} onChange={(e) => set("prescribed_by", e.target.value)} /></div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving ? "Saving…" : "Add Medication"}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}