import React from "react";
import { FileText } from "lucide-react";

export default function VisitNotesTimeline({ notes }) {
  if (!notes.length) {
    return <div className="py-6 text-center text-sm text-muted-foreground">No visit notes recorded.</div>;
  }
  return (
    <ol className="relative space-y-4 border-l border-border pl-6">
      {notes.map((n) => (
        <li key={n.id} className="relative">
          <span className="absolute -left-[27px] flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground">
            <FileText className="h-3 w-3" />
          </span>
          <div className="rounded-lg border border-border bg-card p-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold capitalize text-foreground">{n.note_type} note</span>
              <span className="text-xs text-muted-foreground">
                {(n.created_at || n.created_date || "").slice(0, 10)} · {n.provider}
              </span>
            </div>
            {n.subjective && <p className="mt-1 text-xs text-muted-foreground"><span className="font-semibold text-foreground">S:</span> {n.subjective}</p>}
            {n.objective && <p className="text-xs text-muted-foreground"><span className="font-semibold text-foreground">O:</span> {n.objective}</p>}
            {n.assessment && <p className="text-xs text-muted-foreground"><span className="font-semibold text-foreground">A:</span> {n.assessment}</p>}
            {n.plan && <p className="text-xs text-muted-foreground"><span className="font-semibold text-foreground">P:</span> {n.plan}</p>}
          </div>
        </li>
      ))}
    </ol>
  );
}