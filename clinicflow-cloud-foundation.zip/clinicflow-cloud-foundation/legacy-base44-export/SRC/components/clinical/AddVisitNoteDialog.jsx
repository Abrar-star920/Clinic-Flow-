import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

export default function AddVisitNoteDialog({ open, onOpenChange, onAdd, defaultProvider }) {
  const [form, setForm] = useState({ provider: defaultProvider || "", note_type: "soap", subjective: "", objective: "", assessment: "", plan: "" });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    if (!form.provider) return;
    setSaving(true);
    try {
      await onAdd(form);
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader><DialogTitle>Add Visit Note</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Provider</Label><Input value={form.provider} onChange={(e) => set("provider", e.target.value)} required /></div>
            <div>
              <Label>Type</Label>
              <Select value={form.note_type} onValueChange={(v) => set("note_type", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="soap">SOAP</SelectItem>
                  <SelectItem value="progress">Progress</SelectItem>
                  <SelectItem value="intake">Intake</SelectItem>
                  <SelectItem value="discharge">Discharge</SelectItem>
                  <SelectItem value="telephone">Telephone</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div><Label>Subjective</Label><Textarea value={form.subjective} onChange={(e) => set("subjective", e.target.value)} rows={2} /></div>
          <div><Label>Objective</Label><Textarea value={form.objective} onChange={(e) => set("objective", e.target.value)} rows={2} /></div>
          <div><Label>Assessment</Label><Textarea value={form.assessment} onChange={(e) => set("assessment", e.target.value)} rows={2} /></div>
          <div><Label>Plan</Label><Textarea value={form.plan} onChange={(e) => set("plan", e.target.value)} rows={2} /></div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving ? "Saving…" : "Add Note"}</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}