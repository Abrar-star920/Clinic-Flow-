import React from "react";
import { Sparkles, ShieldAlert, Lightbulb, CheckCircle2 } from "lucide-react";

const RISK = {
  low: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  moderate: "bg-sky-100 text-sky-700 ring-1 ring-sky-200",
  elevated: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  high: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
};

export default function ClinicalSummary({ summary, loading, onGenerate }) {
  if (loading) {
    return (
      <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
        <div className="py-8 text-center text-sm text-muted-foreground">Analyzing chart…</div>
      </div>
    );
  }
  if (!summary) {
    return (
      <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
        <button
          onClick={onGenerate}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-border py-6 text-sm font-semibold text-primary hover:bg-accent/50"
        >
          <Sparkles className="h-4 w-4" /> Generate AI Clinical Summary
        </button>
      </div>
    );
  }
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">AI Clinical Summary</span>
        </div>
        <span className={`status-badge ${RISK[summary.risk_level] || RISK.moderate}`}>{summary.risk_level} risk</span>
      </div>
      <p className="mt-2 text-sm text-foreground">{summary.summary}</p>
      {summary.risk_factors?.length > 0 && <Field icon={ShieldAlert} title="Risk Factors" items={summary.risk_factors} />}
      {summary.recommendations?.length > 0 && <Field icon={Lightbulb} title="Recommendations" items={summary.recommendations} />}
      {summary.follow_ups?.length > 0 && <Field icon={CheckCircle2} title="Follow-ups" items={summary.follow_ups} />}
      <button onClick={onGenerate} className="mt-2 text-xs font-semibold text-primary hover:underline">Regenerate</button>
    </div>
  );
}

function Field({ icon: Icon, title, items }) {
  return (
    <div className="mt-3">
      <div className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
        <Icon className="h-3.5 w-3.5" /> {title}
      </div>
      <ul className="mt-1 space-y-1">
        {items.map((it, i) => (
          <li key={i} className="text-xs text-foreground">• {it}</li>
        ))}
      </ul>
    </div>
  );
}