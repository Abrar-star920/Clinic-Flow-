import React, { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";

const COLORS = {
  bp_systolic: "#0ea5e9", bp_diastolic: "#0284c7", heart_rate: "#ef4444",
  temperature: "#f59e0b", weight: "#10b981", spo2: "#8b5cf6",
  respiratory_rate: "#14b8a6", glucose: "#ec4899",
};
const LABELS = {
  bp_systolic: "BP Systolic", bp_diastolic: "BP Diastolic", heart_rate: "Heart Rate",
  temperature: "Temp", weight: "Weight", spo2: "SpO2",
  respiratory_rate: "Resp Rate", glucose: "Glucose",
};

export default function VitalsChart({ vitals }) {
  const data = useMemo(() => {
    const byDate = {};
    vitals.forEach((v) => {
      const d = (v.recorded_at || "").slice(0, 10);
      if (!d) return;
      byDate[d] = byDate[d] || { date: d };
      byDate[d][v.type] = v.value;
    });
    return Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date));
  }, [vitals]);

  const types = useMemo(() => [...new Set(vitals.map((v) => v.type))], [vitals]);

  if (!data.length) {
    return <div className="py-8 text-center text-sm text-muted-foreground">No vital readings recorded.</div>;
  }

  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data} margin={{ top: 8, right: 16, left: -12, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
        <XAxis dataKey="date" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
        <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
        <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
        <Legend wrapperStyle={{ fontSize: 12 }} />
        {types.map((t) => (
          <Line key={t} type="monotone" dataKey={t} name={LABELS[t] || t} stroke={COLORS[t] || "#64748b"} strokeWidth={2} dot={{ r: 3 }} />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}