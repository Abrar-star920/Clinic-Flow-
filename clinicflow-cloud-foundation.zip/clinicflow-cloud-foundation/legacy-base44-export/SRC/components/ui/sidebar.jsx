




Upgrade


Back to Dashboard
Code files


base44
src
api
components
analytics
assistant
billing
branding
clinical
concierge
identification
insights
landing
messaging
patient
tabs
PatientInvoices.jsx
SectionCard.jsx
portal
InsuranceFinder.jsx
MyRecords.jsx
PayBill.jsx
PortalConcierge.jsx
PortalMessages.jsx
ScheduleForm.jsx
rpm
AlertsPanel.jsx
LogTimeDialog.jsx
VitalsTrendsWidget.jsx
scheduling
EligibilityBlockDialog.jsx
security
ActivationGate.jsx
SecurityGate.jsx
VaultLockScreen.jsx
tasks
TaskDialog.jsx
ui
accordion.jsx
alert-dialog.jsx
alert.jsx
aspect-ratio.jsx
avatar.jsx
badge.jsx
breadcrumb.jsx
button.jsx
calendar.jsx
card.jsx
carousel.jsx
chart.jsx
checkbox.jsx
collapsible.jsx
command.jsx
context-menu.jsx
dialog.jsx
drawer.jsx
dropdown-menu.jsx
form.jsx
hover-card.jsx
image-helpers.js
image.jsx
input-otp.jsx
input.jsx
label.jsx
menubar.jsx
navigation-menu.jsx
pagination.jsx
popover.jsx
progress.jsx
radio-group.jsx
resizable.jsx
scroll-area.jsx
select.jsx
separator.jsx
sheet.jsx
sidebar.jsx
skeleton.jsx
slider.jsx
sonner.jsx
switch.jsx
table.jsx
tabs.jsx
textarea.jsx
toast.jsx
toaster.jsx
toggle-group.jsx
toggle.jsx
tooltip.jsx
use-toast.jsx
AuthLayout.jsx
Avatar.jsx
DoctorDialog.jsx
GoogleCalendarConnect.jsx
GoogleIcon.jsx
InactivityLogout.jsx
Layout.jsx
PageHeader.jsx
PatientIntakeDialog.jsx
PhotoUpload.jsx
ProtectedRoute.jsx
ProviderCalendar.jsx
RoleRouter.jsx
ScrollToTop.jsx
StatCard.jsx
StatusBadge.jsx
UserNotRegisteredError.jsx
hooks
lib
pages
utils
App.jsx
index.css
main.jsx
.gitignore
AGENTS.md
CLAUDE.md
components.json
eslint.config.js
index.html
jsconfig.json
package.json
postcss.config.js
README.md
tailwind.config.js
vite.config.js
src
components
ui
sidebar.jsx

Split view
Code editing is only available on paid plans.
View plans

123456789101112131415161718192021222324252627282930313233343536373839404142
const SIDEBAR_COOKIE_NAME: "sidebar_state"
Cannot edit in read-only editor