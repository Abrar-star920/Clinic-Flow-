import React from "react";
import { ShieldAlert, CheckCircle2, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";

export default function EligibilityBlockDialog({ result, onClose }) {
  const open = !!result;
  const blocked = result && !result.eligible;
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose(); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {blocked
              ? <ShieldAlert className="h-5 w-5 text-rose-600" />
              : <CheckCircle2 className="h-5 w-5 text-emerald-600" />}
            {blocked ? "Booking blocked by rules engine" : "Eligibility check passed"}
          </DialogTitle>
          <DialogDescription>
            {blocked
              ? "This appointment cannot be confirmed until the blocking items are resolved."
              : "All scheduling rules passed. You can confirm the appointment."}
          </DialogDescription>
        </DialogHeader>

        {result?.patient && (
          <div className="rounded-lg border border-border bg-muted/30 px-3 py-2 text-sm">
            <span className="font-semibold text-foreground">{result.patient.full_name || "Patient"}</span>
            <span className="ml-2 text-xs text-muted-foreground">Chart: {result.patient.chart_status || "existing"}</span>
          </div>
        )}

        {result?.checks?.length > 0 && (
          <ul className="space-y-1.5">
            {result.checks.map((c, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                {c.passed
                  ? <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                  : c.required
                    ? <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-rose-500" />
                    : <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />}
                <span className={c.passed ? "text-foreground" : c.required ? "text-rose-700" : "text-amber-700"}>{c.message}</span>
              </li>
            ))}
          </ul>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}