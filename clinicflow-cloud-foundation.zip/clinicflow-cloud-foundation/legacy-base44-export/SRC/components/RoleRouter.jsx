import React from "react";
import { Outlet } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import Layout from "@/components/Layout";
import PatientPortal from "@/pages/PatientPortal";

const STAFF_ROLES = ["admin", "doctor", "nurse", "receptionist", "billing"];

export default function RoleRouter() {
  const { user } = useAuth();
  // Any staff role gets the operations dashboard; patients get their portal.
  if (user && STAFF_ROLES.includes(user.role)) {
    return (
      <Layout>
        <Outlet />
      </Layout>
    );
  }
  return <PatientPortal />;
}