import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Loader2, ShieldAlert, ShieldCheck, UserRound, Building2, HelpCircle,
  PhoneCall, FileSearch, CheckCircle2, XCircle, ChevronRight,
} from "lucide-react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/components/ui/use-toast";
import StatusBadge from "@/components/StatusBadge";

const norm = (s = "") => s.toLowerCase().replace(/[^a-z0-9]/g, "");

function payerMatches(a, b) {
  const na = norm(a), nb = norm(b);
  if (!na || !nb) return false;
  return na.includes(nb) || nb.includes(na);
}

export default function CallerVerificationDialog({ open, onOpenChange, onIdentifyPatient }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [path, setPath] = useState(null); // null | "insurance" | "other"

  // insurance rep form
  const [rep, setRep] = useState({ callerName: "", phone: "", payer: "", memberId: "", group: "", npi: "", reason: "" });
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null); // { state, record, patient, note }
  const [escalating, setEscalating] = useState(false);

  // other/third-party form
  const [other, setOther] = useState({ callerName: "", phone: "", org: "", reason: "" });

  function reset() {
    setPath(null);
    setRep({ callerName: "", phone: "", payer: "", memberId: "", group: "", npi: "", reason: "" });
    setOther({ callerName: "", phone: "", org: "", reason: "" });
    setResult(null);
    setBusy(false);
    setEscalating(false);
  }

  // ---- Insurance representative verification ----
  async function verifyInsurance(e) {
    e.preventDefault();
    if (!rep.callerName.trim() || !rep.payer.trim() || !rep.memberId.trim()) return;
    setBusy(true);
    setResult(null);
    try {
      const records = await base44.entities.InsuranceRecord.filter({ member_id: rep.memberId.trim() }, "-created_date", 20);
      const record = (records || [])[0];
      if (!record) {
        setResult({ state: "no_match", record: null, patient: null, note: "No insurance record found for this member ID." });
        return;
      }
      let patient = null;
      if (record.patient_id) {
        try { patient = await base44.entities.Patient.get(record.patient_id); } catch { /* ignore */ }
      }
      const payerOk = payerMatches(record.payer, rep.payer);
      const eligible = record.eligibility_status === "verified";
      if (!payerOk) {
        setResult({
          state: "payer_mismatch", record, patient,
          note: `Member ID belongs to payer "${record.payer || "unknown"}", not "${rep.payer}". Possible wrong payer or fraud.`,
        });
      } else if (!eligible) {
        setResult({
          state: "pending", record, patient,
          note: `Payer matches but eligibility is ${record.eligibility_status}. Confirm eligibility before disclosing details.`,
        });
      } else {
        setResult({ state: "verified", record, patient, note: "Payer matched and eligibility verified." });
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Lookup failed", description: err?.message });
    } finally {
      setBusy(false);
    }
  }

  async function logVerification(rec, patient, outcome, hipaaCheck, resultStatus, notes) {
    try {
      await base44.entities.IdentityVerification.create({
        patient_id: patient?.id || null,
        patient_name: patient?.full_name || rec?.patient_name || "",
        patient_email: patient?.email || rec?.patient_email || "",
        caller_name: rep.callerName,
        caller_phone: rep.phone,
        caller_relationship: "insurance_representative",
        method: "manual",
        dob_provided: false,
        name_provided: false,
        result: resultStatus,
        matched_patient_ids: patient?.id ? [patient.id] : [],
        hipaa_check: hipaaCheck,
        outcome,
        handled_by: "staff",
        notes,
      });
    } catch { /* non-blocking */ }
  }

  async function logAudit(patient, summary) {
    try {
      await base44.entities.AuditLog.create({
        entity_type: "InsuranceRecord",
        entity_id: result?.record?.id || "",
        patient_id: patient?.id || null,
        patient_name: patient?.full_name || "",
        action: "view",
        actor_email: "staff",
        summary,
      });
    } catch { /* non-blocking */ }
  }

  async function createEscalation(category, reason, priority, captured, aiSummary) {
    await base44.entities.Escalation.create({
      caller_name: rep.callerName || other.callerName,
      phone: rep.phone || other.phone,
      category,
      reason,
      priority,
      status: "open",
      identity_status: "insurance_rep",
      hipaa_status: "not_authorized",
      captured_details: JSON.stringify(captured),
      ai_summary: aiSummary,
      escalation_reason: reason,
      created_at: new Date().toISOString(),
    });
  }

  async function proceedInsurance() {
    const rec = result.record;
    const patient = result.patient;
    const notes = `Insurance rep verified — payer ${rec.payer}, member ${rep.memberId}, group ${rep.group || "—"}. ${result.note}`;
    await logVerification(rec, patient, "proceed", "authorized_caller", "existing", notes);
    await logAudit(patient, `Insurance rep ${rep.callerName} (${rep.payer}) verified for member ${rep.memberId}.`);
    toast({ title: "Insurance representative verified", description: "You may discuss insurance and billing." });
    onOpenChange(false);
    if (patient?.id) navigate(`/patients/${patient.id}`);
    reset();
  }

  async function escalateInsurance() {
    setEscalating(true);
    try {
      const captured = { type: "insurance_rep", ...rep, found_payer: result?.record?.payer || null, found_patient: result?.patient?.full_name || null };
      const aiSummary = `Insurance rep ${rep.callerName} (${rep.payer}) — member ${rep.memberId}. ${result?.note || "Verification failed."}`;
      await createEscalation("insurance", "identity_ambiguous", "high", captured, aiSummary);
      await logVerification(result?.record, result?.patient, "escalate", "not_authorized", result?.state || "ambiguous", `Escalated: ${result?.note || "insurance verification failed"}`);
      toast({ title: "Escalated to staff", description: "Do not disclose patient or insurance details." });
      onOpenChange(false);
      reset();
    } catch (err) {
      toast({ variant: "destructive", title: "Escalation failed", description: err?.message });
    } finally {
      setEscalating(false);
    }
  }

  // ---- Other / third party ----
  async function escalateOther() {
    setEscalating(true);
    try {
      const captured = { type: "other", ...other };
      const aiSummary = `Third-party caller ${other.callerName} (${other.org || "unknown org"}) — ${other.reason || "no reason given"}. Identity not verifiable; no disclosure.`;
      await createEscalation("other", "hipaa_unauthorized", "medium", captured, aiSummary);
      try {
        await base44.entities.IdentityVerification.create({
          caller_name: other.callerName,
          caller_phone: other.phone,
          caller_relationship: "other",
          method: "manual",
          result: "ambiguous",
          hipaa_check: "not_authorized",
          outcome: "escalate",
          handled_by: "staff",
          notes: `Org: ${other.org}. Reason: ${other.reason}`,
        });
      } catch { /* non-blocking */ }
      toast({ title: "Routed to staff", description: "No patient information disclosed." });
      onOpenChange(false);
      reset();
    } catch (err) {
      toast({ variant: "destructive", title: "Escalation failed", description: err?.message });
    } finally {
      setEscalating(false);
    }
  }

  function choosePatient() {
    onOpenChange(false);
    reset();
    if (onIdentifyPatient) onIdentifyPatient();
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!busy && !escalating) { onOpenChange(v); if (!v) reset(); } }}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PhoneCall className="h-5 w-5 text-primary" /> Caller Verification
          </DialogTitle>
          <DialogDescription>
            Before sharing any information, verify who is on the line. Never disclose patient or insurance details to an unverified caller.
          </DialogDescription>
        </DialogHeader>

        {!path && (
          <div className="space-y-3">
            <p className="text-sm font-medium text-foreground">Who is on the line?</p>
            <div className="grid gap-3">
              <PathCard icon={UserRound} title="The Patient" desc="Verify identity by DOB (and name if needed)." onClick={() => choosePatient()} />
              <PathCard icon={Building2} title="Insurance Company Representative" desc="Verify against the patient's insurance record by member ID + payer." accent onClick={() => setPath("insurance")} />
              <PathCard icon={HelpCircle} title="Someone Else" desc="Third party — do not disclose; route to staff." onClick={() => setPath("other")} />
            </div>
          </div>
        )}

        {path === "insurance" && (
          <div className="space-y-4">
            <form onSubmit={verifyInsurance} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="rn">Representative Name *</Label>
                  <Input id="rn" value={rep.callerName} onChange={(e) => setRep({ ...rep, callerName: e.target.value })} placeholder="Rep full name" required />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="rp">Callback Phone</Label>
                  <Input id="rp" value={rep.phone} onChange={(e) => setRep({ ...rep, phone: e.target.value })} placeholder="(555) 123-4567" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="py">Payer / Insurance Company *</Label>
                  <Input id="py" value={rep.payer} onChange={(e) => setRep({ ...rep, payer: e.target.value })} placeholder="e.g. Blue Cross Blue Shield" required />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="mi">Member ID *</Label>
                  <Input id="mi" value={rep.memberId} onChange={(e) => setRep({ ...rep, memberId: e.target.value })} placeholder="Member ID" required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="gr">Group Number</Label>
                  <Input id="gr" value={rep.group} onChange={(e) => setRep({ ...rep, group: e.target.value })} placeholder="Group #" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="np">Rep / NPI ID</Label>
                  <Input id="np" value={rep.npi} onChange={(e) => setRep({ ...rep, npi: e.target.value })} placeholder="Optional" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="rs">Reason for Call</Label>
                <Textarea id="rs" value={rep.reason} onChange={(e) => setRep({ ...rep, reason: e.target.value })} rows={2} placeholder="What are they requesting?" />
              </div>
              {!result && (
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setPath(null)} disabled={busy}>Back</Button>
                  <Button type="submit" disabled={busy} className="gap-1.5">
                    {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileSearch className="h-4 w-4" />} Verify Insurance
                  </Button>
                </DialogFooter>
              )}
            </form>

            {result && (
              <div className="space-y-3">
                <InsuranceResultBanner result={result} />

                {result.patient && (
                  <div className="rounded-lg border border-border bg-card p-3 text-sm">
                    <div className="font-display font-semibold text-foreground">{result.patient.full_name}</div>
                    <div className="text-xs text-muted-foreground">DOB {result.patient.dob || "—"} · {result.patient.email || "No email"}</div>
                    <div className="mt-1 flex flex-wrap items-center gap-2">
                      <span className="text-xs text-muted-foreground">Eligibility:</span>
                      <StatusBadge status={result.record.eligibility_status} />
                      <span className="text-xs text-muted-foreground">Network:</span>
                      <StatusBadge status={result.record.network_status} />
                    </div>
                  </div>
                )}

                {result.state !== "no_match" && (
                  <div className="rounded-lg border border-border bg-muted/40 p-3 text-xs text-muted-foreground">
                    On file: payer <strong>{result.record.payer || "—"}</strong> · plan <strong>{result.record.plan_name || "—"}</strong> · member <strong>{result.record.member_id}</strong>
                  </div>
                )}

                {result.state === "verified" ? (
                  <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-800">
                    <ShieldCheck className="mb-1 inline h-4 w-4" /> Payer matched and eligibility verified. You may discuss insurance and billing for this member.
                  </div>
                ) : (
                  <div className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-800">
                    <ShieldAlert className="mb-1 inline h-4 w-4" /> Do not disclose patient or insurance details. Escalate to staff for verification.
                  </div>
                )}

                <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
                  <Button type="button" variant="ghost" size="sm" onClick={() => { setResult(null); }} disabled={escalating}>Re-verify</Button>
                  {result.state === "verified" ? (
                    <Button variant="gold" disabled={escalating} onClick={proceedInsurance} className="gap-1.5">
                      <CheckCircle2 className="h-4 w-4" /> Proceed {result.patient ? "(open chart)" : ""}
                    </Button>
                  ) : (
                    <Button variant="destructive" disabled={escalating} onClick={escalateInsurance} className="gap-1.5">
                      {escalating ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldAlert className="h-4 w-4" />} Escalate to staff
                    </Button>
                  )}
                </DialogFooter>
              </div>
            )}
          </div>
        )}

        {path === "other" && (
          <div className="space-y-4">
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
              <ShieldAlert className="mb-1 inline h-4 w-4" /> This caller is not the patient and not a verified insurance representative.
              Do <strong>not</strong> disclose any patient information. Capture details and route to staff.
            </div>
            <form onSubmit={(e) => { e.preventDefault(); escalateOther(); }} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="on">Caller Name *</Label>
                  <Input id="on" value={other.callerName} onChange={(e) => setOther({ ...other, callerName: e.target.value })} required />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="op">Phone</Label>
                  <Input id="op" value={other.phone} onChange={(e) => setOther({ ...other, phone: e.target.value })} />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="oo">Organization / Relationship</Label>
                <Input id="oo" value={other.org} onChange={(e) => setOther({ ...other, org: e.target.value })} placeholder="e.g. employer, attorney, family" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="orr">Reason for Call</Label>
                <Textarea id="orr" value={other.reason} onChange={(e) => setOther({ ...other, reason: e.target.value })} rows={2} />
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setPath(null)} disabled={escalating}>Back</Button>
                <Button type="submit" variant="destructive" disabled={escalating} className="gap-1.5">
                  {escalating ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldAlert className="h-4 w-4" />} Route to Staff
                </Button>
              </DialogFooter>
            </form>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function PathCard({ icon: Icon, title, desc, onClick, accent }) {
  return (
    <button type="button" onClick={onClick}
      className={`flex items-center gap-3 rounded-xl border p-3.5 text-left transition-colors hover:bg-muted/60 ${accent ? "border-primary/40 bg-primary/5" : "border-border bg-card"}`}>
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${accent ? "bg-primary/10 text-primary" : "bg-secondary text-secondary-foreground"}`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1">
        <div className="font-display text-sm font-semibold text-foreground">{title}</div>
        <div className="text-xs text-muted-foreground">{desc}</div>
      </div>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </button>
  );
}

function InsuranceResultBanner({ result }) {
  const map = {
    verified: { icon: CheckCircle2, tone: "bg-emerald-50 text-emerald-800 border-emerald-200", label: "Insurance Representative Verified" },
    pending: { icon: ShieldAlert, tone: "bg-amber-50 text-amber-800 border-amber-200", label: "Payer Matched — Eligibility Pending" },
    payer_mismatch: { icon: XCircle, tone: "bg-rose-50 text-rose-800 border-rose-200", label: "Payer Mismatch — Do Not Disclose" },
    no_match: { icon: XCircle, tone: "bg-slate-50 text-slate-700 border-slate-200", label: "No Insurance Record Found" },
  };
  const m = map[result.state] || map.no_match;
  const Icon = m.icon;
  return (
    <div className={`flex items-start gap-2 rounded-lg border p-3 text-sm font-medium ${m.tone}`}>
      <Icon className="mt-0.5 h-4 w-4" />
      <div>
        <div>{m.label}</div>
        <div className="mt-0.5 text-xs font-normal">{result.note}</div>
      </div>
    </div>
  );
}