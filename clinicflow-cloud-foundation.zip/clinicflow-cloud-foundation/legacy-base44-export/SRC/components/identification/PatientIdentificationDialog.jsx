import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, ShieldAlert, UserCheck, UserX, FileSearch, Headset } from "lucide-react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import StatusBadge from "@/components/StatusBadge";

const STEPS = ["phone", "dob", "name", "result"];

export default function PatientIdentificationDialog({ open, onOpenChange }) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState("phone");
  const [busy, setBusy] = useState(false);
  const [callerName, setCallerName] = useState("");
  const [callerPhone, setCallerPhone] = useState("");
  const [relationship, setRelationship] = useState("self");
  const [dob, setDob] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneHintCount, setPhoneHintCount] = useState(null);
  const [dobMatches, setDobMatches] = useState([]);
  const [nameMatches, setNameMatches] = useState([]);
  const [result, setResult] = useState(null); // { status, patient, matches }
  const [hipaa, setHipaa] = useState(null);
  const [escalating, setEscalating] = useState(false);

  function reset() {
    setStep("phone"); setBusy(false);
    setCallerName(""); setCallerPhone(""); setRelationship("self");
    setDob(""); setFirstName(""); setLastName("");
    setPhoneHintCount(null); setDobMatches([]); setNameMatches([]);
    setResult(null); setHipaa(null); setEscalating(false);
  }

  const normName = (n) => (n || "").trim().toLowerCase();

  async function searchByDob(dobVal) {
    const matches = await base44.entities.Patient.filter({ dob: dobVal }, "-created_date", 50);
    return matches || [];
  }

  function nameMatchesPatient(p, fn, ln) {
    const full = normName(p.full_name);
    return (!fn || full.includes(fn)) && (!ln || full.includes(ln));
  }

  // ---- Step handlers ----
  async function onPhoneNext(e) {
    e.preventDefault();
    if (!callerName.trim()) return;
    setBusy(true);
    try {
      // Phone is ONLY a hint — never decides new vs existing.
      if (callerPhone.trim()) {
        const hint = await base44.entities.Patient.filter({ phone: callerPhone.trim() }, "-created_date", 50);
        setPhoneHintCount(hint?.length || 0);
      } else {
        setPhoneHintCount(null);
      }
      setStep("dob");
    } catch { setPhoneHintCount(null); setStep("dob"); }
    finally { setBusy(false); }
  }

  async function onDobNext(e) {
    e.preventDefault();
    if (!dob) return;
    setBusy(true);
    try {
      const matches = await searchByDob(dob);
      setDobMatches(matches);
      if (matches.length === 0) {
        // No matching chart by DOB → No Matching Chart (new patient)
        setResult({ status: "no_match", patient: null, matches: [] });
        setHipaa({ callerType: "unknown", authorized: false });
        setStep("result");
      } else if (matches.length === 1) {
        finalizeMatch(matches[0]);
      } else {
        // Multiple DOB matches → disambiguate by name
        setStep("name");
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Lookup failed", description: err?.message });
    } finally { setBusy(false); }
  }

  async function onNameNext(e) {
    e.preventDefault();
    setBusy(true);
    try {
      const fn = normName(firstName), ln = normName(lastName);
      const filtered = dobMatches.filter((p) => nameMatchesPatient(p, fn, ln));
      setNameMatches(filtered);
      if (filtered.length === 1) {
        finalizeMatch(filtered[0]);
      } else {
        // 0 or >1 → ambiguous → escalate
        setResult({
          status: "ambiguous",
          patient: null,
          matches: dobMatches.map((p) => ({ id: p.id, name: p.full_name, dob: p.dob })),
        });
        setHipaa({ callerType: "unknown", authorized: false });
        setStep("result");
      }
    } finally { setBusy(false); }
  }

  // ---- HIPAA check for a matched patient ----
  async function finalizeMatch(patient) {
    const chartStatus = patient.chart_status === "partial" ? "partial" : "existing";
    const callerIsSelf = relationship === "self" ||
      normName(patient.full_name).includes(normName(callerName));
    let hipaaRes = { callerType: "self", authorized: true, contact: null };
    if (!callerIsSelf) {
      // Third party: must have HIPAA authorization on file. Emergency/support contact is NOT enough.
      const contacts = await base44.entities.PatientContact.filter({ patient_id: patient.id }, "-created_date", 50);
      const cn = normName(callerName);
      const cp = (callerPhone || "").replace(/\D/g, "");
      const auth = (contacts || []).find((c) =>
        c.hipaa_authorized &&
        c.authorization_status === "authorized" &&
        (normName(c.full_name).includes(cn) || cn.includes(normName(c.full_name)) ||
          (cp && (c.phone || "").replace(/\D/g, "") === cp))
      );
      hipaaRes = auth
        ? { callerType: "authorized_caller", authorized: true, contact: auth }
        : { callerType: "third_party", authorized: false, contact: null };
    }
    setHipaa(hipaaRes);
    setResult({ status: chartStatus, patient, matches: [] });
    setStep("result");
  }

  // ---- Logging ----
  async function logVerification(res, hipaaRes, outcome) {
    try {
      await base44.entities.IdentityVerification.create({
        patient_id: res.patient?.id || null,
        patient_name: res.patient?.full_name || "",
        patient_email: res.patient?.email || "",
        caller_name: callerName,
        caller_phone: callerPhone,
        caller_relationship: relationship,
        method: res.matches?.length > 0 && firstName ? "phone_hint_dob_name" : "phone_hint_dob",
        dob_provided: !!dob,
        name_provided: !!(firstName || lastName),
        result: res.status,
        matched_patient_ids: res.patient ? [res.patient.id] : (res.matches || []).map((m) => m.id),
        hipaa_check: hipaaRes?.callerType || "not_checked",
        outcome,
        handled_by: "staff",
        notes: `DOB ${dob || "—"}; name ${firstName} ${lastName}`.trim(),
      });
    } catch { /* non-blocking */ }
  }

  async function logAudit(patientId, patientName, summary) {
    try {
      await base44.entities.AuditLog.create({
        entity_type: "IdentityVerification",
        entity_id: patientId || "",
        patient_id: patientId || null,
        patient_name: patientName || "",
        action: "view",
        actor_email: "staff",
        summary,
      });
    } catch { /* non-blocking */ }
  }

  // ---- Escalation with full context ----
  async function escalate(reason) {
    setEscalating(true);
    try {
      const captured = {
        caller_name: callerName, caller_phone: callerPhone, relationship,
        dob, first_name: firstName, last_name: lastName,
        phone_hint_count: phoneHintCount,
        dob_matches: (dobMatches || []).map((p) => ({ id: p.id, name: p.full_name, dob: p.dob })),
        name_matches: (nameMatches || []).map((p) => ({ id: p.id, name: p.full_name })),
      };
      const aiSummary = `Caller ${callerName} (${relationship}) — identity ${result?.status || "undetermined"}. ` +
        `HIPAA: ${hipaa?.callerType || "not checked"} (${hipaa?.authorized ? "authorized" : "not authorized"}). ` +
        `DOB provided: ${!!dob}. ${reason}`;
      await base44.entities.Escalation.create({
        caller_name: callerName,
        phone: callerPhone,
        category: result?.status === "ambiguous" ? "technical_ai" : "medical_records",
        reason: result?.status === "ambiguous" ? "identity_ambiguous" : "hipaa_unauthorized",
        priority: result?.status === "ambiguous" ? "high" : "medium",
        status: "open",
        identity_status: result?.status || "undetermined",
        hipaa_status: hipaa?.callerType || "not_checked",
        intent: "",
        captured_details: JSON.stringify(captured),
        ai_summary: aiSummary,
        escalation_reason: reason,
        created_at: new Date().toISOString(),
      });
      await logVerification(result || { status: "ambiguous", patient: null, matches: [] }, hipaa, "escalate");
      toast({ title: "Escalated to staff", description: "Full context captured for the representative." });
      onOpenChange(false);
      reset();
    } catch (err) {
      toast({ variant: "destructive", title: "Escalation failed", description: err?.message });
    } finally { setEscalating(false); }
  }

  // ---- Proceed: open chart + mark verified ----
  async function proceedToChart() {
    const p = result.patient;
    await logVerification(result, hipaa, "proceed");
    await logAudit(p.id, p.full_name, `Identity verified (${result.status}); HIPAA: ${hipaa.callerType}. Opened chart.`);
    try {
      await base44.entities.Patient.update(p.id, { identity_verified: true, identity_verified_at: new Date().toISOString() });
    } catch { /* non-blocking */ }
    onOpenChange(false);
    reset();
    navigate(`/patients/${p.id}`);
  }

  // ---- Create partial chart for no-match ----
  async function createPartialChart() {
    setBusy(true);
    try {
      const created = await base44.entities.Patient.create({
        full_name: callerName,
        dob: dob || undefined,
        phone: callerPhone || undefined,
        chart_status: "partial",
        identity_verified: true,
        identity_verified_at: new Date().toISOString(),
        insurance_status: "pending",
        intake_status: "new",
      });
      await logVerification({ status: "no_match", patient: created, matches: [] }, hipaa, "proceed");
      await logAudit(created.id, created.full_name, `Created partial chart (no DOB match); identity flagged new.`);
      toast({ title: "Partial chart created", description: "Complete demographics during intake." });
      onOpenChange(false);
      reset();
      navigate(`/patients/${created.id}`);
    } catch (err) {
      toast({ variant: "destructive", title: "Could not create chart", description: err?.message });
    } finally { setBusy(false); }
  }

  const progress = STEPS.indexOf(step);

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!busy && !escalating) { onOpenChange(v); if (!v) reset(); } }}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSearch className="h-5 w-5 text-primary" /> Patient Identification
          </DialogTitle>
          <DialogDescription>
            Phone is a lookup hint only. Identity is confirmed by DOB (and name if needed). Never guess.
          </DialogDescription>
        </DialogHeader>

        {/* progress */}
        <div className="flex items-center gap-1.5">
          {STEPS.map((s, i) => (
            <div key={s} className={`h-1.5 flex-1 rounded-full ${i <= progress ? "bg-primary" : "bg-muted"}`} />
          ))}
        </div>

        {step === "phone" && (
          <form onSubmit={onPhoneNext} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="cn">Caller Name *</Label>
              <Input id="cn" value={callerName} onChange={(e) => setCallerName(e.target.value)} placeholder="Who is calling?" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="cp">Caller Phone (hint only)</Label>
                <Input id="cp" value={callerPhone} onChange={(e) => setCallerPhone(e.target.value)} placeholder="(555) 123-4567" />
              </div>
              <div className="space-y-1.5">
                <Label>Caller is the</Label>
                <Select value={relationship} onValueChange={setRelationship}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="self">Patient (self)</SelectItem>
                    <SelectItem value="spouse">Spouse</SelectItem>
                    <SelectItem value="parent">Parent</SelectItem>
                    <SelectItem value="child">Child</SelectItem>
                    <SelectItem value="caregiver">Caregiver</SelectItem>
                    <SelectItem value="legal_guardian">Legal Guardian</SelectItem>
                    <SelectItem value="other">Other / Third party</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {phoneHintCount !== null && (
              <p className="text-xs text-muted-foreground">
                Phone hint: {phoneHintCount} record(s) share this number — this does <strong>not</strong> confirm identity.
              </p>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Cancel</Button>
              <Button type="submit" disabled={busy || !callerName.trim()} className="gap-1.5">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Next: Verify DOB
              </Button>
            </DialogFooter>
          </form>
        )}

        {step === "dob" && (
          <form onSubmit={onDobNext} className="space-y-4">
            <p className="text-sm text-muted-foreground">Confirm identity with the patient's date of birth.</p>
            <div className="space-y-1.5">
              <Label htmlFor="dob">Date of Birth *</Label>
              <Input id="dob" type="date" value={dob} onChange={(e) => setDob(e.target.value)} required autoFocus />
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setStep("phone")} disabled={busy}>Back</Button>
              <Button type="submit" disabled={busy || !dob} className="gap-1.5">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Search by DOB
              </Button>
            </DialogFooter>
          </form>
        )}

        {step === "name" && (
          <form onSubmit={onNameNext} className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Multiple patients share this DOB. Disambiguate with first and last name.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label htmlFor="fn">First Name</Label>
                <Input id="fn" value={firstName} onChange={(e) => setFirstName(e.target.value)} autoFocus />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ln">Last Name</Label>
                <Input id="ln" value={lastName} onChange={(e) => setLastName(e.target.value)} />
              </div>
            </div>
            <div className="rounded-lg border border-border bg-muted/40 p-3 text-xs text-muted-foreground">
              DOB matches: {dobMatches.length}
              <ul className="mt-1 space-y-0.5">
                {dobMatches.slice(0, 6).map((p) => (<li key={p.id}>• {p.full_name} — {p.dob}</li>))}
              </ul>
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setStep("dob")} disabled={busy}>Back</Button>
              <Button type="submit" disabled={busy || (!firstName && !lastName)} className="gap-1.5">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null} Confirm Identity
              </Button>
            </DialogFooter>
          </form>
        )}

        {step === "result" && result && (
          <div className="space-y-4">
            <ResultBanner status={result.status} hipaa={hipaa} />

            {result.patient && (
              <div className="rounded-lg border border-border bg-card p-3 text-sm">
                <div className="font-display font-semibold text-foreground">{result.patient.full_name}</div>
                <div className="text-xs text-muted-foreground">DOB {result.patient.dob || "—"} · {result.patient.email || "No email"}</div>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">Chart:</span>
                  <StatusBadge status={result.patient.chart_status || "existing"} />
                </div>
              </div>
            )}

            {result.status === "ambiguous" && (
              <ul className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 space-y-0.5">
                {result.matches.map((m) => (<li key={m.id}>• {m.name} — {m.dob}</li>))}
              </ul>
            )}

            {hipaa && !hipaa.authorized && result.patient && (
              <div className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-800">
                <ShieldAlert className="mb-1 inline h-4 w-4" /> HIPAA authorization not on file for this caller.
                Being an emergency or support contact does <strong>not</strong> authorize disclosure.
                Do not share patient information — route to staff.
              </div>
            )}

            <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
              <Button type="button" variant="ghost" size="sm" className="gap-1.5" disabled={escalating}
                onClick={() => escalate("Caller requested a live representative")}>
                <Headset className="h-4 w-4" /> Speak with a representative
              </Button>
              <div className="flex gap-2">
                {result.status === "ambiguous" && (
                  <Button variant="gold" disabled={escalating} onClick={() => escalate("Identity ambiguous after DOB+name disambiguation")}>
                    {escalating ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldAlert className="h-4 w-4" />} Escalate to staff
                  </Button>
                )}
                {result.status === "no_match" && (
                  <Button variant="gold" disabled={busy} onClick={createPartialChart} className="gap-1.5">
                    {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserX className="h-4 w-4" />} Create partial chart
                  </Button>
                )}
                {result.status !== "no_match" && result.status !== "ambiguous" && (
                  hipaa?.authorized ? (
                    <Button variant="gold" disabled={busy} onClick={proceedToChart} className="gap-1.5">
                      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <UserCheck className="h-4 w-4" />} Open chart
                    </Button>
                  ) : (
                    <Button variant="destructive" disabled={escalating} onClick={() => escalate("Caller not HIPAA-authorized; disclosure blocked")}>
                      {escalating ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldAlert className="h-4 w-4" />} Escalate (no disclosure)
                    </Button>
                  )
                )}
              </div>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function ResultBanner({ status, hipaa }) {
  const map = {
    existing: { icon: UserCheck, tone: "bg-emerald-50 text-emerald-800 border-emerald-200", label: "Existing Chart — identity confirmed" },
    partial: { icon: FileSearch, tone: "bg-sky-50 text-sky-800 border-sky-200", label: "Partially Created Chart — referral/insurance pre-existed" },
    no_match: { icon: UserX, tone: "bg-slate-50 text-slate-700 border-slate-200", label: "No Matching Chart — new patient" },
    ambiguous: { icon: ShieldAlert, tone: "bg-amber-50 text-amber-800 border-amber-200", label: "Identity Ambiguous — route to staff" },
  };
  const m = map[status] || map.no_match;
  const Icon = m.icon;
  return (
    <div className={`flex items-center gap-2 rounded-lg border p-3 text-sm font-medium ${m.tone}`}>
      <Icon className="h-4 w-4" /> {m.label}
      {hipaa && status !== "no_match" && status !== "ambiguous" && (
        <span className="ml-auto text-xs font-normal">
          HIPAA: {hipaa.callerType === "self" ? "Self" : hipaa.authorized ? "Authorized caller" : "Not authorized"}
        </span>
      )}
    </div>
  );
}