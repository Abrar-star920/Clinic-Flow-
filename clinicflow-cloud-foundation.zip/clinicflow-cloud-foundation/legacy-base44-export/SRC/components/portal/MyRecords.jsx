import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Loader2, LogIn, LogOut, ShieldCheck, AlertCircle, CalendarClock, CheckCircle2,
  CreditCard, Stethoscope, Clock, User,
} from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

const todayStr = () => new Date().toISOString().slice(0, 10);

export default function MyRecords({ onSession }) {
  const { toast } = useToast();
  const [form, setForm] = useState({ phone: "", first_name: "", last_name: "" });
  const [loading, setLoading] = useState(false);
  const [notFound, setNotFound] = useState(false);
  const [session, setSession] = useState(null);
  const [payingId, setPayingId] = useState(null);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function signIn(e) {
    e.preventDefault();
    setLoading(true);
    setNotFound(false);
    try {
      const { data } = await base44.functions.invoke("patientPortalRecords", form);
      if (data?.error) throw new Error(data.error);
      if (data?.found) {
        setSession(data);
        if (onSession) onSession({ name: data.patient.full_name, email: data.patient.email, insurance_status: data.patient.insurance_status });
        toast({ title: "Signed in", description: `Welcome, ${data.patient.full_name}.` });
      } else {
        setNotFound(true);
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Sign-in failed", description: err?.message });
    } finally {
      setLoading(false);
    }
  }

  function signOut() {
    setSession(null);
    setForm({ phone: "", first_name: "", last_name: "" });
    if (onSession) onSession(null);
  }

  async function pay(claim) {
    if (window.self !== window.top) {
      toast({ variant: "destructive", title: "Open in published app", description: "Payment works only from the published app, not the preview." });
      return;
    }
    setPayingId(claim.id);
    try {
      const { data } = await base44.functions.invoke("createStripeCheckoutSession", {
        claim_id: claim.id,
        return_path: "/portal",
      });
      if (data?.url) window.location.href = data.url;
    } catch (err) {
      toast({ variant: "destructive", title: "Checkout failed", description: err?.response?.data?.error || err?.message });
    } finally {
      setPayingId(null);
    }
  }

  const money = (n) => `$${Number(n || 0).toFixed(2)}`;

  // ---- Signed-out: sign-in form ----
  if (!session) {
    return (
      <div className="space-y-5">
        <div className="rounded-xl border border-sky-100 bg-sky-50/60 px-4 py-3 text-sm text-sky-800">
          <div className="flex items-center gap-2 font-semibold"><ShieldCheck className="h-4 w-4" /> Access your records</div>
          <p className="mt-1">No insurance member ID? No problem. Sign in with your phone number, first name, and last name to view your appointments, insurance, and invoices.</p>
        </div>

        <form onSubmit={signIn} className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Phone Number">
              <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} required placeholder="(555) 000-0000" />
            </Field>
            <Field label="First Name">
              <Input value={form.first_name} onChange={(e) => set("first_name", e.target.value)} required placeholder="Jane" />
            </Field>
            <Field label="Last Name">
              <Input value={form.last_name} onChange={(e) => set("last_name", e.target.value)} required placeholder="Doe" />
            </Field>
          </div>
          <Button type="submit" disabled={loading} className="gap-1.5">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
            {loading ? "Verifying…" : "Sign In"}
          </Button>
        </form>

        {notFound && (
          <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
            <AlertCircle className="mt-0.5 h-4 w-4" />
            <span>No matching patient record found. Please confirm your details or contact us at (555) 200-1000.</span>
          </div>
        )}
      </div>
    );
  }

  // ---- Signed-in: records ----
  const { patient, appointments, invoices } = session;
  const today = todayStr();
  const sorted = [...appointments].sort((a, b) =>
    `${a.appointment_date} ${a.appointment_time || ""}`.localeCompare(`${b.appointment_date} ${b.appointment_time || ""}`)
  );
  const upcoming = sorted.filter((a) => (a.appointment_date || "") >= today && a.status !== "cancelled");
  const past = sorted.filter((a) => (a.appointment_date || "") < today || a.status === "completed" || a.status === "cancelled");
  const outstanding = (invoices || []).filter((c) => c.status !== "paid");

  return (
    <div className="space-y-6">
      {/* Patient header */}
      <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-5 shadow-sm sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-teal-400 to-sky-600 text-white shadow-soft">
            <User className="h-5 w-5" />
          </div>
          <div>
            <div className="font-display text-base font-bold text-foreground">{patient.full_name}</div>
            <div className="text-xs text-muted-foreground">{patient.email || patient.phone}</div>
          </div>
        </div>
        <Button variant="outline" size="sm" className="gap-1.5 self-start" onClick={signOut}>
          <LogOut className="h-4 w-4" /> Sign Out
        </Button>
      </div>

      {/* Insurance summary */}
      <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-4 w-4 text-primary" />
          <h3 className="font-display text-sm font-bold text-foreground">Insurance</h3>
          <div className="ml-auto"><StatusBadge status={patient.insurance_status} /></div>
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <InfoTile label="Provider" value={patient.insurance_provider || "—"} />
          <InfoTile label="Member ID" value={patient.insurance_member_id || "—"} mono />
        </div>
      </div>

      {/* Appointments */}
      <div>
        <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <CalendarClock className="h-4 w-4" /> Upcoming Appointments
        </h3>
        {upcoming.length === 0 ? (
          <Empty text="You have no upcoming appointments." />
        ) : (
          <div className="grid gap-3 sm:grid-cols-2">{upcoming.map((a) => <ApptCard key={a.id} a={a} />)}</div>
        )}
      </div>
      {past.length > 0 && (
        <div>
          <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
            <CheckCircle2 className="h-4 w-4" /> History
          </h3>
          <div className="grid gap-3 sm:grid-cols-2">{past.map((a) => <ApptCard key={a.id} a={a} />)}</div>
        </div>
      )}

      {/* Invoices */}
      <div>
        <h3 className="mb-3 flex items-center gap-2 font-display text-sm font-bold uppercase tracking-wide text-muted-foreground">
          <CreditCard className="h-4 w-4" /> Invoices
        </h3>
        {(invoices || []).length === 0 ? (
          <Empty text="No invoices on record." />
        ) : (
          <div className="space-y-3">
            {(invoices || []).map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card p-4 shadow-sm">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-sm font-bold text-foreground">{c.invoice_number || "Invoice"}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  {c.description && <div className="mt-0.5 truncate text-xs text-muted-foreground">{c.description}</div>}
                </div>
                <div className="flex items-center gap-3">
                  <div className="font-display text-base font-bold text-foreground">{money(c.amount)}</div>
                  {c.status !== "paid" ? (
                    <Button size="sm" className="h-8 gap-1.5 text-xs" disabled={payingId === c.id} onClick={() => pay(c)}>
                      {payingId === c.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CreditCard className="h-3.5 w-3.5" />}
                      Pay
                    </Button>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600">
                      <CheckCircle2 className="h-4 w-4" /> Paid
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold">{label}</Label>
      {children}
    </div>
  );
}

function InfoTile({ label, value, mono }) {
  return (
    <div className="rounded-lg border border-border bg-background/50 px-3 py-2.5">
      <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={`mt-0.5 text-sm font-semibold text-foreground ${mono ? "font-mono tracking-wide" : ""}`}>{value}</div>
    </div>
  );
}

function ApptCard({ a }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="font-display text-base font-bold text-foreground">
            {a.appointment_date ? new Date(a.appointment_date + "T00:00:00").toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }) : "—"}
          </div>
          <div className="text-sm font-medium text-primary">{a.appointment_time?.slice(0, 5) || "—"}</div>
        </div>
        <StatusBadge status={a.status} />
      </div>
      <div className="mt-3 space-y-1.5 text-sm text-muted-foreground">
        <div className="flex items-center gap-2"><Stethoscope className="h-3.5 w-3.5" /> {a.provider}</div>
        <div className="capitalize">{a.type?.replace(/_/g, " ")}</div>
      </div>
    </div>
  );
}

function Empty({ text }) {
  return (
    <div className="rounded-xl border border-dashed border-border bg-card/50 px-6 py-8 text-center text-sm text-muted-foreground">
      <Clock className="mx-auto h-6 w-6 text-muted-foreground/50" />
      <p className="mt-2">{text}</p>
    </div>
  );
}