import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Search, ShieldCheck, BadgeCheck, AlertCircle, IdCard } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

export default function InsuranceFinder({ onResolved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({ phone: "", first_name: "", last_name: "" });
  const [searching, setSearching] = useState(false);
  const [result, setResult] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    setSearching(true);
    setResult(null);
    setNotFound(false);
    try {
      const { data } = await base44.functions.invoke("patientPortalLookup", form);
      if (data?.error) throw new Error(data.error);
      if (data?.found) {
        setResult(data);
        if (onResolved) onResolved({ name: data.full_name, email: data.email, insurance_status: data.insurance_status });
        toast({ title: "Insurance details found" });
      } else {
        setNotFound(true);
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Lookup failed", description: err?.message });
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-sky-100 bg-sky-50/60 px-4 py-3 text-sm text-sky-800">
        <div className="flex items-center gap-2 font-semibold"><ShieldCheck className="h-4 w-4" /> Forgot your insurance number?</div>
        <p className="mt-1">Re-authenticate using any of your three identifiers — we'll match all of them for security:</p>
        <ul className="mt-1.5 list-disc pl-5 text-xs text-sky-700/90">
          <li>Phone Number</li>
          <li>First Name</li>
          <li>Last Name</li>
        </ul>
      </div>

      <form onSubmit={submit} className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Phone Number">
            <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} required placeholder="(555) 000-0000" />
          </Field>
          <Field label="First Name">
            <Input value={form.first_name} onChange={(e) => set("first_name", e.target.value)} required placeholder="Jane" />
          </Field>
          <Field label="Last Name">
            <Input value={form.last_name} onChange={(e) => set("last_name", e.target.value)} required placeholder="Doe" />
          </Field>
        </div>
        <Button type="submit" variant="secondary" disabled={searching} className="gap-1.5">
          {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Find My Insurance
        </Button>
      </form>

      {notFound && (
        <div className="flex items-start gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <AlertCircle className="mt-0.5 h-4 w-4" />
          <span>No matching patient record found. Please confirm your details or contact us at (555) 200-1000.</span>
        </div>
      )}

      {result && (
        <div className="rounded-xl border border-border bg-card p-5 shadow-card">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 ring-1 ring-emerald-100">
              <BadgeCheck className="h-5 w-5" />
            </div>
            <div>
              <div className="font-display text-sm font-bold text-foreground">{result.full_name}</div>
              <div className="text-xs text-muted-foreground">Existing patient · record verified</div>
            </div>
            <div className="ml-auto"><StatusBadge status={result.insurance_status} /></div>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <InfoRow icon={IdCard} label="Insurance Provider" value={result.insurance_provider || "—"} />
            <InfoRow icon={IdCard} label="Member ID" value={result.insurance_member_id || "—"} mono />
          </div>

          {result.insurance_status !== "verified" && (
            <div className="mt-4 flex items-start gap-2 rounded-lg bg-amber-50 px-3 py-2 text-xs text-amber-800">
              <AlertCircle className="mt-0.5 h-3.5 w-3.5" />
              Your insurance is pending verification. Our team will confirm coverage before your visit.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold">{label}</Label>
      {children}
    </div>
  );
}

function InfoRow({ icon: Icon, label, value, mono }) {
  return (
    <div className="rounded-lg border border-border bg-background/50 px-3 py-2.5">
      <div className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className={`mt-0.5 text-sm font-semibold text-foreground ${mono ? "font-mono tracking-wide" : ""}`}>{value}</div>
    </div>
  );
}