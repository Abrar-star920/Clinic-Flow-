import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Send, ShieldCheck, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";
import MessageThread from "@/components/messaging/MessageThread";

export default function PortalMessages() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [dob, setDob] = useState("");
  const [verified, setVerified] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);

  async function verify(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke("portalFetchMessages", { email, dob });
      if (data?.error) throw new Error(data.error);
      setVerified({ patient: data.patient, messages: data.messages });
    } catch (err) {
      toast({ variant: "destructive", title: "Could not open messages", description: err?.message });
    } finally {
      setLoading(false);
    }
  }

  async function send(body) {
    setSending(true);
    try {
      const { data } = await base44.functions.invoke("portalSendMessage", { email, dob, body });
      if (data?.error) throw new Error(data.error);
      setVerified((v) => ({ ...v, messages: [...(v?.messages || []), data.message] }));
      toast({ title: "Message sent" });
    } catch (err) {
      toast({ variant: "destructive", title: "Could not send", description: err?.message });
    } finally {
      setSending(false);
    }
  }

  if (!verified) {
    return (
      <form onSubmit={verify} className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
          <ShieldCheck className="h-4 w-4 text-primary" /> Verify your identity
        </div>
        <p className="text-xs text-muted-foreground">Enter your email and date of birth to open your secure message thread with the clinic.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Email *</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Date of Birth *</Label>
            <Input type="date" value={dob} onChange={(e) => setDob(e.target.value)} required />
          </div>
        </div>
        <Button type="submit" disabled={loading} className="w-full gap-1.5">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />}
          Open Messages
        </Button>
      </form>
    );
  }

  return (
    <div className="h-[460px] overflow-hidden rounded-xl border border-border bg-card shadow-sm">
      <div className="border-b border-border bg-muted/40 px-4 py-2 text-xs font-semibold text-muted-foreground">
        Secure thread · {verified.patient.full_name}
      </div>
      <MessageThread messages={verified.messages} onSend={send} sending={sending} placeholder="Write a message to the clinic…" />
    </div>
  );
}