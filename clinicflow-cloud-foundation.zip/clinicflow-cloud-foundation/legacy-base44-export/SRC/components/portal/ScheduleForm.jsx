import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { CalendarPlus, Loader2, CheckCircle2, CalendarClock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";

const PROVIDERS = ["Dr. A. Reyes", "Dr. M. Chen", "Dr. S. Patel", "NP L. Okafor"];
const TYPES = [
  { value: "new_patient", label: "New Patient" },
  { value: "follow_up", label: "Follow-up" },
  { value: "procedure", label: "Procedure" },
  { value: "telehealth", label: "Telehealth" },
  { value: "lab_work", label: "Lab Work" },
];

export default function ScheduleForm() {
  const { toast } = useToast();
  const [form, setForm] = useState({
    patient_name: "", phone: "", email: "",
    appointment_date: "", appointment_time: "09:00",
    provider: "Dr. A. Reyes", type: "follow_up", reason_for_visit: "",
  });
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState(null);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    setSubmitting(true);
    setConfirmed(null);
    try {
      const { data } = await base44.functions.invoke("publicScheduleAppointment", form);
      if (data?.error) throw new Error(data.error);
      setConfirmed(data.appointment);
      toast({ title: "Appointment requested", description: "We'll confirm via phone or email." });
    } catch (err) {
      toast({ variant: "destructive", title: "Could not book", description: err?.message });
    } finally {
      setSubmitting(false);
    }
  }

  if (confirmed) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-emerald-200 bg-emerald-50/60 px-6 py-12 text-center">
        <CheckCircle2 className="h-10 w-10 text-emerald-500" />
        <h3 className="mt-3 font-display text-lg font-bold text-foreground">Appointment requested!</h3>
        <p className="mt-1 text-sm text-muted-foreground">{confirmed.patient_name}, your visit is pending confirmation.</p>
        <div className="mt-4 rounded-lg border border-border bg-card px-5 py-3 text-sm shadow-sm">
          <div className="flex items-center gap-2 font-semibold text-foreground">
            <CalendarClock className="h-4 w-4 text-primary" />
            {confirmed.appointment_date} at {confirmed.appointment_time}
          </div>
          <div className="mt-1 text-muted-foreground">{confirmed.provider} · {confirmed.type?.replace(/_/g, " ")}</div>
        </div>
        <Button variant="outline" size="sm" className="mt-5" onClick={() => setConfirmed(null)}>
          Book another
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Full Name *">
          <Input value={form.patient_name} onChange={(e) => set("patient_name", e.target.value)} required placeholder="Jane Doe" />
        </Field>
        <Field label="Phone">
          <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="(555) 000-0000" />
        </Field>
        <Field label="Email">
          <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="jane@email.com" />
        </Field>
        <Field label="Provider">
          <Select value={form.provider} onValueChange={(v) => set("provider", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{PROVIDERS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
          </Select>
        </Field>
        <Field label="Preferred Date *">
          <Input type="date" value={form.appointment_date} onChange={(e) => set("appointment_date", e.target.value)} required />
        </Field>
        <Field label="Preferred Time *">
          <Input type="time" value={form.appointment_time} onChange={(e) => set("appointment_time", e.target.value)} required />
        </Field>
        <Field label="Visit Type">
          <Select value={form.type} onValueChange={(v) => set("type", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
          </Select>
        </Field>
        <Field label="Reason for Visit">
          <Input value={form.reason_for_visit} onChange={(e) => set("reason_for_visit", e.target.value)} placeholder="Annual check-up" />
        </Field>
      </div>
      <Button type="submit" disabled={submitting} className="w-full gap-1.5">
        {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CalendarPlus className="h-4 w-4" />}
        {submitting ? "Requesting…" : "Request Appointment"}
      </Button>
    </form>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-semibold">{label}</Label>
      {children}
    </div>
  );
}