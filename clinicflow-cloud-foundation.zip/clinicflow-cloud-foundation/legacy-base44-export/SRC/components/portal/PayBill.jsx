import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { CreditCard, Loader2, Search, CheckCircle2, Receipt } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/components/ui/use-toast";

export default function PayBill() {
  const { toast } = useToast();
  const [invoice_number, setInvoiceNumber] = useState("");
  const [last_name, setLastName] = useState("");
  const [searching, setSearching] = useState(false);
  const [invoice, setInvoice] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const [paying, setPaying] = useState(false);

  async function lookup(e) {
    e.preventDefault();
    setSearching(true);
    setInvoice(null);
    setNotFound(false);
    try {
      const { data } = await base44.functions.invoke("publicInvoiceLookup", { invoice_number, last_name });
      if (data?.error) throw new Error(data.error);
      if (data?.found) setInvoice(data);
      else setNotFound(true);
    } catch (err) {
      toast({ variant: "destructive", title: "Lookup failed", description: err?.message });
    } finally {
      setSearching(false);
    }
  }

  async function pay() {
    if (window.self !== window.top) {
      toast({ variant: "destructive", title: "Open in published app", description: "Payment works only from the published app, not the preview." });
      return;
    }
    setPaying(true);
    try {
      const { data } = await base44.functions.invoke("createStripeCheckoutSession", {
        claim_id: invoice.id,
        return_path: "/portal",
      });
      if (data?.url) window.location.href = data.url;
    } catch (err) {
      toast({ variant: "destructive", title: "Checkout failed", description: err?.response?.data?.error || err?.message });
    } finally {
      setPaying(false);
    }
  }

  const money = (n) => `$${Number(n || 0).toFixed(2)}`;

  return (
    <div className="space-y-5">
      <form onSubmit={lookup} className="space-y-4 rounded-xl border border-border bg-card p-5 shadow-sm">
        <p className="text-sm text-muted-foreground">Enter your invoice number and last name to find and pay your bill.</p>
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Invoice Number</Label>
            <Input value={invoice_number} onChange={(e) => setInvoiceNumber(e.target.value)} required placeholder="INV-00123" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-semibold">Last Name</Label>
            <Input value={last_name} onChange={(e) => setLastName(e.target.value)} required placeholder="Doe" />
          </div>
        </div>
        <Button type="submit" variant="secondary" disabled={searching} className="gap-1.5">
          {searching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Find Invoice
        </Button>
      </form>

      {notFound && (
        <div className="rounded-xl border border-dashed border-border bg-card/50 px-6 py-8 text-center text-sm text-muted-foreground">
          No invoice found. Double-check your invoice number and last name, or call us at (555) 200-1000.
        </div>
      )}

      {invoice && (
        <div className="rounded-xl border border-border bg-card p-5 shadow-card">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Receipt className="h-4 w-4 text-primary" />
              <span className="font-display text-sm font-bold text-foreground">{invoice.invoice_number || "Invoice"}</span>
              <StatusBadge status={invoice.status} />
            </div>
            <div className="font-display text-xl font-bold text-foreground">{money(invoice.amount)}</div>
          </div>
          <div className="mt-2 text-sm text-muted-foreground">{invoice.patient_name}</div>
          {invoice.description && <div className="mt-0.5 text-sm text-muted-foreground">{invoice.description}</div>}
          {invoice.due_date && <div className="mt-0.5 text-xs text-muted-foreground">Due {invoice.due_date}</div>}
          {invoice.status === "paid" ? (
            <div className="mt-4 flex items-center gap-1.5 rounded-lg bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-700">
              <CheckCircle2 className="h-4 w-4" /> This invoice is already paid. Thank you!
            </div>
          ) : (
            <Button className="mt-4 w-full gap-1.5" disabled={paying} onClick={pay}>
              {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <CreditCard className="h-4 w-4" />}
              {paying ? "Redirecting…" : `Pay ${money(invoice.amount)}`}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}