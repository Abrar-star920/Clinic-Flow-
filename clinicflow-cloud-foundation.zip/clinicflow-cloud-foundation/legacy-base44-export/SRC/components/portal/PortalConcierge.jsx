import React from "react";
import ConciergeChat from "@/components/concierge/ConciergeChat";
import { Bot } from "lucide-react";

export default function PortalConcierge({ patientContext = {} }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5 rounded-xl border border-sky-100 bg-sky-50/60 px-4 py-3 text-sm text-sky-800">
        <Bot className="h-4 w-4 shrink-0" />
        Chat with our AI receptionist — it can help you schedule, answer insurance and billing questions, and guide you to the right care.
      </div>
      <ConciergeChat variant="embedded" patientContext={patientContext} />
    </div>
  );
}