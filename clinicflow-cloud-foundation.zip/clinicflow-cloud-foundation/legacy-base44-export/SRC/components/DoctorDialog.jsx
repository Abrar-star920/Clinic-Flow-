import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import PhotoUpload from "@/components/PhotoUpload";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Loader2 } from "lucide-react";

const EMPTY = { full_name: "", specialty: "", email: "", phone: "", bio: "", photo_url: "" };

export default function DoctorDialog({ open, onOpenChange, onSaved, doctor }) {
  const [form, setForm] = useState(EMPTY);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setForm(doctor ? { ...EMPTY, ...doctor } : EMPTY);
      setError("");
    }
  }, [open, doctor]);

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!form.full_name.trim()) {
      setError("Full name is required.");
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        full_name: form.full_name.trim(),
        specialty: form.specialty || undefined,
        email: form.email || undefined,
        phone: form.phone || undefined,
        bio: form.bio || undefined,
        photo_url: form.photo_url || undefined,
      };
      const saved = doctor
        ? await base44.entities.Doctor.update(doctor.id, payload)
        : await base44.entities.Doctor.create(payload);
      onSaved?.(saved);
      onOpenChange(false);
    } catch (err) {
      setError("Could not save the doctor. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!submitting) onOpenChange(v); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{doctor ? "Edit Doctor" : "Add Doctor"}</DialogTitle>
          <DialogDescription>
            {doctor ? "Update the provider profile and photo." : "Create a provider profile with an optional photo."}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <PhotoUpload value={form.photo_url} onChange={(url) => setForm({ ...form, photo_url: url })} name={form.full_name} />

          <div className="space-y-1.5">
            <Label htmlFor="d_name">Full Name *</Label>
            <Input id="d_name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} placeholder="Dr. A. Reyes" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="d_specialty">Specialty</Label>
              <Input id="d_specialty" value={form.specialty} onChange={(e) => setForm({ ...form, specialty: e.target.value })} placeholder="Cardiology" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="d_phone">Phone</Label>
              <Input id="d_phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="(555) 200-1000" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="d_email">Email</Label>
            <Input id="d_email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="reyes@clinic.com" />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="d_bio">Bio</Label>
            <Textarea id="d_bio" rows={2} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="Brief bio…" />
          </div>

          {error && <p className="text-sm font-medium text-destructive">{error}</p>}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={submitting}>Cancel</Button>
            <Button type="submit" disabled={submitting} className="gap-1.5">
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</> : "Save Doctor"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}