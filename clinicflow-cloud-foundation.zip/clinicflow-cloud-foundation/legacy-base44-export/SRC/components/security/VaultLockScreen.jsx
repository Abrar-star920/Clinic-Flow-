import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Lock, ShieldAlert } from "lucide-react";
import { ClinicFlowLogo } from "@/components/branding/ClinicFlowMark";

// Automatic lockdown screen: shown across the entire app when intrusion
// attempts exceed the threshold. All patient data is sealed behind this vault
// screen — only the vendor's security key reopens it.
export default function VaultLockScreen({ status, onUnlocked }) {
  const [securityKey, setSecurityKey] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const triggeredAt = status.triggered_at
    ? new Date(status.triggered_at).toLocaleString()
    : null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.functions.invoke("securityGate", {
        action: "unlock",
        security_key: securityKey,
      });
      await onUnlocked();
    } catch (err) {
      setError(err?.response?.data?.error || err.message || "Invalid security key");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-brand px-6 py-12">
      <div className="w-full max-w-md rounded-2xl bg-card p-8 shadow-elevated">
        <div className="mb-6 flex items-center justify-between">
          <ClinicFlowLogo size={34} />
          <span className="status-badge bg-destructive/10 text-destructive ring-1 ring-destructive/20">
            <ShieldAlert className="h-3.5 w-3.5" /> Lockdown active
          </span>
        </div>

        <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10">
          <Lock className="h-7 w-7 text-destructive" />
        </div>

        <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">
          Data vault locked
        </h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          Repeated unauthorized access attempts were detected. All patient data
          and application functions are sealed. Enter the vendor security key to
          unlock the vault.
        </p>

        <div className="mt-4 rounded-lg border border-destructive/20 bg-destructive/5 p-3 text-xs text-muted-foreground">
          {status.trigger_reason && (
            <p className="font-medium text-foreground">Reason: {status.trigger_reason}</p>
          )}
          {triggeredAt && <p className="mt-1">Locked since: {triggeredAt}</p>}
        </div>

        {error && (
          <div className="mt-4 rounded-lg bg-destructive/10 p-3 text-sm font-medium text-destructive">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="vault_key">Vendor security key</Label>
            <Input
              id="vault_key"
              type="password"
              autoFocus
              placeholder="Security key"
              value={securityKey}
              onChange={(e) => setSecurityKey(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (<><Loader2 className="h-4 w-4 animate-spin" /> Unlocking…</>) : "Unlock data vault"}
          </Button>
        </form>
      </div>
    </div>
  );
}