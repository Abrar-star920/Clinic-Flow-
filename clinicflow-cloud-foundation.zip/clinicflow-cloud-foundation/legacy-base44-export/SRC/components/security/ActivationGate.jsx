import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KeyRound, Loader2, ShieldCheck } from "lucide-react";
import { ClinicFlowLogo } from "@/components/branding/ClinicFlowMark";

// First-launch license activation: the vendor unlocks the app with the
// security key issued after purchase. Until then, nothing in the app is usable.
export default function ActivationGate({ onActivated }) {
  const [securityKey, setSecurityKey] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await base44.functions.invoke("securityGate", {
        action: "activate",
        security_key: securityKey,
        customer_name: customerName,
        customer_email: customerEmail,
      });
      await onActivated();
    } catch (err) {
      setError(err?.response?.data?.error || err.message || "Invalid security key");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-brand px-6 py-12">
      <div className="w-full max-w-md rounded-2xl bg-card p-8 shadow-elevated">
        <div className="mb-6 flex items-center justify-between">
          <ClinicFlowLogo size={34} />
          <span className="status-badge bg-accent text-accent-foreground">
            <ShieldCheck className="h-3.5 w-3.5" /> HIPAA-aware security
          </span>
        </div>

        <h1 className="font-display text-2xl font-bold tracking-tight text-foreground">
          Activate your license
        </h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          This application is licensed software. Enter the security key provided
          after purchase to unlock it for your organization.
        </p>

        {error && (
          <div className="mt-4 rounded-lg bg-destructive/10 p-3 text-sm font-medium text-destructive">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="security_key">Security key</Label>
            <div className="relative">
              <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
              <Input
                id="security_key"
                type="password"
                autoFocus
                placeholder="Provided after purchase"
                value={securityKey}
                onChange={(e) => setSecurityKey(e.target.value)}
                className="pl-10"
                required
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="customer_name">Organization name</Label>
            <Input
              id="customer_name"
              placeholder="Your clinic or company"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="customer_email">Contact email</Label>
            <Input
              id="customer_email"
              type="email"
              placeholder="admin@clinic.com"
              value={customerEmail}
              onChange={(e) => setCustomerEmail(e.target.value)}
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? (<><Loader2 className="h-4 w-4 animate-spin" /> Activating…</>) : "Activate application"}
          </Button>
        </form>
      </div>
    </div>
  );
}