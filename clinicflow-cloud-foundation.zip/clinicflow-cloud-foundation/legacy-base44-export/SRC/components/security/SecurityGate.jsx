import React from "react";
import useSecurityGate from "@/hooks/useSecurityGate";
import ActivationGate from "@/components/security/ActivationGate";
import VaultLockScreen from "@/components/security/VaultLockScreen";

// Wraps the entire app. Three states:
// - license not activated → vendor must enter the purchased security key first
// - vault lockdown active  → whole app is sealed; only the security key unlocks it
// - otherwise             → normal app usage
export default function SecurityGate({ children }) {
  const { status, loading, refresh } = useSecurityGate();

  if (loading || !status) return <>{children}</>;

  if (status.activation_status === "pending") {
    return <ActivationGate onActivated={refresh} />;
  }
  if (status.lockdown_active) {
    return <VaultLockScreen status={status} onUnlocked={refresh} />;
  }
  return <>{children}</>;
}