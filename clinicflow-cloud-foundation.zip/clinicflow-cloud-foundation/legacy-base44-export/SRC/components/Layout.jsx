import React, { useState } from "react";
import { Outlet, NavLink, useLocation, Link } from "react-router-dom";
import {
  Users, CalendarClock, PhoneCall, AlertTriangle, Stethoscope, UserRound,
  BarChart3, ScrollText, CreditCard, HeartPulse, Headset, Activity, MessagesSquare, ListChecks, LineChart,
  Menu, X, Search, Bell, ChevronDown, LogOut, ShieldCheck, LayoutDashboard, Building2,
} from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { cn } from "@/lib/utils";
import ClinicFlowMark from "@/components/branding/ClinicFlowMark";

const NAV = [
  // Overview
  { to: "/app", label: "Dashboard", icon: LayoutDashboard, group: "Overview", end: true, roles: ["admin", "doctor", "nurse", "receptionist", "billing"] },
  // Attract patients
  { to: "/scheduling", label: "Scheduling", icon: CalendarClock, group: "Attract patients", roles: ["admin", "doctor", "nurse", "receptionist"] },
  // Deliver care
  { to: "/patients", label: "Patient Records", icon: Users, group: "Deliver care", end: true, roles: ["admin", "doctor", "nurse", "receptionist", "billing"] },
  { to: "/procedures", label: "Procedures", icon: Stethoscope, group: "Deliver care", roles: ["admin", "doctor", "nurse"] },
  { to: "/rpm", label: "RPM Monitor", icon: HeartPulse, group: "Deliver care", roles: ["admin", "doctor", "nurse"] },
  { to: "/doctors", label: "Providers", icon: UserRound, group: "Deliver care", roles: ["admin", "doctor", "nurse", "receptionist"] },
  // Run the clinic
  { to: "/tasks", label: "Work Queue", icon: ListChecks, group: "Run the clinic", roles: ["admin", "doctor", "nurse", "receptionist"] },
  { to: "/call-log", label: "Call Log", icon: PhoneCall, group: "Run the clinic", roles: ["admin", "receptionist"] },
  { to: "/escalations", label: "Escalations", icon: AlertTriangle, group: "Run the clinic", roles: ["admin", "doctor", "nurse", "receptionist"] },
  { to: "/call-concierge", label: "AI Concierge", icon: Headset, group: "Run the clinic", roles: ["admin", "doctor", "nurse", "receptionist"] },
  { to: "/messages", label: "Messages", icon: MessagesSquare, group: "Run the clinic", roles: ["admin", "doctor", "nurse", "receptionist"] },
  // Finance
  { to: "/billing", label: "Billing", icon: CreditCard, group: "Finance", roles: ["admin", "billing"] },
  { to: "/insurance-assistant", label: "Insurance Assistant", icon: ShieldCheck, group: "Finance", roles: ["admin", "billing"] },
  { to: "/payers", label: "Payers", icon: Building2, group: "Finance", roles: ["admin", "billing"] },
  // Insights
  { to: "/analytics", label: "Analytics", icon: BarChart3, group: "Insights", roles: ["admin", "doctor", "billing"] },
  { to: "/booking-trends", label: "Booking Trends", icon: LineChart, group: "Insights", roles: ["admin", "doctor", "billing"] },
  // Admin
  { to: "/activity-log", label: "Audit Log", icon: ScrollText, group: "Admin", roles: ["admin"] },
];

const GROUP_ORDER = ["Overview", "Attract patients", "Deliver care", "Run the clinic", "Finance", "Insights", "Admin"];

const ROLE_LABELS = {
  admin: "Administrator", doctor: "Doctor", nurse: "Nurse",
  receptionist: "Receptionist", billing: "Billing", patient: "Patient",
};

function initials(name = "") {
  const parts = name.trim().split(/\s+/);
  return (parts[0]?.[0] || "") + (parts[1]?.[0] || parts[0]?.[1] || "");
}

export default function Layout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  const role = user?.role || "patient";
  const visible = NAV.filter((n) => n.roles.includes(role));
  const active = visible.find((n) => (n.end ? location.pathname === n.to : location.pathname.startsWith(n.to) && n.to !== "/")) || visible[0];

  const Sidebar = (
    <aside className="flex h-full w-64 flex-col border-r border-sidebar-border bg-sidebar">
      <div className="flex items-center gap-2.5 px-5 py-5">
        <ClinicFlowMark size={36} />
        <div className="leading-tight">
          <div className="font-display text-[15px] font-extrabold uppercase tracking-[0.06em] text-brand">Clinic Flow</div>
          <div className="text-[11px] font-medium text-muted-foreground">Practice Management</div>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-2">
        {GROUP_ORDER.map((group) => {
          const items = visible.filter((n) => n.group === group);
          if (!items.length) return null;
          return (
            <div key={group} className="mb-3">
              <div className="px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground/70">{group}</div>
              <div className="space-y-0.5">
                {items.map(({ to, label, icon: Icon, end }) => (
                  <NavLink
                    key={to}
                    to={to}
                    end={end}
                    onClick={() => setMobileOpen(false)}
                    className={({ isActive }) =>
                      cn(
                        "group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                        isActive
                          ? "bg-accent text-accent-foreground"
                          : "text-sidebar-foreground/75 hover:bg-secondary hover:text-foreground"
                      )
                    }
                  >
                    {({ isActive }) => (
                      <>
                        <Icon className={cn("h-[18px] w-[18px] shrink-0", isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                        {label}
                      </>
                    )}
                  </NavLink>
                ))}
              </div>
            </div>
          );
        })}
      </nav>

      <div className="border-t border-sidebar-border px-3 py-3">
        <div className="flex items-center gap-3 rounded-lg px-2 py-1.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
            {initials(user?.full_name || "Staff")}
          </div>
          <div className="min-w-0 leading-tight">
            <div className="truncate text-[13px] font-semibold text-foreground">{user?.full_name || "Staff"}</div>
            <div className="text-[11px] text-muted-foreground">{ROLE_LABELS[role] || role} session</div>
          </div>
        </div>
      </div>
    </aside>
  );

  function onLogout() {
    logout(true);
  }

  return (
    <div className="flex h-screen overflow-hidden bg-surface">
      <div className="hidden md:block">{Sidebar}</div>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 h-full shadow-elevated">{Sidebar}</div>
        </div>
      )}

      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center justify-between gap-4 border-b border-border bg-card px-4 py-3 md:px-8">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(true)} className="rounded-lg p-1.5 text-foreground hover:bg-muted md:hidden">
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-sm">
              <span className="hidden text-muted-foreground sm:inline">ClinicFlow</span>
              <span className="hidden text-muted-foreground/40 sm:inline">/</span>
              <span className="font-display font-bold tracking-tight text-foreground">{active?.label || "Dashboard"}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-lg border border-input bg-surface px-3 py-1.5 text-sm text-muted-foreground lg:flex lg:w-64">
              <Search className="h-4 w-4" />
              <input placeholder="Search patients…" className="w-full bg-transparent text-foreground outline-none placeholder:text-muted-foreground" />
            </div>
            <button className="relative rounded-lg border border-border bg-card p-2 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground">
              <Bell className="h-4 w-4" />
              <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-primary" />
            </button>

            <div className="relative">
              <button
                onClick={() => setMenuOpen((v) => !v)}
                className="flex items-center gap-2 rounded-lg border border-border bg-card px-2 py-1.5 text-sm transition-colors hover:bg-muted"
              >
                <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-[11px] font-bold text-primary-foreground">
                  {initials(user?.full_name || "Staff")}
                </div>
                <span className="hidden font-medium text-foreground sm:inline">{user?.full_name?.split(" ")[0] || "Staff"}</span>
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </button>
              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
                  <div className="absolute right-0 z-50 mt-2 w-56 overflow-hidden rounded-xl border border-border bg-card shadow-elevated">
                    <div className="border-b border-border px-4 py-3">
                      <div className="text-sm font-semibold text-foreground">{user?.full_name || "Staff"}</div>
                      <div className="text-xs text-muted-foreground">{user?.email || ""}</div>
                      <div className="mt-1.5 inline-flex items-center gap-1 rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold uppercase text-accent-foreground">
                        <ShieldCheck className="h-3 w-3" /> {ROLE_LABELS[role] || role}
                      </div>
                    </div>
                    <button onClick={onLogout} className="flex w-full items-center gap-2 px-4 py-2.5 text-sm text-destructive hover:bg-destructive/5">
                      <LogOut className="h-4 w-4" /> Sign out
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        <main key={location.pathname} className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}