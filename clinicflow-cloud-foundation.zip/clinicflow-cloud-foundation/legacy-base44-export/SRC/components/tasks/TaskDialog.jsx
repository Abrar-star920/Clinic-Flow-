import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";

const TYPES = [
  { value: "follow_up", label: "Follow-up" },
  { value: "authorization_issue", label: "Authorization Issue" },
  { value: "clinical_message", label: "Clinical Message" },
  { value: "records_request", label: "Records Request" },
  { value: "prescription_refill", label: "Prescription Refill" },
  { value: "callback", label: "Callback" },
  { value: "other", label: "Other" },
];
const PRIORITIES = [
  { value: "low", label: "Low" },
  { value: "medium", label: "Medium" },
  { value: "high", label: "High" },
  { value: "urgent", label: "Urgent" },
];

export default function TaskDialog({ open, onOpenChange, onSaved, patients = [], staff = [], task = null }) {
  const [form, setForm] = useState({
    title: "", description: "", task_type: "follow_up", priority: "medium",
    due_date: "", assigned_to: "", patient_name: "", source: "manual",
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (task) {
      setForm({
        title: task.title || "", description: task.description || "", task_type: task.task_type || "follow_up",
        priority: task.priority || "medium", due_date: task.due_date || "", assigned_to: task.assigned_to || "",
        patient_name: task.patient_name || "", source: task.source || "manual",
      });
    } else {
      setForm({
        title: "", description: "", task_type: "follow_up", priority: "medium",
        due_date: "", assigned_to: "", patient_name: "", source: "manual",
      });
    }
  }, [task, open]);

  async function save() {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      const selected = patients.find((p) => p.full_name === form.patient_name);
      const payload = {
        ...form,
        patient_id: selected?.id || null,
        patient_name: form.patient_name || selected?.full_name || "",
        patient_email: selected?.email || "",
      };
      await onSaved?.(task ? { id: task.id, ...payload } : payload);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{task ? "Edit Task" : "New Task"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>Task</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Call patient about lab results" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={form.task_type} onValueChange={(v) => setForm({ ...form, task_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Priority</Label>
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{PRIORITIES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Patient (optional)</Label>
            <Input list="task-patients" value={form.patient_name} onChange={(e) => setForm({ ...form, patient_name: e.target.value })} placeholder="Type or select a patient" />
            <datalist id="task-patients">{patients.map((p) => <option key={p.id} value={p.full_name} />)}</datalist>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Assign to</Label>
              <Input list="task-staff" value={form.assigned_to} onChange={(e) => setForm({ ...form, assigned_to: e.target.value })} placeholder="Unassigned" />
              <datalist id="task-staff">{staff.map((s) => <option key={s} value={s} />)}</datalist>
            </div>
            <div className="space-y-1.5">
              <Label>Due date</Label>
              <Input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Description</Label>
            <Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={save} disabled={saving || !form.title.trim()}>{saving ? "Saving…" : "Save"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}