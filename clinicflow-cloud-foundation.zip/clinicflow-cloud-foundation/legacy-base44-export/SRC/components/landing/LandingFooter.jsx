import React from "react";
import { Link } from "react-router-dom";
import { ClinicFlowLogo } from "@/components/branding/ClinicFlowMark";

export default function LandingFooter() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-8 sm:flex-row sm:px-8">
        <Link to="/" className="flex items-center">
          <ClinicFlowLogo size={32} />
        </Link>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} ClinicFlow. Built for front-desk teams.</p>
        <div className="flex items-center gap-5 text-xs font-medium text-muted-foreground">
          <Link to="/staff-login" className="hover:text-foreground">Staff Login</Link>
          <Link to="/portal" className="hover:text-foreground">Patient Portal</Link>
          <a href="#contact" className="hover:text-foreground">Contact</a>
        </div>
      </div>
    </footer>
  );
}