import React from "react";
import HeroVisual from "./HeroVisual";
import HeroVideo from "./HeroVideo";
import { ArrowRight, Play } from "lucide-react";

export default function LandingHero() {
  return (
    <section className="relative overflow-hidden border-b border-border bg-gradient-to-b from-accent/40 to-background">
      <div className="pointer-events-none absolute -right-32 top-0 h-96 w-96 rounded-full bg-primary/5 blur-3xl" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-6 py-20 sm:px-8 lg:grid-cols-2 lg:py-28">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary">
            Front-Desk Platform for Clinics
          </span>
          <h1 className="mt-5 font-display text-4xl font-extrabold leading-[1.1] tracking-tight text-foreground sm:text-5xl lg:text-[3.5rem]">
            Less admin. More care. One front desk that runs itself.
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground">
            ClinicFlow unifies patient intake, insurance verification, scheduling, billing, and call triage into one calm, connected workspace — so your staff focuses on patients, not paperwork.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <a href="#contact" className="inline-flex items-center gap-2 rounded-lg bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-sm transition-colors hover:bg-primary/90">
              Get a Demo <ArrowRight className="h-4 w-4" />
            </a>
            <a href="#how" className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-accent">
              <Play className="h-4 w-4 text-primary" /> See how it works
            </a>
          </div>
        </div>
        <div className="lg:pl-8">
          <HeroVisual />
        </div>
      </div>

      <div className="relative mx-auto max-w-7xl px-6 sm:px-8">
        <HeroVideo />
      </div>
    </section>
  );
}