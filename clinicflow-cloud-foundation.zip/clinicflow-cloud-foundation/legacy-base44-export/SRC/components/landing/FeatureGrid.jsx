import React from "react";
import { Users, ShieldCheck, CalendarClock, Headset, CreditCard, HeartPulse } from "lucide-react";

const FEATURES = [
  { icon: Users, title: "Unified Patient Intake", body: "One front-desk view across every EHR, provider, and location." },
  { icon: ShieldCheck, title: "Insurance Verification", body: "Real-time coverage checks flag gaps before the visit, not at check-in." },
  { icon: CalendarClock, title: "Smart Scheduling", body: "Provider-by-slot calendar with automated reminders and no-show recovery." },
  { icon: Headset, title: "AI Concierge", body: "24/7 call triage, appointment booking, and answers for your patients." },
  { icon: CreditCard, title: "Billing & RCM", body: "Claims tracking and patient payments, end to end, in one place." },
  { icon: HeartPulse, title: "Remote Monitoring", body: "Remote vitals with proactive alerts for at-risk patients." },
];

export default function FeatureGrid() {
  return (
    <section id="features" className="bg-background py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <div className="max-w-2xl">
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-primary">Features</div>
          <h2 className="mt-3 font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Everything your front desk needs</h2>
          <p className="mt-4 text-base text-muted-foreground">A single, calm workspace for intake, scheduling, billing, and patient communication.</p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="rounded-2xl border border-border bg-card p-6 transition-all hover:-translate-y-0.5 hover:shadow-card">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-primary ring-1 ring-primary/10">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-5 font-display text-lg font-bold tracking-tight text-foreground">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}