import React from "react";

const STATS = [
  { value: "40%", label: "Faster patient intake" },
  { value: "3×", label: "Fewer call escalations" },
  { value: "100%", label: "Insurance status visibility" },
  { value: "24/7", label: "AI concierge coverage" },
];

export default function StatsBand() {
  return (
    <section className="border-b border-border bg-card">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px px-6 sm:px-8 lg:grid-cols-4">
        {STATS.map((s) => (
          <div key={s.label} className="py-9 text-center">
            <div className="font-display text-4xl font-extrabold tracking-tight text-primary">{s.value}</div>
            <div className="mt-1.5 text-sm font-medium text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}