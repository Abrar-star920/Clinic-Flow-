import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle2, Loader2, ShieldCheck } from "lucide-react";

const EMPTY = { first_name: "", last_name: "", clinic_name: "", job_title: "", email: "", phone: "" };

export default function DemoForm() {
  const [form, setForm] = useState(EMPTY);
  const [status, setStatus] = useState("idle"); // idle | loading | success | error
  const [error, setError] = useState("");

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function onSubmit(e) {
    e.preventDefault();
    setStatus("loading");
    setError("");
    try {
      const res = await base44.functions.invoke("requestDemo", form);
      if (res?.data?.success) {
        setStatus("success");
      } else {
        setError(res?.data?.error || "Something went wrong. Please try again.");
        setStatus("error");
      }
    } catch (err) {
      setError(err?.response?.data?.error || err?.message || "Submission failed.");
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className="flex flex-col items-center justify-center rounded-2xl bg-white p-8 text-center shadow-elevated">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-emerald-100">
          <CheckCircle2 className="h-8 w-8 text-emerald-600" />
        </div>
        <h3 className="mt-4 font-display text-xl font-bold text-foreground">Request received</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Thanks, {form.first_name}! Our team will reach out within one business day to schedule your personalized demo.
        </p>
        <button
          onClick={() => { setForm(EMPTY); setStatus("idle"); }}
          className="mt-5 text-sm font-semibold text-primary hover:underline"
        >
          Submit another request
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={onSubmit} className="rounded-2xl bg-white p-6 shadow-elevated sm:p-7">
      <div className="flex items-center gap-2">
        <h3 className="font-display text-xl font-bold tracking-tight text-foreground">Request a demo</h3>
        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-emerald-700 ring-1 ring-emerald-200">
          <ShieldCheck className="h-3 w-3" /> HIPAA-ready
        </span>
      </div>
      <p className="mt-1.5 text-sm text-muted-foreground">No commitment. We'll show you a 30-minute demo tailored to your front-desk workflow.</p>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <Field label="First Name" required value={form.first_name} onChange={update("first_name")} />
        <Field label="Last Name" required value={form.last_name} onChange={update("last_name")} />
        <Field label="Clinic Name" value={form.clinic_name} onChange={update("clinic_name")} />
        <Field label="Job Title" value={form.job_title} onChange={update("job_title")} />
        <Field label="Email Address" type="email" required value={form.email} onChange={update("email")} />
        <Field label="Phone Number" type="tel" value={form.phone} onChange={update("phone")} />
      </div>

      {error && <p className="mt-3 text-sm font-medium text-rose-600">{error}</p>}

      <Button type="submit" variant="default" className="mt-5 w-full" disabled={status === "loading"}>
        {status === "loading" ? (
          <><Loader2 className="h-4 w-4 animate-spin" /> Booking…</>
        ) : (
          "Book Now"
        )}
      </Button>
      <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">
        ClinicFlow uses your contact information solely to schedule your demo. You may opt out at any time.
      </p>
    </form>
  );
}

function Field({ label, value, onChange, type = "text", required = false }) {
  return (
    <div className="space-y-1">
      <Label className="text-xs font-semibold text-foreground">
        {label} {required && <span className="text-rose-500">*</span>}
      </Label>
      <Input type={type} value={value} onChange={onChange} required={required} className="h-9" />
    </div>
  );
}