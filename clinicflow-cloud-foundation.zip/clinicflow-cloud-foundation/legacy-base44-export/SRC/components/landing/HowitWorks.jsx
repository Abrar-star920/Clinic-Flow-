import React from "react";

const STEPS = [
  { n: "01", title: "Connect your systems", body: "ClinicFlow sits above your EHR, phone system, and billing — no rip-and-replace, no migration." },
  { n: "02", title: "Automate the front desk", body: "Intake, verification, scheduling, and call triage run together in one connected workflow." },
  { n: "03", title: "See everything in one place", body: "Staff get a single dashboard; patients get a self-service portal. Nothing slips." },
];

export default function HowItWorks() {
  return (
    <section id="how" className="border-y border-border bg-card py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <div className="max-w-2xl">
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-primary">How it works</div>
          <h2 className="mt-3 font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Live in days, not quarters</h2>
        </div>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {STEPS.map((s) => (
            <div key={s.n} className="relative">
              <div className="font-display text-sm font-bold text-primary/30">{s.n}</div>
              <h3 className="mt-3 font-display text-lg font-bold tracking-tight text-foreground">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}