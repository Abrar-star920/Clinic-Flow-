import React from "react";
import DemoForm from "./DemoForm";

export default function ContactSection() {
  return (
    <section id="contact" className="bg-background py-20 sm:py-24">
      <div className="mx-auto grid max-w-6xl gap-12 px-6 sm:px-8 lg:grid-cols-2 lg:items-center">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-primary">Get a demo</div>
          <h2 className="mt-3 font-display text-3xl font-bold tracking-tight text-foreground sm:text-4xl">See ClinicFlow on your workflow</h2>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            No commitment. We'll walk you through a 30-minute demo tailored to your clinic's front-desk operations — intake, verification, scheduling, and billing.
          </p>
          <ul className="mt-6 space-y-3 text-sm text-muted-foreground">
            <li>• Sits above your existing EHR and billing — replaces nothing.</li>
            <li>• Built for multi-site practices and independent clinics.</li>
            <li>• HIPAA-ready with role-based access and audit logging.</li>
          </ul>
        </div>
        <div className="lg:pl-6">
          <DemoForm />
        </div>
      </div>
    </section>
  );
}