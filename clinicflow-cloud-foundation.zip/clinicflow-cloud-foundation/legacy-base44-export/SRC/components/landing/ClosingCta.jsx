import React from "react";
import { ArrowRight } from "lucide-react";

export default function ClosingCta() {
  return (
    <section className="bg-primary py-16 sm:py-20">
      <div className="mx-auto max-w-4xl px-6 text-center sm:px-8">
        <h2 className="font-display text-3xl font-extrabold tracking-tight text-primary-foreground sm:text-4xl">
          See your front desk the way it should look.
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-base text-primary-foreground/80">
          One workspace. Every patient. Every system. Every participating provider.
        </p>
        <a href="#contact" className="mt-8 inline-flex items-center gap-2 rounded-lg bg-background px-6 py-3 text-sm font-semibold text-primary shadow-sm transition-colors hover:bg-background/90">
          Get a Demo <ArrowRight className="h-4 w-4" />
        </a>
      </div>
    </section>
  );
}