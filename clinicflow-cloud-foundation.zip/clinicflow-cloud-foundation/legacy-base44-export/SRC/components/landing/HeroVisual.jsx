import React from "react";
import { Activity, ShieldCheck, CalendarClock, HeartPulse } from "lucide-react";

const ROWS = [
  { t: "09:00", n: "M. Alvarez", s: "In room", c: "bg-primary" },
  { t: "09:30", n: "J. Chen", s: "Checked in", c: "bg-emerald-500" },
  { t: "10:00", n: "R. Patel", s: "Scheduled", c: "bg-sky-400" },
];

export default function HeroVisual() {
  return (
    <div className="relative">
      <div className="rounded-2xl border border-border bg-card p-5 shadow-elevated">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">Today's Front Desk</div>
            <div className="font-display text-lg font-bold text-foreground">Live overview</div>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 ring-1 ring-emerald-200">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> All systems go
          </span>
        </div>

        <div className="mt-4 grid grid-cols-3 gap-3">
          <Mini icon={CalendarClock} label="Checked in" value="18" accent="text-primary" />
          <Mini icon={ShieldCheck} label="Verified" value="92%" accent="text-emerald-600" />
          <Mini icon={HeartPulse} label="RPM alerts" value="3" accent="text-rose-600" />
        </div>

        <div className="mt-4 space-y-2.5">
          {ROWS.map((r) => (
            <div key={r.t} className="flex items-center gap-3 rounded-lg border border-border bg-background px-3 py-2.5">
              <div className="text-xs font-semibold text-muted-foreground tabular-nums">{r.t}</div>
              <div className="grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-[#1d4b73] to-[#005696] text-[10px] font-bold text-white">{r.n[0]}</div>
              <div className="flex-1 text-sm font-medium text-foreground">{r.n}</div>
              <span className={`h-2 w-2 rounded-full ${r.c}`} />
              <span className="text-[11px] text-muted-foreground">{r.s}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-lg border border-border bg-background p-3">
          <div className="flex items-center gap-2 text-[11px] font-semibold text-muted-foreground">
            <Activity className="h-3.5 w-3.5 text-primary" /> Patient vitals trend
          </div>
          <svg viewBox="0 0 300 60" className="mt-2 h-12 w-full" preserveAspectRatio="none">
            <polyline points="0,40 40,32 80,36 120,20 160,28 200,14 240,22 300,10" fill="none" stroke="hsl(var(--primary))" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            <polyline points="0,52 40,48 80,50 120,44 160,46 200,40 240,42 300,38" fill="none" stroke="hsl(var(--chart-2))" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6" />
          </svg>
        </div>
      </div>

      <div className="absolute -left-4 bottom-6 hidden rounded-xl border border-border bg-card px-4 py-3 shadow-elevated sm:block">
        <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Avg. intake time</div>
        <div className="font-display text-xl font-bold text-foreground">↓ 40%</div>
      </div>
    </div>
  );
}

function Mini({ icon: Icon, label, value, accent }) {
  return (
    <div className="rounded-xl border border-border bg-background p-3">
      <Icon className={`h-4 w-4 ${accent}`} />
      <div className="mt-2 font-display text-lg font-bold tabular-nums text-foreground">{value}</div>
      <div className="text-[10px] text-muted-foreground">{label}</div>
    </div>
  );
}