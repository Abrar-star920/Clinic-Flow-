import React, { useState, useEffect } from "react";
import { Play, X } from "lucide-react";

export default function HeroVideo() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Watch the ClinicFlow overview video"
        className="group relative mt-14 block w-full overflow-hidden rounded-2xl border border-border bg-card text-left shadow-card transition-all hover:shadow-elevated"
      >
        <div className="aspect-video w-full bg-gradient-to-br from-[#eef4f9] via-[#e7f3f4] to-[#dde9f3]">
          <div className="absolute inset-0 opacity-40">
            <div className="absolute left-0 top-1/2 h-px w-full bg-primary/20" />
            <div className="absolute left-1/4 top-0 h-full w-px bg-primary/10" />
            <div className="absolute right-1/4 top-0 h-full w-px bg-primary/10" />
          </div>
          <div className="absolute left-5 top-5 rounded-full border border-border bg-background/80 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground backdrop-blur">
            Video coming soon
          </div>
          <div className="absolute inset-0 grid place-items-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-card text-primary shadow-elevated ring-1 ring-border transition-transform group-hover:scale-105 sm:h-20 sm:w-20">
              <Play className="h-7 w-7 translate-x-0.5 sm:h-8 sm:w-8" />
            </span>
          </div>
        </div>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-4 backdrop-blur-sm"
          onClick={() => setOpen(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Video player"
        >
          <div className="relative w-full max-w-4xl" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close video"
              className="absolute -top-11 right-0 inline-flex items-center gap-1.5 rounded-lg bg-card px-3 py-2 text-sm font-medium text-foreground shadow-card hover:bg-accent"
            >
              <X className="h-4 w-4" /> Close
            </button>
            <div className="aspect-video w-full overflow-hidden rounded-2xl border border-border bg-card shadow-elevated">
              <div className="grid h-full place-items-center bg-gradient-to-br from-[#1d4b73] to-[#005696] text-center text-primary-foreground">
                <div>
                  <span className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-white/80 ring-1 ring-white/20">
                    <Play className="h-7 w-7 translate-x-0.5" />
                  </span>
                  <div className="font-display text-lg font-bold">Video coming soon</div>
                  <div className="mt-1 text-sm text-primary-foreground/70">Swap in your video URL to go live.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}