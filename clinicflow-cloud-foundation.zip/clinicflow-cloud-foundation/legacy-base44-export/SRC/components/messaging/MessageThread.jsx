import React, { useState, useEffect, useRef } from "react";
import { Send, Loader2 } from "lucide-react";

export default function MessageThread({ messages, onSend, sending, placeholder = "Type a reply…" }) {
  const [text, setText] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  async function submit(e) {
    e.preventDefault();
    const t = text.trim();
    if (!t || sending) return;
    setText("");
    await onSend(t);
  }

  return (
    <div className="flex h-full flex-col">
      <div ref={scrollRef} className="flex-1 space-y-2 overflow-y-auto bg-muted/20 p-4">
        {(!messages || messages.length === 0) && (
          <div className="py-10 text-center text-sm text-muted-foreground">No messages yet. Start the conversation.</div>
        )}
        {messages.map((m) => {
          const mine = m.sender_role === "staff";
          return (
            <div key={m.id} className={mine ? "flex justify-end" : "flex justify-start"}>
              <div className={mine
                ? "max-w-[80%] rounded-2xl bg-primary px-3.5 py-2 text-sm text-primary-foreground shadow-sm"
                : "max-w-[80%] rounded-2xl border border-border bg-card px-3.5 py-2 text-sm text-card-foreground shadow-sm"}>
                <div className="whitespace-pre-wrap break-words">{m.body}</div>
                <div className="mt-1 text-[10px] opacity-70">
                  {m.sender_name || (mine ? "Staff" : "Patient")} · {(m.created_date || "").slice(0, 16).replace("T", " ")}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <form onSubmit={submit} className="flex items-center gap-2 border-t border-border bg-card p-3">
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={placeholder}
          className="flex-1 rounded-lg border border-input bg-transparent px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-ring"
        />
        <button type="submit" disabled={sending || !text.trim()} className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50">
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </button>
      </form>
    </div>
  );
}