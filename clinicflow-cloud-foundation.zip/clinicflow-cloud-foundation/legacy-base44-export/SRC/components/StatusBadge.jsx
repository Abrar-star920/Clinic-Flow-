import React from "react";
import { cn } from "@/lib/utils";

const PALETTES = {
  // intake / general
  new: "bg-sky-100 text-sky-700 ring-1 ring-sky-200",
  checked_in: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  in_room: "bg-indigo-100 text-indigo-700 ring-1 ring-indigo-200",
  checked_out: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  no_show: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  // chart status / identity
  existing: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  partial: "bg-sky-100 text-sky-700 ring-1 ring-sky-200",
  no_match: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  ambiguous: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  inactive: "bg-slate-100 text-slate-500 ring-1 ring-slate-200",
  // insurance
  verified: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  pending: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  unverified: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  denied: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  // appointment
  scheduled: "bg-sky-100 text-sky-700 ring-1 ring-sky-200",
  confirmed: "bg-teal-100 text-teal-700 ring-1 ring-teal-200",
  in_progress: "bg-indigo-100 text-indigo-700 ring-1 ring-indigo-200",
  completed: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  cancelled: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  // call
  answered: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  missed: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  voicemail: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  escalated: "bg-orange-100 text-orange-700 ring-1 ring-orange-200",
  // escalation priority
  low: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  medium: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  high: "bg-orange-100 text-orange-700 ring-1 ring-orange-200",
  critical: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  // escalation status
  open: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  resolved: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  unresolved: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  waiting: "bg-violet-100 text-violet-700 ring-1 ring-violet-200",
  // procedure
  prep: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  recovery: "bg-violet-100 text-violet-700 ring-1 ring-violet-200",
  // pre-auth
  approved: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  not_required: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  draft: "bg-slate-100 text-slate-600 ring-1 ring-slate-200",
  ready: "bg-sky-100 text-sky-700 ring-1 ring-sky-200",
  submitted: "bg-indigo-100 text-indigo-700 ring-1 ring-indigo-200",
  partially_paid: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
  paid: "bg-emerald-100 text-emerald-700 ring-1 ring-emerald-200",
  on_hold: "bg-violet-100 text-violet-700 ring-1 ring-violet-200",
};

const LABELS = {
  new: "New",
  checked_in: "Checked In",
  in_room: "In Room",
  checked_out: "Checked Out",
  no_show: "No Show",
  existing: "Existing Chart",
  partial: "Partial Chart",
  no_match: "No Match",
  ambiguous: "Ambiguous",
  inactive: "Inactive",
  verified: "Verified",
  pending: "Pending",
  unverified: "Unverified",
  denied: "Denied",
  scheduled: "Scheduled",
  confirmed: "Confirmed",
  in_progress: "In Progress",
  completed: "Completed",
  cancelled: "Cancelled",
  answered: "Answered",
  missed: "Missed",
  voicemail: "Voicemail",
  escalated: "Escalated",
  low: "Low",
  medium: "Medium",
  high: "High",
  critical: "Critical",
  open: "Open",
  resolved: "Resolved",
  unresolved: "Unresolved",
  waiting: "Waiting",
  prep: "Prep",
  recovery: "Recovery",
  approved: "Approved",
  not_required: "Not Required",
  draft: "Draft",
  ready: "Ready",
  submitted: "Submitted",
  partially_paid: "Partially Paid",
  paid: "Paid",
  on_hold: "On Hold",
};

export default function StatusBadge({ status, className }) {
  const palette = PALETTES[status] || "bg-slate-100 text-slate-600 ring-1 ring-slate-200";
  const label = LABELS[status] || status;
  return (
    <span className={cn("status-badge", palette, className)}>
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {label}
    </span>
  );
}