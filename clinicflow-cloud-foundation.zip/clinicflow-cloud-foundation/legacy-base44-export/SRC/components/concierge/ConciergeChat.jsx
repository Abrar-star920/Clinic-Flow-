import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Bot, X, Send, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const SUGGESTIONS = [
  "Book an appointment",
  "Verify my insurance",
  "I need a prescription refill",
  "I have a billing question",
];

const URGENCY_CHIP = {
  low: "bg-slate-100 text-slate-600",
  medium: "bg-amber-100 text-amber-700",
  high: "bg-orange-100 text-orange-700",
  critical: "bg-rose-100 text-rose-700",
};

export default function ConciergeChat({ variant = "widget", patientContext = {} }) {
  const [open, setOpen] = useState(variant === "embedded");
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content: "Hi! I'm the ClinicFlow Concierge. I can book your appointment, verify your insurance details, request refills, and answer billing questions — right here in chat. How can I help today?",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, loading, open]);

  async function send(text) {
    const content = (text ?? input).trim();
    if (!content || loading) return;
    setInput("");
    const next = [...messages, { role: "user", content }];
    setMessages(next);
    setLoading(true);
    try {
      const { data } = await base44.functions.invoke("conciergeChat", {
        messages: next,
        patient_context: patientContext,
      });
      setMessages((m) => [...m, { role: "assistant", content: data.reply, intent: data.intent, urgency: data.urgency, escalated: data.escalated }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", content: "I'm having trouble connecting right now. Please call the clinic at (555) 200-1000.", urgency: "high" }]);
    } finally {
      setLoading(false);
    }
  }

  const Panel = (
    <div className="flex h-full flex-col">
      <div className="flex items-center gap-2.5 border-b border-border bg-gradient-to-r from-teal-500 to-sky-600 px-4 py-3 text-white">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20">
          <Bot className="h-5 w-5" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-bold">ClinicFlow Concierge</div>
          <div className="text-[11px] text-sky-100">AI assistant · online 24/7</div>
        </div>
        {variant === "widget" && (
          <button onClick={() => setOpen(false)} className="ml-auto rounded-lg p-1.5 hover:bg-white/20">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-background/60 p-4">
        {messages.map((m, i) => (
          <div key={i} className={cn("flex", m.role === "user" ? "justify-end" : "justify-start")}>
            <div className={cn("max-w-[85%] whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2 text-sm shadow-sm", m.role === "user" ? "bg-primary text-primary-foreground" : "bg-card text-card-foreground border border-border")}>
              {m.content}
              {m.urgency && m.role === "assistant" && (
                <div className="mt-1.5 flex items-center gap-1.5">
                  {m.intent && <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] font-semibold text-muted-foreground">{m.intent.replace(/_/g, " ")}</span>}
                  <span className={cn("rounded px-1.5 py-0.5 text-[10px] font-bold uppercase", URGENCY_CHIP[m.urgency])}>{m.urgency}</span>
                  {m.escalated && <span className="rounded bg-rose-100 px-1.5 py-0.5 text-[10px] font-bold uppercase text-rose-700">Routed to staff</span>}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="flex items-center gap-1.5 rounded-2xl border border-border bg-card px-3.5 py-2.5 text-sm text-muted-foreground">
              <Loader2 className="h-3.5 w-3.5 animate-spin" /> Thinking…
            </div>
          </div>
        )}
        {messages.length <= 1 && !loading && (
          <div className="flex flex-wrap gap-2 pt-1">
            {SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} className="rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground shadow-sm transition-colors hover:bg-accent">
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      <form
        onSubmit={(e) => { e.preventDefault(); send(); }}
        className="flex items-center gap-2 border-t border-border bg-card p-3"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message…"
          className="flex-1 rounded-lg border border-input bg-transparent px-3 py-2 text-sm outline-none focus:ring-1 focus:ring-ring"
        />
        <button type="submit" disabled={loading || !input.trim()} className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground transition-colors hover:bg-primary/90 disabled:opacity-50">
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );

  if (variant === "embedded") {
    return <div className="h-[460px] overflow-hidden rounded-2xl border border-border bg-card shadow-lg">{Panel}</div>;
  }

  return (
    <>
      {open ? (
        <div className="fixed bottom-5 right-5 z-50 flex h-[520px] w-[360px] max-w-[calc(100vw-2.5rem)] flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-2xl">
          {Panel}
        </div>
      ) : (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full bg-gradient-to-r from-teal-500 to-sky-600 px-4 py-3 text-sm font-semibold text-white shadow-lg transition-transform hover:scale-105"
        >
          <Sparkles className="h-5 w-5" /> Ask Concierge
        </button>
      )}
    </>
  );
}