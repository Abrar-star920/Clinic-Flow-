import React, { useEffect, useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { CalendarCheck, Loader2, Plug, Unplug } from "lucide-react";

const CONNECTOR_ID = "6a84a59e386cd73bf1499b9d";

export default function GoogleCalendarConnect() {
  const [connected, setConnected] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  const check = useCallback(async () => {
    try {
      const res = await base44.functions.invoke("syncAppointmentToCalendar", {});
      setConnected(!!res.data?.connected);
    } catch {
      setConnected(false);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    base44.auth.isAuthenticated().then((authed) => {
      if (authed) check();
      else setLoading(false);
    });
  }, [check]);

  async function handleConnect() {
    setBusy(true);
    try {
      const url = await base44.connectors.connectAppUser(CONNECTOR_ID);
      const popup = window.open(url, "_blank");
      const timer = setInterval(() => {
        if (!popup || popup.closed) {
          clearInterval(timer);
          check();
          setBusy(false);
        }
      }, 500);
    } catch {
      setBusy(false);
    }
  }

  async function handleDisconnect() {
    setBusy(true);
    try {
      await base44.connectors.disconnectAppUser(CONNECTOR_ID);
      setConnected(false);
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return (
      <Button variant="outline" size="sm" disabled className="gap-1.5">
        <Loader2 className="h-4 w-4 animate-spin" /> Calendar…
      </Button>
    );
  }

  if (connected) {
    return (
      <Button variant="outline" size="sm" className="gap-1.5 border-emerald-300 text-emerald-700" onClick={handleDisconnect} disabled={busy}>
        <CalendarCheck className="h-4 w-4" /> Google Calendar synced
      </Button>
    );
  }

  return (
    <Button variant="outline" size="sm" className="gap-1.5" onClick={handleConnect} disabled={busy}>
      <Plug className="h-4 w-4" /> Connect Google Calendar
    </Button>
  );
}