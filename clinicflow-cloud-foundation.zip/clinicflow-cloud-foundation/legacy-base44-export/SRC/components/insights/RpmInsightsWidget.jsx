import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  Activity, HeartPulse, Droplet, Thermometer, Gauge, AlertTriangle,
  TrendingUp, ArrowUpRight, Loader2,
} from "lucide-react";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid,
} from "recharts";
import { cn } from "@/lib/utils";

const METRIC_META = {
  bp_systolic: { label: "Systolic BP", unit: "mmHg", icon: Gauge },
  bp_diastolic: { label: "Diastolic BP", unit: "mmHg", icon: Gauge },
  heart_rate: { label: "Heart Rate", unit: "bpm", icon: HeartPulse },
  spo2: { label: "SpO₂", unit: "%", icon: Droplet },
  temperature: { label: "Temperature", unit: "°F", icon: Thermometer },
  glucose: { label: "Glucose", unit: "mg/dL", icon: Activity },
  respiratory_rate: { label: "Resp Rate", unit: "rpm", icon: Activity },
  weight: { label: "Weight", unit: "lb", icon: Activity },
};

// Returns { level: "critical"|"elevated"|null, note } when a reading is abnormal
function classify(type, value) {
  const v = Number(value);
  if (Number.isNaN(v)) return null;
  const rules = {
    bp_systolic: [[180, "critical", "Hypertensive crisis"], [140, "elevated", "High"], [90, null, ""], [0, "critical", "Low"]],
    bp_diastolic: [[120, "critical", "Critical"], [90, "elevated", "High"], [50, null, ""], [0, "critical", "Low"]],
    heart_rate: [[120, "critical", "Critical"], [100, "elevated", "Tachycardia"], [50, null, ""], [0, "critical", "Bradycardia"]],
    spo2: [[92, null, ""], [88, "elevated", "Low"], [0, "critical", "Critical"]],
    temperature: [[103, "critical", "High fever"], [100.4, "elevated", "Fever"], [95, null, ""], [0, "critical", "Low"]],
    glucose: [[300, "critical", "Critical"], [180, "elevated", "High"], [70, null, ""], [0, "critical", "Low"]],
    respiratory_rate: [[24, "critical", "Critical"], [20, "elevated", "High"], [12, null, ""], [0, "critical", "Low"]],
  };
  const r = rules[type];
  if (!r) return null;
  for (const [threshold, level, note] of r) {
    if (v >= threshold) return level ? { level, note } : null;
  }
  return null;
}

const LEVEL_CHIP = {
  critical: "bg-rose-100 text-rose-700 ring-1 ring-rose-200",
  elevated: "bg-amber-100 text-amber-700 ring-1 ring-amber-200",
};

function dayKey(d) {
  return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export default function RpmInsightsWidget() {
  const [vitals, setVitals] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    Promise.all([
      base44.entities.VitalReading.list("-recorded_at", 300),
      base44.entities.RpmSession.list("-recorded_at", 200),
    ])
      .then(([v, s]) => {
        if (!active) return;
        setVitals(v || []);
        setSessions(s || []);
      })
      .finally(() => active && setLoading(false));
    return () => { active = false; };
  }, []);

  const insights = useMemo(() => {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 86400000);
    const todayKey = now.toLocaleDateString("en-US");

    // latest reading per patient+type
    const latest = new Map(); // key `${patient_id}|${type}` -> reading
    for (const r of vitals) {
      const k = `${r.patient_id}|${r.type}`;
      const ex = latest.get(k);
      if (!ex || new Date(r.recorded_at) > new Date(ex.recorded_at)) latest.set(k, r);
    }

    // concerns: patients with abnormal latest readings
    const concernsByPatient = new Map();
    for (const r of latest.values()) {
      const c = classify(r.type, r.value);
      if (!c) continue;
      const arr = concernsByPatient.get(r.patient_id) || { patient_id: r.patient_id, patient_name: r.patient_name, items: [] };
      arr.items.push({ type: r.type, value: r.value, ...c, recorded_at: r.recorded_at });
      concernsByPatient.set(r.patient_id, arr);
    }
    const concerns = [...concernsByPatient.values()]
      .map((c) => ({
        ...c,
        worst: c.items.reduce((acc, it) => (it.level === "critical" ? "critical" : acc), "elevated"),
      }))
      .sort((a, b) => (a.worst === "critical" ? -1 : 1) - (b.worst === "critical" ? -1 : 1))
      .slice(0, 5);

    // monitored patients (distinct)
    const monitored = new Set([...vitals.map((v) => v.patient_id), ...sessions.map((s) => s.patient_id)].filter(Boolean));
    const readingsToday = vitals.filter((v) => v.recorded_at && new Date(v.recorded_at).toLocaleDateString("en-US") === todayKey).length;

    // weekly minutes
    const weekSessions = sessions.filter((s) => s.recorded_at && new Date(s.recorded_at) >= weekAgo);
    const weekMinutes = weekSessions.reduce((sum, s) => sum + (Number(s.minutes) || 0), 0);
    const avgMinutes = monitored.size ? Math.round(weekMinutes / monitored.size) : 0;

    // daily avg systolic BP trend (last 7 days)
    const dailySys = {};
    for (const v of vitals) {
      if (v.type !== "bp_systolic" || !v.recorded_at) continue;
      const d = new Date(v.recorded_at);
      if (d < weekAgo) continue;
      const k = dayKey(d);
      dailySys[k] = dailySys[k] || { sum: 0, n: 0 };
      dailySys[k].sum += Number(v.value) || 0;
      dailySys[k].n += 1;
    }
    const trend = Object.entries(dailySys)
      .map(([day, { sum, n }]) => ({ day, avg: Math.round(sum / n) }))
      .slice(-7);

    return { concerns, monitored: monitored.size, readingsToday, avgMinutes, weekMinutes, trend };
  }, [vitals, sessions]);

  const trendMax = insights.trend.length ? Math.max(...insights.trend.map((t) => t.avg)) : 0;

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card shadow-card">
      <div className="flex items-center justify-between border-b border-border bg-gradient-to-r from-sky-50/70 to-teal-50/40 px-5 py-3.5">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-sky-500 to-teal-500 text-white shadow-soft">
            <Activity className="h-4 w-4" />
          </div>
          <div>
            <h3 className="font-display text-sm font-bold tracking-tight text-foreground">Vitals & RPM Insights</h3>
            <p className="text-[11px] text-muted-foreground">Real-time health trends across monitored patients</p>
          </div>
        </div>
        <Link to="/rpm" className="inline-flex items-center gap-0.5 text-xs font-semibold text-primary hover:underline">
          Open RPM <ArrowUpRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
        </div>
      ) : (
        <div className="grid gap-0 lg:grid-cols-5">
          {/* Trend chart */}
          <div className="border-b border-border p-5 lg:col-span-3 lg:border-b-0 lg:border-r">
            <div className="mb-1 flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Avg Systolic BP · 7 days</span>
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-foreground">
                <TrendingUp className="h-3.5 w-3.5 text-chart-2" /> {insights.trend.length ? `${insights.trend[insights.trend.length - 1].avg} mmHg` : "—"}
              </span>
            </div>
            <div className="h-32">
              {insights.trend.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={insights.trend} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
                    <defs>
                      <linearGradient id="bpFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--chart-1))" stopOpacity={0.35} />
                        <stop offset="100%" stopColor="hsl(var(--chart-1))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                    <XAxis dataKey="day" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                    <YAxis domain={[60, Math.max(160, trendMax + 10)]} tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={36} />
                    <Tooltip contentStyle={{ borderRadius: 10, border: "1px solid hsl(var(--border))", fontSize: 12 }} />
                    <Area type="monotone" dataKey="avg" stroke="hsl(var(--chart-1))" strokeWidth={2.5} fill="url(#bpFill)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full items-center justify-center text-xs text-muted-foreground">No BP readings in the last 7 days</div>
              )}
            </div>

            <div className="mt-4 grid grid-cols-3 gap-3">
              <MiniStat label="Monitored" value={insights.monitored} icon={HeartPulse} />
              <MiniStat label="Readings today" value={insights.readingsToday} icon={Activity} />
              <MiniStat label="Avg min / patient" value={`${insights.avgMinutes}m`} icon={TrendingUp} />
            </div>
          </div>

          {/* Health concerns */}
          <div className="p-5 lg:col-span-2">
            <div className="mb-2 flex items-center gap-1.5">
              <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
              <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Health concerns</span>
            </div>
            {insights.concerns.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-8 text-center">
                <HeartPulse className="h-6 w-6 text-emerald-500" />
                <p className="mt-2 text-xs text-muted-foreground">All monitored vitals within range</p>
              </div>
            ) : (
              <ul className="space-y-2">
                {insights.concerns.map((c) => (
                  <li key={c.patient_id}>
                    <Link
                      to={`/patients/${c.patient_id}`}
                      className="block rounded-lg border border-border bg-background/50 p-3 transition-colors hover:border-primary/40 hover:bg-accent"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-sm font-semibold text-foreground">{c.patient_name || "Unknown"}</span>
                        <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold uppercase", LEVEL_CHIP[c.worst])}>
                          {c.worst}
                        </span>
                      </div>
                      <div className="mt-1.5 flex flex-wrap gap-1.5">
                        {c.items.slice(0, 3).map((it, i) => {
                          const Meta = METRIC_META[it.type] || {};
                          return (
                            <span key={i} className="inline-flex items-center gap-1 rounded-md bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground">
                              {Meta.label || it.type}: <span className="font-semibold text-foreground">{it.value}{Meta.unit ? ` ${Meta.unit}` : ""}</span>
                            </span>
                          );
                        })}
                      </div>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value, icon: Icon }) {
  return (
    <div className="rounded-lg border border-border bg-background/50 p-2.5">
      <div className="flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
        <Icon className="h-3 w-3" /> {label}
      </div>
      <div className="mt-0.5 font-display text-base font-bold text-foreground">{value}</div>
    </div>
  );
}