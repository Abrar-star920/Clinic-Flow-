import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

export default function NewInvoiceDialog({ open, onClose, onCreated }) {
  const { toast } = useToast();
  const [patients, setPatients] = useState([]);
  const [form, setForm] = useState({ patient_id: "", cpt_codes: "", description: "", amount: "", due_date: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) base44.entities.Patient.list("-created_date", 200).then(setPatients).catch(() => {});
  }, [open]);

  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    const patient = patients.find((p) => p.id === form.patient_id);
    if (!patient) return toast({ variant: "destructive", title: "Select a patient" });
    if (!form.amount || Number(form.amount) <= 0) return toast({ variant: "destructive", title: "Enter a valid amount" });
    setSaving(true);
    try {
      await base44.entities.Claim.create({
        patient_id: patient.id,
        patient_name: patient.full_name,
        patient_email: patient.email,
        invoice_number: `INV-${Date.now().toString().slice(-6)}`,
        cpt_codes: form.cpt_codes ? form.cpt_codes.split(",").map((s) => s.trim()).filter(Boolean) : [],
        description: form.description,
        amount: Number(form.amount),
        currency: "usd",
        status: "ready",
        due_date: form.due_date || undefined,
      });
      toast({ title: "Invoice created" });
      setForm({ patient_id: "", cpt_codes: "", description: "", amount: "", due_date: "" });
      onCreated();
    } catch (err) {
      toast({ variant: "destructive", title: "Could not create invoice", description: err?.message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>New Invoice</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Patient</Label>
            <select
              value={form.patient_id}
              onChange={(e) => update("patient_id", e.target.value)}
              className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
            >
              <option value="">Select patient…</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>{p.full_name}</option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Description</Label>
            <Textarea value={form.description} onChange={(e) => update("description", e.target.value)} rows={2} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Amount ($)</Label>
              <Input type="number" step="0.01" min="0" value={form.amount} onChange={(e) => update("amount", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Due Date</Label>
              <Input type="date" value={form.due_date} onChange={(e) => update("due_date", e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>CPT Codes (comma separated)</Label>
            <Input value={form.cpt_codes} onChange={(e) => update("cpt_codes", e.target.value)} placeholder="99490, 99439" />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Create Invoice
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}