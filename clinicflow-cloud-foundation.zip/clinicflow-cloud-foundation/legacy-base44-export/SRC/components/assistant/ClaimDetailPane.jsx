import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Loader2, FileText, AlertTriangle, Send, ShieldCheck, CheckCircle2, Lock } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { useToast } from "@/components/ui/use-toast";

function Field({ label, value }) {
  return (
    <div>
      <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="text-sm font-medium text-foreground">{value || "—"}</div>
    </div>
  );
}

function maskName(name = "") {
  const parts = name.trim().split(/\s+/);
  if (parts.length < 2) return name;
  return `${parts[0]} ${parts[parts.length - 1][0]}.`;
}

const APPROVABLE = ["ready", "draft", "denied", "on_hold"];

export default function ClaimDetailPanel({ claim, env, connected }) {
  const { toast } = useToast();
  const [statusReply, setStatusReply] = useState("");
  const [denialReply, setDenialReply] = useState("");
  const [loading, setLoading] = useState("");
  const [payerName, setPayerName] = useState("");
  const [submitResult, setSubmitResult] = useState(null);

  useEffect(() => {
    setSubmitResult(null);
    if (!claim?.patient_id) { setPayerName(""); return; }
    base44.entities.Patient.get(claim.patient_id).then((p) => setPayerName(p.insurance_provider || "")).catch(() => setPayerName(""));
  }, [claim?.id]);

  if (!claim) {
    return <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">Select a claim to view details.</div>;
  }

  async function runAi(action, setter) {
    setLoading(action);
    setter("");
    try {
      const res = await base44.functions.invoke("insuranceAssistant", { action, claimId: claim.id });
      setter(res.data.reply);
    } catch (err) {
      setter("Error: " + (err.response?.data?.error || "unable to analyze"));
    } finally {
      setLoading("");
    }
  }

  async function checkStatus() {
    setLoading("claim_status_api");
    try {
      const res = await base44.functions.invoke("checkClaimStatus", { claim_id: claim.id });
      const d = res.data;
      if (d.error) toast({ variant: "destructive", title: "Claim status failed", description: d.error });
      else toast({ title: "Status updated", description: d.result?.status || "Checked" });
    } catch (err) {
      toast({ variant: "destructive", title: "Claim status failed", description: err.response?.data?.error || "error" });
    } finally {
      setLoading("");
    }
  }

  async function approveForSubmission() {
    setLoading("approve_claim");
    try {
      const res = await base44.functions.invoke("insuranceAssistant", { action: "approve_claim", claimId: claim.id });
      if (res.data.error) toast({ variant: "destructive", title: "Approval failed", description: res.data.error });
      else toast({ title: "Approved for submission", description: "Claim is ready to submit." });
    } catch (err) {
      toast({ variant: "destructive", title: "Approval failed", description: err.response?.data?.error || "error" });
    } finally {
      setLoading("");
    }
  }

  async function submitClaim() {
    setLoading("submit_claim");
    setSubmitResult(null);
    try {
      const res = await base44.functions.invoke("submitClaim", { claim_id: claim.id });
      const d = res.data;
      if (d.error) {
        toast({ variant: "destructive", title: "Submission failed", description: d.error });
      } else {
        setSubmitResult(d);
        toast({ title: "Claim submitted", description: `Stedi control #${d.stediControlNumber || "—"}` });
      }
    } catch (err) {
      toast({ variant: "destructive", title: "Submission failed", description: err.response?.data?.error || "error" });
    } finally {
      setLoading("");
    }
  }

  const isProduction = env === "production";
  const canSubmit = isProduction && claim.status === "approved_for_submission";
  const statusTooltip = !isProduction ? "Requires production mode" : claim.status !== "approved_for_submission" ? "Approve for submission first" : "";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-display text-sm font-bold text-foreground">{claim.invoice_number || "Claim"}</div>
          <div className="text-xs text-muted-foreground">{claim.patient_name}</div>
        </div>
        <StatusBadge status={claim.status} />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <Field label="Billed" value={claim.amount != null ? `$${Number(claim.amount).toFixed(2)}` : ""} />
        <Field label="Status" value={claim.status} />
        <Field label="Due date" value={claim.due_date} />
        <Field label="Paid date" value={claim.paid_date} />
        <Field label="CPT codes" value={Array.isArray(claim.cpt_codes) ? claim.cpt_codes.join(", ") : claim.cpt_codes} />
        <Field label="Payer (on file)" value={payerName} />
      </div>

      {(claim.clearinghouse_status || (claim.denial_codes && claim.denial_codes.length)) && (
        <div className="rounded-lg border border-border bg-surface p-3">
          <div className="mb-1 text-xs font-semibold text-muted-foreground">Clearinghouse</div>
          <div className="flex flex-wrap gap-2 text-sm">
            {claim.clearinghouse_status && <span className="font-medium text-foreground">Status: {claim.clearinghouse_status}</span>}
            {claim.denial_codes?.length > 0 && (
              <span className="font-medium text-destructive">Denial codes: {claim.denial_codes.join(", ")}</span>
            )}
          </div>
          {claim.stedi_control_number && <div className="mt-1 text-xs text-muted-foreground">Stedi control # {claim.stedi_control_number}</div>}
        </div>
      )}

      {claim.description && <Field label="Description" value={claim.description} />}

      <div className="flex flex-wrap gap-2">
        <Button variant="outline" size="sm" onClick={() => runAi("claim_status", setStatusReply)} disabled={!!loading}>
          {loading === "claim_status" ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
          Explain status
        </Button>
        <Button variant="outline" size="sm" onClick={() => runAi("denial_analysis", setDenialReply)} disabled={!!loading}>
          {loading === "denial_analysis" ? <Loader2 className="h-4 w-4 animate-spin" /> : <AlertTriangle className="h-4 w-4" />}
          Denial analysis
        </Button>
        <Button
          variant="outline" size="sm" onClick={checkStatus}
          disabled={!connected || !isProduction || !!loading}
          title={!isProduction ? "Requires production mode" : ""}
        >
          {loading === "claim_status_api" ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
          Check claim status
        </Button>
        {APPROVABLE.includes(claim.status) && (
          <Button variant="outline" size="sm" onClick={approveForSubmission} disabled={!!loading}>
            {loading === "approve_claim" ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
            Approve for submission
          </Button>
        )}
      </div>

      <div className="flex items-center gap-2">
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button size="sm" disabled={!canSubmit || !!loading} title={statusTooltip}>
              {loading === "submit_claim" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Submit claim
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Submit this claim to the payer?</AlertDialogTitle>
              <AlertDialogDescription>
                This sends a real 837P claim through Stedi in <strong>production</strong> mode. Confirm the details:
              </AlertDialogDescription>
            </AlertDialogHeader>
            <div className="space-y-1.5 rounded-lg border border-border bg-surface p-3 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Payer</span><span className="font-medium">{payerName || "on file"}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Patient</span><span className="font-medium">{maskName(claim.patient_name)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Total charges</span><span className="font-medium">${Number(claim.amount || 0).toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Control #</span><span className="font-medium">{claim.patient_control_number || claim.invoice_number || "—"}</span></div>
            </div>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={submitClaim}>Submit claim</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
        {!isProduction && <span className="text-xs text-muted-foreground">Requires production mode</span>}
        {claim.status !== "approved_for_submission" && isProduction && <span className="text-xs text-muted-foreground">Approve for submission first</span>}
      </div>

      {submitResult && (
        <div className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
          <CheckCircle2 className="h-3.5 w-3.5" /> Submitted — Stedi control # {submitResult.stediControlNumber || "—"}
        </div>
      )}

      {statusReply && (
        <div className="rounded-lg border border-border bg-surface p-3">
          <div className="mb-1 text-xs font-semibold text-muted-foreground">Status summary</div>
          <p className="whitespace-pre-wrap text-sm text-foreground">{statusReply}</p>
        </div>
      )}
      {denialReply && (
        <div className="rounded-lg border border-amber-200 bg-amber-50/60 p-3">
          <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold text-amber-700">
            <AlertTriangle className="h-3.5 w-3.5" /> Denial analysis
          </div>
          <p className="whitespace-pre-wrap text-sm text-foreground">{denialReply}</p>
        </div>
      )}

      <p className="inline-flex items-center gap-1 text-[11px] text-muted-foreground"><Lock className="h-3 w-3" /> AI can read results but can never submit a claim.</p>
    </div>
  );
}