import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Inbox, Loader2 } from "lucide-react";

export default function FetchAcknowledgmentsButton({ connected, onUpdated }) {
  const { toast } = useToast();
  const [fetching, setFetching] = useState(false);

  async function onFetch() {
    setFetching(true);
    try {
      const res = await base44.functions.invoke("fetchAcknowledgmentsAndRemittance", {});
      const data = res.data || {};
      if (data.error) {
        toast({ title: "Acknowledgments", description: data.error, variant: "destructive" });
      } else {
        toast({
          title: "Acknowledgments fetched",
          description: `Processed ${data.processed || 0} report(s), updated ${data.updated || 0} claim(s), skipped ${data.skipped || 0} already processed.`,
        });
        onUpdated?.();
      }
    } catch (e) {
      toast({
        title: "Could not fetch acknowledgments",
        description: e.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setFetching(false);
    }
  }

  return (
    <Button size="sm" variant="outline" onClick={onFetch} disabled={!connected || fetching}>
      {fetching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Inbox className="h-4 w-4" />}
      Fetch acknowledgments
    </Button>
  );
}