import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Loader2, Sparkles, Copy, Check, Send, ShieldCheck } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const TYPES = [
  { value: "appeal", label: "Appeal letter" },
  { value: "prior_auth", label: "Prior-authorization request" },
  { value: "follow_up", label: "Payer follow-up (email + call script)" },
];

export default function DraftPanel({ claim }) {
  const { toast } = useToast();
  const [draftType, setDraftType] = useState("appeal");
  const [payer, setPayer] = useState("");
  const [draft, setDraft] = useState("");
  const [interactionId, setInteractionId] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [approved, setApproved] = useState(null);

  async function generate() {
    if (!claim) return;
    setLoading(true);
    setDraft("");
    setApproved(null);
    try {
      const res = await base44.functions.invoke("insuranceAssistant", {
        action: "draft", claimId: claim.id, draftType, payer,
      });
      setDraft(res.data.draftText);
      setInteractionId(res.data.interactionId);
    } catch (err) {
      toast({ variant: "destructive", title: "Draft failed", description: err.message });
    } finally {
      setLoading(false);
    }
  }

  function copy() {
    navigator.clipboard.writeText(draft);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  async function approve() {
    if (!interactionId) return;
    try {
      const res = await base44.functions.invoke("insuranceAssistant", { action: "approve", interactionId });
      setApproved(res.data);
      toast({ title: "Approved", description: "Draft approved and logged. Transmission requires a connected clearinghouse." });
    } catch (err) {
      toast({ variant: "destructive", title: "Approval failed", description: err.message });
    }
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div className="space-y-1.5 sm:col-span-2">
          <Label>Draft type</Label>
          <Select value={draftType} onValueChange={setDraftType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="py">Payer</Label>
          <Input id="py" value={payer} onChange={(e) => setPayer(e.target.value)} placeholder="Payer name" />
        </div>
      </div>

      <Button onClick={generate} disabled={loading || !claim} className="w-full sm:w-auto">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
        Generate draft
      </Button>

      {draft && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="dt">Draft — editable, for staff review only</Label>
            <Button variant="ghost" size="sm" onClick={copy}>
              {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />} Copy
            </Button>
          </div>
          <Textarea id="dt" value={draft} onChange={(e) => setDraft(e.target.value)} rows={14} className="font-mono text-xs" />
          <div className="flex items-center justify-between">
            <p className="text-xs text-muted-foreground">Nothing is sent until a staff member reviews and approves.</p>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" disabled={!!approved}>
                  <Send className="h-4 w-4" /> Approve and send
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Approve this draft?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This marks the draft as reviewed and approved by you, and logs your approval. The draft will be transmitted to the payer only once a clearinghouse is connected.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={approve}>Approve</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
          {approved && (
            <div className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1 text-xs font-semibold text-accent-foreground">
              <ShieldCheck className="h-3.5 w-3.5" /> Approved by {approved.approvedBy}
            </div>
          )}
        </div>
      )}
    </div>
  );
}