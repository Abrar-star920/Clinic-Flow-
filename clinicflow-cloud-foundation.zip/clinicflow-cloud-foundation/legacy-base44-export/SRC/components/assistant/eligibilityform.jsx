import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Search, WifiOff, FlaskConical, ShieldCheck, CheckCircle2, XCircle } from "lucide-react";

const SERVICE_TYPES = [
  { value: "health_benefit", label: "Health Benefit Plan Coverage" },
  { value: "medical_care", label: "Medical Care" },
  { value: "specialist", label: "Specialist Visit" },
  { value: "lab", label: "Lab Work" },
];

function ResultRow({ label, value }) {
  return (
    <div className="flex items-center justify-between border-b border-border py-2 last:border-0">
      <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</span>
      <span className="text-sm font-semibold text-foreground">{value || "—"}</span>
    </div>
  );
}

export default function EligibilityForm({ env, connected }) {
  const [patients, setPatients] = useState([]);
  const [payers, setPayers] = useState([]);
  const [patientId, setPatientId] = useState("");
  const [payerId, setPayerId] = useState("");
  const [dateOfService, setDateOfService] = useState("");
  const [serviceType, setServiceType] = useState("health_benefit");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    base44.entities.Patient.filter({}, { sort: "full_name", limit: 200, fields: ["full_name"] })
      .then(({ items }) => setPatients(items));
    base44.entities.Payer.filter({ supports_eligibility: true }, { sort: "payer_name", limit: 100 })
      .then(({ items }) => setPayers(items));
  }, []);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setResult(null);
    if (!patientId || !payerId) {
      setError("Select a patient and a payer.");
      return;
    }
    setLoading(true);
    try {
      const res = await base44.functions.invoke("checkEligibility", {
        patient_id: patientId, payer_id: payerId,
        date_of_service: dateOfService, service_type: serviceType,
      });
      const d = res.data;
      if (d.error) setError(d.error);
      else setResult(d.result);
    } catch (err) {
      setError(err.response?.data?.error || "Unable to check eligibility.");
    } finally {
      setLoading(false);
    }
  }

  if (!connected) {
    return (
      <div className="flex items-center gap-2 rounded-lg border border-dashed border-border p-6 text-sm text-muted-foreground">
        <WifiOff className="h-4 w-4" /> Stedi not connected. Set STEDI_API_KEY in Settings → Secrets.
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {env === "test" && (
        <div className="flex items-center gap-2 rounded-lg bg-amber-50 px-3 py-2 text-xs font-medium text-amber-800 ring-1 ring-amber-200">
          <FlaskConical className="h-3.5 w-3.5" /> Test mode: mock data only, no real patient data sent to a payer.
        </div>
      )}

      <form onSubmit={submit} className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label>Patient</Label>
          <Select value={patientId} onValueChange={setPatientId}>
            <SelectTrigger><SelectValue placeholder="Select patient" /></SelectTrigger>
            <SelectContent>
              {patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Payer</Label>
          <Select value={payerId} onValueChange={setPayerId}>
            <SelectTrigger><SelectValue placeholder="Select payer" /></SelectTrigger>
            <SelectContent>
              {payers.map((p) => <SelectItem key={p.id} value={p.id}>{p.payer_name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="dos">Date of service</Label>
          <Input id="dos" type="date" value={dateOfService} onChange={(e) => setDateOfService(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label>Service type</Label>
          <Select value={serviceType} onValueChange={setServiceType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {SERVICE_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="sm:col-span-2">
          <Button type="submit" disabled={loading} className="w-full sm:w-auto">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Check eligibility
          </Button>
        </div>
      </form>

      {error && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive">
          {error}
        </div>
      )}

      {result && (
        <div className="rounded-lg border border-border bg-surface p-4">
          <div className="mb-2 flex items-center gap-2">
            {result.active
              ? <span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-2.5 py-1 text-xs font-semibold text-accent-foreground"><CheckCircle2 className="h-3.5 w-3.5" /> Active</span>
              : <span className="inline-flex items-center gap-1.5 rounded-full bg-red-50 px-2.5 py-1 text-xs font-semibold text-red-700"><XCircle className="h-3.5 w-3.5" /> Inactive</span>}
            {result.priorAuthRequired && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700 ring-1 ring-amber-200">
                <ShieldCheck className="h-3.5 w-3.5" /> Prior auth required
              </span>
            )}
          </div>
          <ResultRow label="Plan" value={result.planName} />
          <ResultRow label="Copay" value={result.copay} />
          <ResultRow label="Deductible" value={result.deductible} />
          <ResultRow label="Deductible met" value={result.deductibleMet} />
          <ResultRow label="Out-of-pocket max" value={result.oopMax} />
          <ResultRow label="Coinsurance" value={result.coinsurance} />
        </div>
      )}
    </div>
  );
}