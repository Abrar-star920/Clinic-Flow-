import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/components/ui/use-toast";
import { Loader2, X } from "lucide-react";

export default function PayerDialog({ payer, open, onOpenChange, onSaved }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    payer_name: "", stedi_payer_id: "",
    supports_eligibility: true, supports_claim_status: true, supports_professional_claims: true,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (payer) {
      setForm({
        payer_name: payer.payer_name || "",
        stedi_payer_id: payer.stedi_payer_id || "",
        supports_eligibility: payer.supports_eligibility ?? true,
        supports_claim_status: payer.supports_claim_status ?? true,
        supports_professional_claims: payer.supports_professional_claims ?? true,
      });
    } else {
      setForm({
        payer_name: "", stedi_payer_id: "",
        supports_eligibility: true, supports_claim_status: true, supports_professional_claims: true,
      });
    }
  }, [payer, open]);

  async function save() {
    if (!form.payer_name || !form.stedi_payer_id) {
      toast({ variant: "destructive", title: "Missing fields", description: "Payer name and Stedi payer ID are required." });
      return;
    }
    setSaving(true);
    try {
      if (payer) await base44.entities.Payer.update(payer.id, form);
      else await base44.entities.Payer.create(form);
      toast({ title: "Payer saved" });
      onSaved();
      onOpenChange(false);
    } catch (e) {
      toast({ variant: "destructive", title: "Save failed", description: e.message });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{payer ? "Edit payer" : "Add payer"}</DialogTitle>
        </DialogHeader>
        <DialogClose asChild>
          <button className="absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100"><X className="h-4 w-4" /></button>
        </DialogClose>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="pn">Payer name</Label>
            <Input id="pn" value={form.payer_name} onChange={(e) => setForm({ ...form, payer_name: e.target.value })} placeholder="Blue Cross Blue Shield" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="sp">Stedi payer ID</Label>
            <Input id="sp" value={form.stedi_payer_id} onChange={(e) => setForm({ ...form, stedi_payer_id: e.target.value })} placeholder="00000" />
          </div>
          <div className="space-y-2 rounded-lg border border-border bg-surface p-3">
            {[
              ["supports_eligibility", "Supports eligibility (270/271)"],
              ["supports_claim_status", "Supports claim status (276/277)"],
              ["supports_professional_claims", "Supports professional claims (837P)"],
            ].map(([key, label]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-sm text-foreground">{label}</span>
                <Switch checked={form[key]} onCheckedChange={(v) => setForm({ ...form, [key]: v })} />
              </div>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button onClick={save} disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {payer ? "Save changes" : "Add payer"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}