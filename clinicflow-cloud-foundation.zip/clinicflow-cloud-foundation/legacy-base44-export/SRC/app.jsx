import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import RoleRouter from '@/components/RoleRouter';
import ProtectedRoute from '@/components/ProtectedRoute';
import Patients from '@/pages/Patients';
import Dashboard from '@/pages/Dashboard';
import Scheduling from '@/pages/Scheduling';
import CallLog from '@/pages/CallLog';
import Escalations from '@/pages/Escalations';
import Procedures from '@/pages/Procedures';
import Doctors from '@/pages/Doctors';
import Analytics from '@/pages/Analytics';
import BookingTrends from '@/pages/BookingTrends';
import ActivityLog from '@/pages/ActivityLog';
import Billing from '@/pages/Billing';
import RpmMonitoring from '@/pages/RpmMonitoring';
import Concierge from '@/pages/Concierge';
import PatientPortalPublic from '@/pages/PatientPortalPublic';
import CallConcierge from '@/pages/CallConcierge';
import Messages from '@/pages/Messages';
import Tasks from '@/pages/Tasks';
import PatientDetail from '@/pages/PatientDetail';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Landing from '@/pages/Landing';
import StaffLogin from '@/pages/StaffLogin';
import InactivityLogout from '@/components/InactivityLogout';
import SecurityGate from '@/components/security/SecurityGate';
import PatientAssistant from '@/pages/PatientAssistant';
import InsuranceAssistant from '@/pages/InsuranceAssistant';
import Payers from '@/pages/Payers';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/staff-login" element={<StaffLogin />} />
      <Route path="/" element={<Landing />} />
      <Route path="/concierge" element={<Concierge />} />
      <Route path="/portal" element={<PatientPortalPublic />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route path="/assistant" element={<PatientAssistant />} />
      </Route>
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/staff-login" replace />} />}>
        <Route element={<RoleRouter />}>
          <Route path="/app" element={<Dashboard />} />
          <Route path="/patients" element={<Patients />} />
          <Route path="/patients/:id" element={<PatientDetail />} />
          <Route path="/scheduling" element={<Scheduling />} />
          <Route path="/call-log" element={<CallLog />} />
          <Route path="/escalations" element={<Escalations />} />
          <Route path="/procedures" element={<Procedures />} />
          <Route path="/doctors" element={<Doctors />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/booking-trends" element={<BookingTrends />} />
          <Route path="/activity-log" element={<ActivityLog />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/rpm" element={<RpmMonitoring />} />
          <Route path="/call-concierge" element={<CallConcierge />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/tasks" element={<Tasks />} />
          <Route path="/insurance-assistant" element={<InsuranceAssistant />} />
          <Route path="/payers" element={<Payers />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <SecurityGate>
            <AuthenticatedApp />
          </SecurityGate>
          <InactivityLogout />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App