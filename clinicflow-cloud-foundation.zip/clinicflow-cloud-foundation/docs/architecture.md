# Proposed AWS deployment

Internet -> Route 53 -> CloudFront + AWS WAF -> ALB -> EKS

EKS workloads:
- `web`: static React build served by Nginx (after Base44 SDK removal).
- `api`: modular FastAPI core for patients, scheduling, billing and portal.
- `agent`: doctor discovery and patient-confirmed scheduling workflow.
- `etl-worker`: SQS consumers/CronJobs for provider, payer and claim data sync.

Managed services:
- RDS PostgreSQL Multi-AZ, KMS encryption, private subnets.
- ElastiCache Redis for cache/rate-limit/short-lived holds.
- SQS + DLQs for asynchronous ETL and claim workflows.
- S3 with block-public-access, encryption, lifecycle and access logging.
- Cognito/OIDC for identity; enforce RBAC/ABAC in APIs.
- Secrets Manager + External Secrets Operator for runtime credentials.
- CloudTrail, CloudWatch, GuardDuty, Security Hub and centralized audit events.
- Bedrock only after confirming the exact service/region is covered by the applicable AWS BAA.

Use Terraform for infrastructure and GitHub Actions + ECR for image delivery.
Do not deploy this starter manifest directly to production: add IRSA/workload identity,
network policies, pod security, resource limits, autoscaling, TLS, ingress, secret mounts,
backup policies and admission controls first.
