import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Users, Target, Phone, CalendarCheck, TrendingUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Card } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

export default function Reports() {
  const [reports, setReports] = useState([]);
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [r, l] = await Promise.all([
          base44.entities.Report.list('-report_date', 40),
          base44.entities.Lead.list('-created_date', 500),
        ]);
        setReports(r || []);
        setLeads(l || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const sorted = reports.slice().sort((a, b) => (a.report_date > b.report_date ? 1 : -1));
  const last30 = sorted.slice(-30);
  const chartData = last30.map((r) => ({ label: r.report_date?.slice(5), leads: r.leads_generated || 0, calls: r.calls_made || 0 }));

  // Top lead sources by quality (avg score)
  const sourceMap = {};
  leads.forEach((l) => {
    if (!l.source) return;
    sourceMap[l.source] = sourceMap[l.source] || { sum: 0, count: 0 };
    sourceMap[l.source].sum += l.score || 0;
    sourceMap[l.source].count += 1;
  });
  const topSources = Object.entries(sourceMap)
    .map(([source, v]) => ({ source, avg: v.count ? Math.round(v.sum / v.count) : 0, count: v.count }))
    .sort((a, b) => b.avg - a.avg);

  const totals = reports.reduce(
    (acc, r) => ({
      leads: acc.leads + (r.leads_generated || 0),
      qualified: acc.qualified + (r.qualified || 0),
      calls: acc.calls + (r.calls_made || 0),
      meetings: acc.meetings + (r.meetings_booked || 0),
    }),
    { leads: 0, qualified: 0, calls: 0, meetings: 0 }
  );

  const summary = [
    { label: 'Leads Generated', value: totals.leads, icon: Users },
    { label: 'Qualified', value: totals.qualified, icon: Target },
    { label: 'Calls Made', value: totals.calls, icon: Phone },
    { label: 'Meetings Booked', value: totals.meetings, icon: CalendarCheck },
  ];

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-6">
      <PageHeader title="Reports" subtitle="Daily and weekly performance reports from the autonomous agent" />

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)
          : summary.map((s) => (
              <Card key={s.label} className="flex items-center gap-3 p-4">
                <span className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary"><s.icon className="h-5 w-5" /></span>
                <div>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                  <p className="text-xl font-semibold">{s.value.toLocaleString()}</p>
                </div>
              </Card>
            ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <h3 className="mb-4 text-sm font-semibold">30-Day Trends</h3>
          {loading ? <Skeleton className="h-[280px] rounded-lg" /> : (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={chartData} margin={{ top: 8, right: 10, left: -18, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} interval={3} />
                <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ background: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: 10, fontSize: 12 }} />
                <Bar dataKey="leads" name="Leads" radius={[4, 4, 0, 0]} fill="hsl(222 88% 56%)" maxBarSize={26} />
                <Bar dataKey="calls" name="Calls" radius={[4, 4, 0, 0]} fill="hsl(160 60% 45%)" maxBarSize={26} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold"><TrendingUp className="h-4 w-4 text-primary" /> Top Sources by Quality</h3>
          {loading ? <Skeleton className="h-48" /> : (
            <div className="space-y-3">
              {topSources.map((s, i) => (
                <div key={s.source}>
                  <div className="mb-1 flex items-center justify-between text-xs">
                    <span className="font-medium text-foreground">{s.source}</span>
                    <span className="text-muted-foreground">avg {s.avg} · {s.count} leads</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div className="h-full rounded-full" style={{ width: `${s.avg}%`, background: ['hsl(222 88% 56%)', 'hsl(160 60% 45%)', 'hsl(30 80% 55%)', 'hsl(280 65% 60%)', 'hsl(340 75% 55%)'][i % 5] }} />
                  </div>
                </div>
              ))}
              {topSources.length === 0 && <p className="text-sm text-muted-foreground">No source data.</p>}
            </div>
          )}
        </Card>
      </div>

      {/* Report list */}
      <Card className="mt-4 overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium">Period</th>
                <th className="px-4 py-3 font-medium">Leads</th>
                <th className="px-4 py-3 font-medium">Qualified</th>
                <th className="px-4 py-3 font-medium">Calls</th>
                <th className="px-4 py-3 font-medium">Meetings</th>
                <th className="px-4 py-3 font-medium">Conv. Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading
                ? Array.from({ length: 6 }).map((_, i) => <tr key={i}><td colSpan={7} className="px-4 py-4"><Skeleton className="h-6 w-full" /></td></tr>)
                : sorted.slice().reverse().map((r) => (
                    <tr key={r.id} className="hover:bg-muted/40">
                      <td className="px-4 py-3 font-medium text-foreground">{r.report_date}</td>
                      <td className="px-4 py-3"><span className="rounded-md bg-accent px-1.5 py-0.5 text-xs text-accent-foreground">{r.period}</span></td>
                      <td className="px-4 py-3">{r.leads_generated || 0}</td>
                      <td className="px-4 py-3">{r.qualified || 0}</td>
                      <td className="px-4 py-3">{r.calls_made || 0}</td>
                      <td className="px-4 py-3">{r.meetings_booked || 0}</td>
                      <td className="px-4 py-3 font-medium text-primary">{r.conversion_rate || 0}%</td>
                    </tr>
                  ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}