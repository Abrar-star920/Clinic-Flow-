import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Plus, Pencil, Trash2, Mail, Linkedin } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const CHANNELS = [
  { value: 'email', label: 'Email', icon: Mail },
  { value: 'linkedin', label: 'LinkedIn', icon: Linkedin },
];

const CATEGORIES = ['intro', 'follow_up', 'demo', 'meeting', 'breakup'];

function fillTokens(body, lead) {
  return (body || '')
    .replace(/\{\{first_name\}\}/g, lead?.contact_name?.split(' ')[0] || '{{first_name}}')
    .replace(/\{\{company\}\}/g, lead?.company_name || '{{company}}')
    .replace(/\{\{title\}\}/g, lead?.title || '{{title}}');
}

export { fillTokens };

export default function Templates() {
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [showEditor, setShowEditor] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      setItems((await base44.entities.MessageTemplate.list('-created_date', 200)) || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const openNew = () => { setEditing(null); setShowEditor(true); };
  const openEdit = (t) => { setEditing(t); setShowEditor(true); };

  const remove = async (t) => {
    try {
      await base44.entities.MessageTemplate.delete(t.id);
      toast({ title: 'Template deleted' });
      load();
    } catch {
      toast({ title: 'Delete failed', variant: 'destructive' });
    }
  };

  return (
    <div className="mx-auto max-w-6xl p-4 md:p-6">
      <PageHeader
        title="Outreach Templates"
        subtitle="Reusable email and LinkedIn message templates."
        actions={<Button onClick={openNew}><Plus className="mr-1.5 h-4 w-4" /> New template</Button>}
      />

      {loading ? (
        <div className="grid gap-3 md:grid-cols-2">
          {[...Array(4)].map((_, i) => <div key={i} className="h-40 animate-pulse rounded-xl bg-muted" />)}
        </div>
      ) : items.length === 0 ? (
        <Card className="p-10 text-center text-sm text-muted-foreground">
          No templates yet. Create your first reusable message.
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {items.map((t) => {
            const Chan = CHANNELS.find((c) => c.value === t.channel)?.icon || Mail;
            return (
              <Card key={t.id} className="flex flex-col p-4">
                <div className="mb-2 flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <Chan className="h-4 w-4 text-muted-foreground" />
                      <p className="truncate text-sm font-semibold">{t.name}</p>
                    </div>
                    <p className="mt-0.5 text-[11px] uppercase tracking-wide text-muted-foreground">
                      {t.channel} · {t.category}
                    </p>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="icon" onClick={() => openEdit(t)}><Pencil className="h-3.5 w-3.5" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => remove(t)}><Trash2 className="h-3.5 w-3.5 text-destructive" /></Button>
                  </div>
                </div>
                {t.channel === 'email' && t.subject && (
                  <p className="mb-1 truncate text-xs font-medium text-foreground">Subject: {t.subject}</p>
                )}
                <p className="line-clamp-4 whitespace-pre-wrap text-xs text-muted-foreground">{t.body}</p>
              </Card>
            );
          })}
        </div>
      )}

      <TemplateEditor
        open={showEditor}
        item={editing}
        onClose={() => setShowEditor(false)}
        onSaved={() => { setShowEditor(false); load(); }}
      />
    </div>
  );
}

function TemplateEditor({ open, item, onClose, onSaved }) {
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [channel, setChannel] = useState('email');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [category, setCategory] = useState('intro');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName(item?.name || '');
      setChannel(item?.channel || 'email');
      setSubject(item?.subject || '');
      setBody(item?.body || '');
      setCategory(item?.category || 'intro');
    }
  }, [open, item]);

  const save = async () => {
    if (!name || !body) {
      toast({ title: 'Name and body are required', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const payload = { name, channel, subject: channel === 'email' ? subject : '', body, category };
      if (item?.id) await base44.entities.MessageTemplate.update(item.id, payload);
      else await base44.entities.MessageTemplate.create(payload);
      toast({ title: 'Template saved' });
      onSaved();
    } catch {
      toast({ title: 'Save failed', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{item ? 'Edit template' : 'New template'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="mb-1">Name</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. SaaS intro email" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="mb-1">Channel</Label>
              <Select value={channel} onValueChange={setChannel}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CHANNELS.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="mb-1">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          {channel === 'email' && (
            <div>
              <Label className="mb-1">Subject</Label>
              <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Email subject line" />
            </div>
          )}
          <div>
            <Label className="mb-1">Body</Label>
            <Textarea rows={7} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Use {{first_name}}, {{company}}, {{title}} as placeholders." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? 'Saving…' : 'Save template'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}