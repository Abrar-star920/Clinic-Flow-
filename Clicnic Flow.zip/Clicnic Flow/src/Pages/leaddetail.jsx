import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, Linkedin, Building2, Calendar, ClipboardList, Ban, Pause, UserCog, StickyNote, Sparkles, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ScoreBadge from '@/components/ScoreBadge';
import ScoreBreakdownChart from '@/components/ScoreBreakdownChart';
import AudioPlayer from '@/components/AudioPlayer';
import CallNotes from '@/components/CallNotes';
import AICallDialog from '@/components/AICallDialog';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

const REPS = ['Unassigned', 'Alex Rivera', 'Priya Nair', 'Jordan Lee', 'Sofia Marin'];

const sentimentTone = {
  Positive: 'bg-emerald-500/10 text-emerald-600',
  Neutral: 'bg-muted text-muted-foreground',
  Negative: 'bg-red-500/10 text-red-600',
};

const FIELD = (Icon, label, value) => (
  <div className="flex items-center gap-3 rounded-lg border border-border bg-card px-3 py-2.5">
    <Icon className="h-4 w-4 text-muted-foreground" />
    <div className="min-w-0">
      <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="truncate text-sm text-foreground">{value || '—'}</p>
    </div>
  </div>
);

export default function LeadDetail() {
  const { id } = useParams();
  const { toast } = useToast();
  const [lead, setLead] = useState(null);
  const [calls, setCalls] = useState([]);
  const [loading, setLoading] = useState(true);
  const [aiCallOpen, setAiCallOpen] = useState(false);
  const [fetchingCall, setFetchingCall] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const [l, c] = await Promise.all([
        base44.entities.Lead.get(id),
        base44.entities.Call.filter({ lead_id: id }, '-created_date', 50),
      ]);
      setLead(l);
      setCalls(c || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  const fetchCallResults = async (callId) => {
    setFetchingCall(callId);
    try {
      const res = await base44.functions.invoke('BlandCallDetails', { call_id: callId });
      if (res.data?.error) {
        toast({ title: res.data.error, variant: 'destructive' });
      } else {
        toast({ title: 'Call results fetched', description: 'Transcript & summary updated' });
        load();
      }
    } catch {
      toast({ title: 'Failed to fetch results', variant: 'destructive' });
    } finally {
      setFetchingCall(null);
    }
  };

  const update = async (patch, msg) => {
    try {
      setLead((p) => ({ ...p, ...patch }));
      await base44.entities.Lead.update(id, patch);
      toast({ title: msg });
    } catch {
      toast({ title: 'Update failed', variant: 'destructive' });
      load();
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-6xl space-y-4 p-4 md:p-6">
        <Skeleton className="h-9 w-40" />
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-64 lg:col-span-2" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="mx-auto max-w-6xl p-6 text-center">
        <p className="text-sm text-muted-foreground">Lead not found.</p>
        <Link to="/leads" className="mt-3 inline-block text-primary hover:underline">Back to leads</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl p-4 md:p-6">
      <Link to="/leads" className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> Back to leads
      </Link>

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-semibold tracking-tight md:text-2xl">{lead.company_name}</h1>
            <ScoreBadge score={lead.score} showLabel />
          </div>
          <p className="mt-1 text-sm text-muted-foreground">
            {lead.contact_name} · {lead.title || '—'} · {lead.industry || 'Industry unknown'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            size="sm"
            disabled={!lead.phone || lead.dnc}
            onClick={async () => {
              try {
                await base44.entities.Call.create({
                  lead_id: lead.id,
                  company_name: lead.company_name,
                  contact_name: lead.contact_name,
                  outcome: 'No Answer',
                  review_status: 'Pending',
                });
                toast({ title: 'Call logged — opening dialer…' });
              } catch {
                toast({ title: 'Could not log call', variant: 'destructive' });
              }
              window.location.href = `tel:${lead.phone}`;
            }}
          >
            <Phone className="mr-1.5 h-4 w-4" /> Call {lead.phone || '—'}
          </Button>
          <Button
            size="sm"
            variant="secondary"
            disabled={!lead.phone || lead.dnc}
            onClick={() => setAiCallOpen(true)}
          >
            <Sparkles className="mr-1.5 h-4 w-4" /> Call with AI
          </Button>
          <Link to="/admin?tab=review">
            <Button variant="outline" size="sm"><ClipboardList className="mr-1.5 h-4 w-4" /> Call review queue</Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Left: contact + controls */}
        <div className="space-y-4">
          <Card className="p-4">
            <h3 className="mb-3 text-sm font-semibold">Contact Information</h3>
            <div className="space-y-2">
              {FIELD(Building2, 'Company', lead.company_name)}
              {FIELD(Mail, 'Email', lead.email)}
              {FIELD(Phone, 'Phone', lead.phone)}
              {FIELD(Linkedin, 'LinkedIn', lead.linkedin_url)}
            </div>
          </Card>

          <Card className="p-4">
            <h3 className="mb-3 text-sm font-semibold">Outreach Controls</h3>
            <div className="space-y-3">
              <label className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm"><Ban className="h-4 w-4 text-destructive" /> Do Not Call</span>
                <Switch checked={!!lead.dnc} onCheckedChange={(v) => update({ dnc: v }, 'DNC updated')} className="data-[state=checked]:bg-destructive" />
              </label>
              <label className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm"><Pause className="h-4 w-4 text-amber-500" /> Pause Outreach</span>
                <Switch checked={!!lead.outreach_paused} onCheckedChange={(v) => update({ outreach_paused: v }, 'Outreach paused')} className="data-[state=checked]:bg-amber-500" />
              </label>
              <div>
                <p className="mb-1.5 flex items-center gap-2 text-sm"><UserCog className="h-4 w-4 text-muted-foreground" /> Assigned Rep</p>
                <Select value={lead.assigned_rep || 'Unassigned'} onValueChange={(v) => update({ assigned_rep: v }, 'Rep reassigned')}>
                  <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {REPS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        </div>

        {/* Right: score + calls */}
        <div className="space-y-4 lg:col-span-2">
          <Card className="p-4">
            <div className="mb-1 flex items-center justify-between">
              <h3 className="text-sm font-semibold">Lead Score Breakdown</h3>
              <span className="text-xs text-muted-foreground">Total: <span className="font-semibold text-foreground">{Math.round(lead.score || 0)}/100</span></span>
            </div>
            <ScoreBreakdownChart breakdown={lead.score_breakdown} />
          </Card>

          <Card className="p-4">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold"><Calendar className="h-4 w-4" /> Call History ({calls.length})</h3>
            {calls.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No calls logged yet.</p>
            ) : (
              <div className="space-y-4">
                {calls.map((call) => (
                  <div key={call.id} className="rounded-lg border border-border p-3">
                    <div className="mb-2 flex flex-wrap items-center gap-2">
                      <span className={`rounded-md px-2 py-0.5 text-xs font-medium ${sentimentTone[call.sentiment] || sentimentTone.Neutral}`}>
                        {call.sentiment}
                      </span>
                      <span className="rounded-md bg-accent px-2 py-0.5 text-xs text-accent-foreground">{call.outcome}</span>
                      <span className="text-[11px] text-muted-foreground">{new Date(call.created_date).toLocaleString()}</span>
                    </div>
                    {call.recording_url && <AudioPlayer src={call.recording_url} label="Recording" />}
                    <CallNotes call={call} onSaved={load} />
                    <Button
                      size="sm"
                      variant="ghost"
                      className="mt-1 h-7 text-xs"
                      disabled={fetchingCall === call.id}
                      onClick={() => fetchCallResults(call.id)}
                    >
                      {fetchingCall === call.id ? (
                        <><RefreshCw className="mr-1.5 h-3 w-3 animate-spin" /> Fetching…</>
                      ) : (
                        <><RefreshCw className="mr-1.5 h-3 w-3" /> Fetch AI results</>
                      )}
                    </Button>
                    {call.ai_summary && (
                      <p className="mt-2 text-sm text-foreground"><span className="font-medium">AI Summary:</span> {call.ai_summary}</p>
                    )}
                    {call.next_step && (
                      <p className="mt-1 text-sm text-muted-foreground"><span className="font-medium text-foreground">Next step:</span> {call.next_step}</p>
                    )}
                    {call.transcript && (
                      <details className="mt-2">
                        <summary className="cursor-pointer text-xs font-medium text-primary">View transcript</summary>
                        <p className="mt-2 whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs leading-relaxed text-muted-foreground">{call.transcript}</p>
                      </details>
                    )}
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      <AICallDialog open={aiCallOpen} onOpenChange={setAiCallOpen} lead={lead} onCalled={load} />
    </div>
  );
}