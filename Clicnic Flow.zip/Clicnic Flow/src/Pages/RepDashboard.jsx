import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Users, CalendarClock, Trophy, TrendingUp, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import ScoreBadge from '@/components/ScoreBadge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';

export default function RepDashboard() {
  const [user, setUser] = useState(null);
  const [leads, setLeads] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [rep, setRep] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);
        const allLeads = (await base44.entities.Lead.list('-created_date', 500)) || [];
        const allMeetings = (await base44.entities.Meeting.list('-scheduled_at', 200)) || [];
        setLeads(allLeads);
        setMeetings(allMeetings);
        const reps = Array.from(new Set(allLeads.map((l) => l.assigned_rep).filter(Boolean)));
        const fallback = reps.find((r) => r !== 'Unassigned') || reps[0] || 'Unassigned';
        setRep(reps.includes(me.full_name) ? me.full_name : fallback);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const reps = useMemo(
    () => Array.from(new Set(leads.map((l) => l.assigned_rep).filter(Boolean))).sort(),
    [leads]
  );

  const myLeads = useMemo(() => leads.filter((l) => l.assigned_rep === rep), [leads, rep]);
  const myLeadIds = useMemo(() => new Set(myLeads.map((l) => l.id)), [myLeads]);

  const activeLeads = useMemo(() => myLeads.filter((l) => !['Won', 'Lost'].includes(l.status)), [myLeads]);
  const wonLeads = useMemo(() => myLeads.filter((l) => l.status === 'Won'), [myLeads]);
  const contacted = useMemo(() => myLeads.filter((l) => ['Contacted', 'Meeting Booked', 'Demo Done', 'Won'].includes(l.status)), [myLeads]);

  const myMeetings = useMemo(
    () => meetings.filter((m) => (m.lead_id && myLeadIds.has(m.lead_id)) || (m.company_name && myLeads.some((l) => l.company_name === m.company_name))),
    [meetings, myLeadIds, myLeads]
  );
  const pendingMeetings = useMemo(() => myMeetings.filter((m) => m.status === 'Scheduled'), [myMeetings]);

  const conversion = myLeads.length ? Math.round((wonLeads.length / myLeads.length) * 100) : 0;

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-6">
      <PageHeader
        title="My Dashboard"
        subtitle={user ? `Performance overview for ${user.full_name}` : 'Personal sales performance'}
        actions={
          <Select value={rep} onValueChange={setRep}>
            <SelectTrigger className="w-56"><SelectValue placeholder="Select rep" /></SelectTrigger>
            <SelectContent>
              {reps.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
        }
      />

      <div className="mb-5 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
        ) : (
          <>
            <StatCard label="Active Leads" value={activeLeads.length} icon={Users} accent="#2E6FF2" />
            <StatCard label="Pending Meetings" value={pendingMeetings.length} icon={CalendarClock} accent="#f59e0b" />
            <StatCard label="Won" value={wonLeads.length} icon={Trophy} accent="#10b981" />
            <StatCard label="Conversion Rate" value={`${conversion}%`} icon={TrendingUp} accent="#ec4899" />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div className="rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h3 className="text-sm font-semibold">Active Leads</h3>
            <span className="text-xs text-muted-foreground">{activeLeads.length} in progress</span>
          </div>
          <div className="divide-y divide-border">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => <div key={i} className="px-5 py-4"><Skeleton className="h-10 w-full" /></div>)
            ) : activeLeads.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-muted-foreground">No active leads for this rep.</p>
            ) : (
              activeLeads.slice(0, 8).map((l) => (
                <Link key={l.id} to={`/leads/${l.id}`} className="flex items-center justify-between px-5 py-3 transition-colors hover:bg-muted/40">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-foreground">{l.company_name}</p>
                    <p className="truncate text-xs text-muted-foreground">{l.contact_name} · {l.status}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <ScoreBadge score={l.score} />
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-4">
            <h3 className="text-sm font-semibold">Pending Meetings</h3>
            <span className="text-xs text-muted-foreground">{pendingMeetings.length} scheduled</span>
          </div>
          <div className="divide-y divide-border">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => <div key={i} className="px-5 py-4"><Skeleton className="h-10 w-full" /></div>)
            ) : pendingMeetings.length === 0 ? (
              <p className="px-5 py-8 text-center text-sm text-muted-foreground">No pending meetings.</p>
            ) : (
              pendingMeetings.slice(0, 8).map((m) => (
                <div key={m.id} className="px-5 py-3">
                  <p className="text-sm font-medium text-foreground">{m.title || m.company_name || 'Meeting'}</p>
                  <p className="text-xs text-muted-foreground">
                    {m.contact_name ? `${m.contact_name} · ` : ''}{m.company_name || ''}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {m.scheduled_at ? new Date(m.scheduled_at).toLocaleString() : 'Unscheduled'} · {m.duration_minutes || 30} min
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}