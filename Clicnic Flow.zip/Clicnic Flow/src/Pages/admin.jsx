import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Check, Flag, AlertTriangle, RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import HealthBadge from '@/components/HealthBadge';
import AudioPlayer from '@/components/AudioPlayer';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';

const SOURCES = ['Twilio', 'SMTP', 'Crunchbase', 'LinkedIn', 'Google Calendar', 'LLM'];
const sentimentRank = { Negative: 0, Neutral: 1, Positive: 2 };

export default function Admin() {
  const [params, setParams] = useSearchParams();
  const { toast } = useToast();
  const tab = params.get('tab') || 'review';

  const [calls, setCalls] = useState([]);
  const [errors, setErrors] = useState([]);
  const [health, setHealth] = useState([]);
  const [loading, setLoading] = useState(true);
  const [errSource, setErrSource] = useState('all');
  const [showResolved, setShowResolved] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [c, e, h] = await Promise.all([
        base44.entities.Call.list('-created_date', 100),
        base44.entities.ErrorLog.list('-created_date', 200),
        base44.entities.SystemConfig.list('-created_date', 20),
      ]);
      setCalls(c || []);
      setErrors(e || []);
      setHealth(h || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const setTab = (t) => setParams({ tab: t }, { replace: true });

  const sortedCalls = calls.slice().sort((a, b) => (sentimentRank[a.sentiment] ?? 1) - (sentimentRank[b.sentiment] ?? 1));

  const reviewCall = async (call, status) => {
    try {
      setCalls((prev) => prev.map((c) => (c.id === call.id ? { ...c, review_status: status } : c)));
      await base44.entities.Call.update(call.id, { review_status: status });
      toast({ title: status === 'Approved' ? 'Call approved' : 'Call flagged' });
    } catch {
      toast({ title: 'Failed', variant: 'destructive' });
      load();
    }
  };

  const toggleResolved = async (err) => {
    try {
      setErrors((prev) => prev.map((e) => (e.id === err.id ? { ...e, resolved: !e.resolved } : e)));
      await base44.entities.ErrorLog.update(err.id, { resolved: !err.resolved });
    } catch {
      load();
    }
  };

  const filteredErrors = errors.filter((e) => {
    if (errSource !== 'all' && e.source_system !== errSource) return false;
    if (!showResolved && e.resolved) return false;
    return true;
  });

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-6">
      <PageHeader title="Admin & Monitoring" subtitle="Review calls, monitor errors, and track system health" />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="mb-5">
          <TabsTrigger value="review">Call Review Queue</TabsTrigger>
          <TabsTrigger value="errors">Error Log</TabsTrigger>
          <TabsTrigger value="health">System Health</TabsTrigger>
        </TabsList>

        {/* Call review */}
        <TabsContent value="review" className="space-y-3">
          {loading
            ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)
            : sortedCalls.map((call) => (
                <Card key={call.id} className="p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{call.company_name || call.contact_name || 'Unknown'}</p>
                      <p className="text-xs text-muted-foreground">
                        {call.sentiment} · {call.outcome} · {new Date(call.created_date).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`rounded-md px-2 py-0.5 text-xs ${
                        call.review_status === 'Approved' ? 'bg-emerald-500/10 text-emerald-600' :
                        call.review_status === 'Flagged' ? 'bg-red-500/10 text-red-600' : 'bg-muted text-muted-foreground'
                      }`}>{call.review_status || 'Pending'}</span>
                      <Button size="sm" variant="outline" onClick={() => reviewCall(call, 'Approved')}><Check className="mr-1 h-3.5 w-3.5" /> Approve</Button>
                      <Button size="sm" variant="outline" onClick={() => reviewCall(call, 'Flagged')}><Flag className="mr-1 h-3.5 w-3.5" /> Flag</Button>
                    </div>
                  </div>
                  {call.recording_url && <div className="mt-3"><AudioPlayer src={call.recording_url} /></div>}
                  {call.ai_summary && <p className="mt-3 text-sm text-foreground"><span className="font-medium">Summary:</span> {call.ai_summary}</p>}
                  {call.transcript && (
                    <details className="mt-2">
                      <summary className="cursor-pointer text-xs font-medium text-primary">Transcript</summary>
                      <p className="mt-2 whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">{call.transcript}</p>
                    </details>
                  )}
                </Card>
              ))}
          {!loading && sortedCalls.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">No calls to review.</p>}
        </TabsContent>

        {/* Error log */}
        <TabsContent value="errors">
          <div className="mb-4 flex flex-col gap-3 rounded-xl border border-border bg-card p-3 sm:flex-row sm:items-center">
            <Select value={errSource} onValueChange={setErrSource}>
              <SelectTrigger className="w-full sm:w-48"><SelectValue placeholder="Source system" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All systems</SelectItem>
                {SOURCES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <label className="flex items-center gap-2 text-sm">
              <Switch checked={showResolved} onCheckedChange={setShowResolved} /> Show resolved
            </label>
          </div>
          <div className="space-y-2">
            {loading
              ? Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-lg" />)
              : filteredErrors.map((err) => (
                  <Card key={err.id} className={`flex items-center gap-3 p-3 ${err.resolved ? 'opacity-60' : ''}`}>
                    <AlertTriangle className={`h-4 w-4 ${err.resolved ? 'text-emerald-500' : 'text-amber-500'}`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-foreground">{err.message}</p>
                      <p className="text-xs text-muted-foreground">{err.source_system} · {err.error_type} · {new Date(err.created_date).toLocaleString()}</p>
                    </div>
                    <Button size="sm" variant={err.resolved ? 'outline' : 'default'} onClick={() => toggleResolved(err)}>
                      {err.resolved ? 'Reopen' : 'Resolve'}
                    </Button>
                  </Card>
                ))}
            {!loading && filteredErrors.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">No errors logged.</p>}
          </div>
        </TabsContent>

        {/* System health */}
        <TabsContent value="health">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {loading
              ? Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)
              : SOURCES.map((svc) => {
                  const cfg = health.find((h) => h.service_name === svc);
                  return (
                    <Card key={svc} className="p-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-sm font-semibold text-foreground">{svc}</h3>
                        <HealthBadge status={cfg?.status || 'Operational'} />
                      </div>
                      <p className="mt-3 text-xs text-muted-foreground">
                        Last checked: {cfg?.last_checked ? new Date(cfg.last_checked).toLocaleString() : '—'}
                      </p>
                      <p className="mt-1 text-xs text-muted-foreground">{cfg?.detail || 'No detail available'}</p>
                    </Card>
                  );
                })}
          </div>
          {!loading && (
            <div className="mt-4">
              <Button variant="outline" onClick={load}><RefreshCw className="mr-1.5 h-4 w-4" /> Refresh status</Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}