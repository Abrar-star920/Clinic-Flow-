import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ChevronRight, Flag, X, Sparkles, Linkedin, PhoneCall, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import PageHeader from '@/components/PageHeader';
import ScoreBadge from '@/components/ScoreBadge';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';

const STATUSES = ['New', 'Enriching', 'Qualified', 'Contacted', 'Meeting Booked', 'Demo Done', 'Won', 'Lost'];

export default function Leads() {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [selected, setSelected] = useState(new Set());
  const [generating, setGenerating] = useState(false);
  const [pulling, setPulling] = useState(false);
  const [batchCalling, setBatchCalling] = useState(false);
  const { toast } = useToast();

  const loadLeads = async () => {
    setLeads((await base44.entities.Lead.list('-created_date', 500)) || []);
  };

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const res = await base44.functions.invoke('GenerateLeads', { count: 10 });
      const n = res.data?.created ?? 0;
      toast({ title: `${n} real leads generated` });
      await loadLeads();
    } catch (e) {
      toast({ title: 'Lead generation failed', description: e.message, variant: 'destructive' });
    } finally {
      setGenerating(false);
    }
  };

  const handlePullLinkedIn = async () => {
    setPulling(true);
    try {
      const res = await base44.functions.invoke('PullLinkedInLeads', { count: 10 });
      const n = res.data?.created ?? 0;
      toast({ title: `${n} leads pulled from LinkedIn` });
      await loadLeads();
    } catch (e) {
      toast({ title: 'LinkedIn pull failed', description: e.message, variant: 'destructive' });
    } finally {
      setPulling(false);
    }
  };

  useEffect(() => {
    (async () => {
      try {
        await loadLeads();
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const filtered = useMemo(
    () =>
      leads.filter((l) => {
        if (status !== 'all' && l.status !== status) return false;
        if (q) {
          const t = q.toLowerCase();
          if (!`${l.company_name} ${l.contact_name} ${l.title || ''} ${l.industry || ''}`.toLowerCase().includes(t)) return false;
        }
        return true;
      }),
    [leads, q, status]
  );

  const reps = useMemo(() => {
    const set = new Set(['Unassigned']);
    leads.forEach((l) => l.assigned_rep && set.add(l.assigned_rep));
    return Array.from(set);
  }, [leads]);

  const allFilteredSelected = filtered.length > 0 && filtered.every((l) => selected.has(l.id));
  const toggleAll = () => {
    const next = new Set(selected);
    if (allFilteredSelected) filtered.forEach((l) => next.delete(l.id));
    else filtered.forEach((l) => next.add(l.id));
    setSelected(next);
  };
  const toggleOne = (id) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
  };
  const clearSelection = () => setSelected(new Set());

  const applyBulk = async (patch, label) => {
    const ids = Array.from(selected);
    try {
      await base44.entities.Lead.updateMany({ id: { $in: ids } }, { $set: patch });
      setLeads((prev) => prev.map((l) => (selected.has(l.id) ? { ...l, ...patch } : l)));
      toast({ title: `${label} · ${ids.length} lead${ids.length > 1 ? 's' : ''}` });
    } catch {
      toast({ title: 'Bulk update failed', variant: 'destructive' });
    }
  };
  const bulkStatus = (s) => applyBulk({ status: s }, `Status → ${s}`);
  const bulkRep = (r) => applyBulk({ assigned_rep: r }, `Rep → ${r}`);
  const bulkFlag = () => applyBulk({ flagged: true }, 'Flagged');
  const bulkUnflag = () => applyBulk({ flagged: false }, 'Unflagged');
  const selectedCount = selected.size;

  const handleBatchCall = async () => {
    const selectedLeads = leads.filter((l) => selected.has(l.id) && l.phone && !l.dnc);
    if (selectedLeads.length === 0) {
      toast({ title: 'No callable leads selected', description: 'Leads need a phone number and must not be on DNC', variant: 'destructive' });
      return;
    }
    setBatchCalling(true);
    let success = 0;
    let failed = 0;
    for (const lead of selectedLeads) {
      try {
        const res = await base44.functions.invoke('BlandAICall', { lead_id: lead.id });
        if (res.data?.success) success++; else failed++;
      } catch {
        failed++;
      }
    }
    toast({ title: `Batch calling complete`, description: `${success} calls initiated, ${failed} failed` });
    clearSelection();
    setBatchCalling(false);
  };

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-6">
      <PageHeader
        title="Leads"
        subtitle={`${leads.length} leads discovered and enriched by the agent`}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handlePullLinkedIn}
              disabled={pulling}
              className="inline-flex items-center gap-1.5 rounded-lg border border-[#0A66C2] bg-[#0A66C2] px-4 py-2 text-sm font-medium text-white hover:opacity-90 disabled:opacity-60"
            >
              <Linkedin className="h-4 w-4" />
              {pulling ? 'Pulling…' : 'Pull from LinkedIn'}
            </button>
            <button
              onClick={handleGenerate}
              disabled={generating}
              className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60"
            >
              <Sparkles className="h-4 w-4" />
              {generating ? 'Generating…' : 'Generate Leads'}
            </button>
          </div>
        }
      />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search leads…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full sm:w-48"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {selectedCount > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-primary/40 bg-accent/40 p-3">
          <span className="text-sm font-medium text-foreground">{selectedCount} selected</span>
          <Select onValueChange={bulkStatus}>
            <SelectTrigger className="h-8 w-44"><SelectValue placeholder="Change status" /></SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select onValueChange={bulkRep}>
            <SelectTrigger className="h-8 w-44"><SelectValue placeholder="Reassign rep" /></SelectTrigger>
            <SelectContent>
              {reps.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
          <button onClick={bulkFlag} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-card px-3 text-xs font-medium hover:bg-accent"><Flag className="h-3.5 w-3.5" /> Flag</button>
          <button onClick={bulkUnflag} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-border bg-card px-3 text-xs font-medium hover:bg-accent">Unflag</button>
          <Button size="sm" variant="secondary" onClick={handleBatchCall} disabled={batchCalling} className="h-8">
            {batchCalling ? <><Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> Calling…</> : <><PhoneCall className="mr-1.5 h-3.5 w-3.5" /> Batch AI Call</>}
          </Button>
          <button onClick={clearSelection} className="ml-auto inline-flex h-8 items-center gap-1 rounded-md px-3 text-xs text-muted-foreground hover:text-foreground"><X className="h-3.5 w-3.5" /> Clear</button>
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="w-10 px-4 py-3"><Checkbox checked={allFilteredSelected} onCheckedChange={toggleAll} aria-label="Select all" /></th>
                <th className="px-4 py-3 font-medium">Company</th>
                <th className="px-4 py-3 font-medium">Contact</th>
                <th className="hidden px-4 py-3 font-medium md:table-cell">Industry</th>
                <th className="px-4 py-3 font-medium">Source</th>
                <th className="px-4 py-3 font-medium">Score</th>
                <th className="hidden px-4 py-3 font-medium lg:table-cell">Status</th>
                <th className="hidden px-4 py-3 font-medium lg:table-cell">Rep</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {loading
                ? Array.from({ length: 8 }).map((_, i) => (
                    <tr key={i}><td colSpan={9} className="px-4 py-4"><Skeleton className="h-8 w-full" /></td></tr>
                  ))
                : filtered.map((l) => (
                    <tr key={l.id} className={`transition-colors hover:bg-muted/40 ${selected.has(l.id) ? 'bg-accent/40' : ''}`}>
                      <td className="px-4 py-3"><Checkbox checked={selected.has(l.id)} onCheckedChange={() => toggleOne(l.id)} aria-label="Select lead" /></td>
                      <td className="px-4 py-3 font-medium text-foreground">{l.company_name}</td>
                      <td className="px-4 py-3 text-muted-foreground">{l.contact_name}{l.title ? ` · ${l.title}` : ''}</td>
                      <td className="hidden px-4 py-3 text-muted-foreground md:table-cell">{l.industry || '—'}</td>
                      <td className="px-4 py-3"><span className="rounded-md bg-accent px-1.5 py-0.5 text-xs text-accent-foreground">{l.source || '—'}</span></td>
                      <td className="px-4 py-3"><ScoreBadge score={l.score} /></td>
                      <td className="hidden px-4 py-3 text-muted-foreground lg:table-cell">{l.status}</td>
                      <td className="hidden px-4 py-3 text-muted-foreground lg:table-cell">{l.assigned_rep || 'Unassigned'}</td>
                      <td className="px-4 py-3 text-right">
                        <Link to={`/leads/${l.id}`} className="inline-flex items-center text-primary hover:underline">
                          View <ChevronRight className="h-4 w-4" />
                        </Link>
                      </td>
                    </tr>
                  ))}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-10 text-center text-sm text-muted-foreground">No leads found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}