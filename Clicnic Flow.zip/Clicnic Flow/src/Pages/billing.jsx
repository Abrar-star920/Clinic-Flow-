import React, { useEffect, useState } from 'react';
import { Check, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/components/ui/use-toast';

const fmtUSD = (n) => '$' + Number(n).toLocaleString('en-US');
const fmtINR = (n) => '₹' + Number(n).toLocaleString('en-IN');

export default function Billing() {
  const { toast } = useToast();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currency, setCurrency] = useState('USD');

  useEffect(() => {
    (async () => {
      try {
        const data = await base44.entities.License.list('-created_date', 20);
        // ensure stable display order
        const order = ['basic', 'standard', 'premium', 'onetime'];
        setPlans((data || []).slice().sort((a, b) => order.indexOf(a.plan_code) - order.indexOf(b.plan_code)));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const priceOf = (p) => (currency === 'USD' ? p.base_price_usd : p.base_price_inr);
  const fmt = (n) => (currency === 'USD' ? fmtUSD(n) : fmtINR(n));
  const gst = (p) => Math.round(priceOf(p) * (p.gst_rate ?? 0.18));
  const total = (p) => priceOf(p) + gst(p);

  const buy = (plan) => toast({ title: `Starting ${plan.plan_name} plan…`, description: 'Checkout is a placeholder in this demo.' });

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-6">
      <PageHeader
        title="Billing & Plans"
        subtitle="Choose a plan. Prices include 18% GST."
        actions={
          <div className="inline-flex rounded-lg border border-border p-0.5">
            <button onClick={() => setCurrency('USD')} className={`rounded-md px-3 py-1.5 text-sm font-medium ${currency === 'USD' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>USD</button>
            <button onClick={() => setCurrency('INR')} className={`rounded-md px-3 py-1.5 text-sm font-medium ${currency === 'INR' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>INR</button>
          </div>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-80 rounded-xl" />)
          : plans.map((plan) => (
              <Card key={plan.id} className={`relative flex flex-col p-5 ${plan.highlighted ? 'border-primary ring-1 ring-primary' : ''}`}>
                {plan.highlighted && (
                  <span className="absolute -top-3 left-1/2 inline-flex -translate-x-1/2 items-center gap-1 rounded-full bg-primary px-3 py-1 text-[11px] font-semibold text-primary-foreground">
                    <Sparkles className="h-3 w-3" /> Popular
                  </span>
                )}
                <h3 className="text-sm font-semibold text-foreground">{plan.plan_name}</h3>
                <p className="mt-0.5 text-xs text-muted-foreground capitalize">{plan.period} plan</p>
                <div className="mt-4">
                  <p className="text-2xl font-semibold tracking-tight text-foreground">{fmt(priceOf(plan))}</p>
                  <p className="text-xs text-muted-foreground">base price</p>
                </div>
                <div className="mt-3 space-y-1 rounded-lg bg-muted/50 p-3 text-xs">
                  <div className="flex justify-between text-muted-foreground"><span>GST (18%)</span><span className="text-foreground">{fmt(gst(plan))}</span></div>
                  <div className="flex justify-between font-semibold text-foreground"><span>Total</span><span>{fmt(total(plan))}</span></div>
                </div>
                <Button className="mt-4 w-full" variant={plan.highlighted ? 'default' : 'outline'} onClick={() => buy(plan)}>Buy {plan.plan_name}</Button>
                <ul className="mt-4 space-y-2">
                  {(plan.features || []).map((f) => (
                    <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground">
                      <Check className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" /> {f}
                    </li>
                  ))}
                </ul>
              </Card>
            ))}
      </div>

      {!loading && plans.length > 0 && (
        <div className="mt-8 overflow-hidden rounded-xl border border-border">
          <div className="overflow-x-auto scrollbar-thin">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Feature</th>
                  {plans.map((p) => <th key={p.id} className="px-4 py-3 text-center font-medium">{p.plan_name}</th>)}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr><td className="px-4 py-3 text-muted-foreground">Calls / day</td>{plans.map((p) => <td key={p.id} className="px-4 py-3 text-center font-medium">{p.calls_per_day ?? '—'}</td>)}</tr>
                <tr><td className="px-4 py-3 text-muted-foreground">Users</td>{plans.map((p) => <td key={p.id} className="px-4 py-3 text-center font-medium">{p.users ?? '—'}</td>)}</tr>
                <tr><td className="px-4 py-3 text-muted-foreground">CRM seats</td>{plans.map((p) => <td key={p.id} className="px-4 py-3 text-center font-medium">{p.crm_seats ?? '—'}</td>)}</tr>
                <tr><td className="px-4 py-3 text-muted-foreground">Support</td>{plans.map((p) => <td key={p.id} className="px-4 py-3 text-center font-medium">{p.support_level || '—'}</td>)}</tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}