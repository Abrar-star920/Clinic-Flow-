import React, { useEffect, useMemo, useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Search, Filter, RotateCcw, Mail, Linkedin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/PageHeader';
import KanbanCard from '@/components/KanbanCard';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import OutreachDialog from '@/components/OutreachDialog';

const COLUMNS = [
  { id: 'New', label: 'New', color: 'border-t-slate-400' },
  { id: 'Enriching', label: 'Enriching', color: 'border-t-sky-500' },
  { id: 'Qualified', label: 'Qualified', color: 'border-t-emerald-500' },
  { id: 'Contacted', label: 'Contacted', color: 'border-t-indigo-500' },
  { id: 'Meeting Booked', label: 'Meeting Booked', color: 'border-t-violet-500' },
  { id: 'Demo Done', label: 'Demo Done', color: 'border-t-amber-500' },
  { id: 'Won', label: 'Won', color: 'border-t-emerald-600' },
  { id: 'Lost', label: 'Lost', color: 'border-t-red-500' },
];

const REPS = ['Unassigned', 'Alex Rivera', 'Priya Nair', 'Jordan Lee', 'Sofia Marin'];

export default function Pipeline() {
  const { toast } = useToast();
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({ q: '', source: 'all', minScore: '', maxScore: '' });
  const [outreach, setOutreach] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await base44.entities.Lead.list('-created_date', 500);
      setLeads(data || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    return leads.filter((l) => {
      if (filters.q) {
        const q = filters.q.toLowerCase();
        if (!`${l.company_name} ${l.contact_name} ${l.title || ''}`.toLowerCase().includes(q)) return false;
      }
      if (filters.source !== 'all' && l.source !== filters.source) return false;
      if (filters.minScore !== '' && (l.score || 0) < Number(filters.minScore)) return false;
      if (filters.maxScore !== '' && (l.score || 0) > Number(filters.maxScore)) return false;
      return true;
    });
  }, [leads, filters]);

  const onDragEnd = async (result) => {
    const { destination, source, draggableId } = result;
    if (!destination || destination.droppableId === source.droppableId) return;
    setLeads((prev) => prev.map((l) => (l.id === draggableId ? { ...l, status: destination.droppableId } : l)));
    try {
      await base44.entities.Lead.update(draggableId, { status: destination.droppableId });
      toast({ title: `Moved to ${destination.droppableId}` });
    } catch {
      toast({ title: 'Failed to update lead', variant: 'destructive' });
      load();
    }
  };

  const handleAction = async (lead, action) => {
    try {
      let patch = {};
      if (action === 'requalify') patch = { status: 'Enriching' };
      else if (action === 'reassign') {
        const next = REPS[(REPS.indexOf(lead.assigned_rep || 'Unassigned') + 1) % REPS.length];
        patch = { assigned_rep: next };
      } else if (action === 'pause') patch = { outreach_paused: !lead.outreach_paused };
      else if (action === 'dnc') patch = { dnc: !lead.dnc };
      else if (action === 'flag') patch = { flagged: !lead.flagged };
      setLeads((prev) => prev.map((l) => (l.id === lead.id ? { ...l, ...patch } : l)));
      await base44.entities.Lead.update(lead.id, patch);
      toast({ title: 'Lead updated' });
    } catch {
      toast({ title: 'Update failed', variant: 'destructive' });
      load();
    }
  };

  return (
    <div className="mx-auto max-w-7xl p-4 md:p-6">
      <PageHeader title="CRM Pipeline" subtitle="Drag leads across stages. Use the menu on each card to override." />

      {/* Filter bar */}
      <div className="mb-5 flex flex-col gap-3 rounded-xl border border-border bg-card p-3 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search company, contact, title…"
            value={filters.q}
            onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
            className="pl-9"
          />
        </div>
        <Select value={filters.source} onValueChange={(v) => setFilters((f) => ({ ...f, source: v }))}>
          <SelectTrigger className="w-full lg:w-44"><Filter className="mr-2 h-4 w-4" /><SelectValue placeholder="Source" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All sources</SelectItem>
            {['Crunchbase', 'LinkedIn', 'Referral', 'Inbound', 'Web Scraping'].map((s) => (
              <SelectItem key={s} value={s}>{s}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <Input type="number" placeholder="Min score" className="w-28" value={filters.minScore} onChange={(e) => setFilters((f) => ({ ...f, minScore: e.target.value }))} />
          <Input type="number" placeholder="Max score" className="w-28" value={filters.maxScore} onChange={(e) => setFilters((f) => ({ ...f, maxScore: e.target.value }))} />
          <Button variant="outline" size="icon" onClick={() => setFilters({ q: '', source: 'all', minScore: '', maxScore: '' })} title="Reset filters">
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="grid animate-pulse grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-8">
          {COLUMNS.map((c) => <div key={c.id} className="h-64 rounded-xl bg-muted" />)}
        </div>
      ) : (
        <div className="overflow-x-auto pb-4 scrollbar-thin">
          <DragDropContext onDragEnd={onDragEnd}>
            <div className="flex min-w-max gap-3">
              {COLUMNS.map((col) => {
                const items = filtered.filter((l) => l.status === col.id);
                return (
                  <div key={col.id} className="flex w-72 flex-col">
                    <div className={`mb-2 flex items-center justify-between rounded-t-lg border-t-4 ${col.color} bg-card px-3 py-2`}>
                      <span className="text-sm font-semibold text-foreground">{col.label}</span>
                      <span className="rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground">{items.length}</span>
                    </div>
                    <Droppable droppableId={col.id}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.droppableProps}
                          className={`flex-1 space-y-2 rounded-b-lg border border-border border-t-0 bg-muted/30 p-2 transition-colors ${snapshot.isDraggingOver ? 'bg-primary/5' : ''}`}
                          style={{ minHeight: 200 }}
                        >
                          {items.map((lead, idx) => (
                            <Draggable key={lead.id} draggableId={lead.id} index={idx}>
                              {(p) => (
                                <KanbanCard
                                  lead={lead}
                                  innerRef={p.innerRef}
                                  draggableProps={p.draggableProps}
                                  dragHandleProps={p.dragHandleProps}
                                  onAction={handleAction}
                                  onOutreach={(lead, channel) => setOutreach({ lead, channel })}
                                />
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                          {items.length === 0 && !provided.placeholder && (
                            <p className="px-2 py-6 text-center text-xs text-muted-foreground">No leads</p>
                          )}
                        </div>
                      )}
                    </Droppable>
                  </div>
                );
              })}
            </div>
          </DragDropContext>
        </div>
      )}
    </div>
  );
}